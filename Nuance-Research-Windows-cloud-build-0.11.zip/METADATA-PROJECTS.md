# Bibliographic extraction and projects — 0.7

The library, maps and citation analysis can use project bibliographies. A reference may belong to several projects without duplicating its PDF. Projects are private to the account and tenant. Their membership never grants access to a document: current document/collection ACLs are checked before retrieval and export.

## Using projects

In Bibliothèque, select references, open **Gérer les projets**, enter a name and create a project. Select a project in **Bibliographie du projet** to search/export it or add/remove selected references. Removing membership preserves the original reference. The Mac library initially has a **Bibliographie initiale** containing its 432 existing sources.

In the writing sidebar, select one or several project bibliographies. Their union is used before lexical/vector candidate retrieval. The selection is saved with the draft; it applies to paragraph, footnote and whole-article suggestions. **Toute ma bibliothèque** is a separate explicit scope. An empty project selection returns no sources; an unavailable project causes an error rather than silently searching the whole library. Previously accepted citations remain in a draft when its scope changes; only new analyses use the new scope. **Carte de cet article** and **Comparer avec l’article en cours** copy this scope to the map, where it can also be changed independently.

API: `/api/research/projects` GET/POST, `/api/research/projects/{id}` PUT with revision checking. `/api/research/suggest`, `/api/research/search`, `/api/research/map` and saved drafts accept `project_ids`: omitted/null = whole account bibliography, [] = empty, array = union. `/api/research/references`, `/api/research/export` and `/api/research/export.bib` accept repeated `project_ids` query parameters. Each project supports up to 10,000 membership IDs; at most 20 projects can be selected together.

## Extraction and review

New imports and **Améliorer les notices bibliographiques** use bibliography-v2.1. For existing PDFs the analysis reads at most three initial pages, 20,000 characters/page, 1,500 font fragments; the PDF byte read is capped at 20 MB. Larger PDFs use the previously extracted page text. Typography accounts for PDF transformation matrices and repeated running titles. XMP, explicit labels, publication headers, DOI/ISBN/ISSN, journal names, publication dates and publisher statements are combined. File creation dates are not publication dates. Abstracts/reference lists are excluded from DOI header detection; ambiguous identifiers are proposed for review.

Every proposed field carries a method, evidence level and available page/excerpt. These levels describe extraction methods, not truth probabilities. Font-based titles and inferred bylines/types remain heuristic. Labels, matching PDF title properties and registered DOI fields can fill empty fields automatically. Existing non-placeholder values and manually verified fields are preserved. Other corrections require checking the proposed values against their evidence. Author family/given structure is kept for CSL/BibTeX and citation formatting. OCR-corrupted bylines, metadata-poor scans and historical/legal formats still need review; no benchmark establishes a general accuracy percentage.

Metadata proposals and before-change snapshots are private research records. Apply uses revision checks; **Annuler la dernière correction** restores the previous notice only when no subsequent edit has occurred. After partial application, remaining fields are still reviewable. Source pages, document hashes and embeddings are unchanged. Processing is sequential in bounded batches of up to ten local notices, with progress/cancellation. It does not run at idle. Cancellation may let the current server batch finish; completed changes remain reversible.

API: POST `/api/research/metadata/analyze` with `reference_ids`, `mode` (local/crossref/grobid), `online_consent` and optional `apply_safe`. GET `/api/research/metadata/{id}`; POST `.../apply` with current `revision` and optionally selected `fields`; POST `.../undo` with current revision. Crossref/GROBID requests accept one reference at a time.

## Optional Crossref

Unchecked by default. Check **Compléter via Crossref** or press the explicit DOI enrichment button in a notice. Only the DOI is sent to `https://api.crossref.org/works/{DOI}`; no PDF, article text, account identity or email is sent. As with any HTTP service the provider sees the connection IP. Local document/title concordance is checked before registered metadata is accepted. Mismatches are shown as alternatives, never automatically substituted. Missing/unresolved DOI or unavailable service leaves local extraction available. Tests mock the service; this update did not send user-library identifiers to Crossref.

## Optional local GROBID

A GROBID header adapter is available, with external consolidation disabled. It sends the PDF to your configured private/local GROBID, never Crossref. Enable only when needed:

```sh
docker compose --profile metadata up -d grobid
# For the containerized API, set GROBID_URL=http://grobid:8070 in .env,
# then recreate the API container.
docker compose up -d api
# Stop the optional service after use:
docker compose --profile metadata stop grobid
```

For a host Python service configure `GROBID_URL=http://127.0.0.1:8070`. The bundled CRF profile caps the optional container at 2 CPU cores/2 GiB and requires downloading its image. GROBID is not running on the user's Mac and actual Docker/GROBID operation has not been validated here; the secure TEI parser and fallback behavior are tested. The core and local extractor do not require it. See [official Docker documentation](https://github.com/grobidOrg/grobid/blob/master/doc/Grobid-docker.md) and [Apache 2.0 license](https://github.com/grobidOrg/grobid/blob/master/LICENSE). Audit the selected container's transitive dependencies/model licenses before distribution.

## Production follow-up

Validate extraction against manually checked samples of journal articles, books/chapters, recommendations and legislation. Add resumable background job persistence, per-project collaboration rules, scalable paginated project membership, extraction worker resource isolation and OCR/GROBID benchmarking. Current processing is synchronous and project access is owner-private, not a shared-team project permission system. The best-effort request limiter is per process; production still needs an authenticated reverse proxy.
