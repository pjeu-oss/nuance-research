"""Private Qdrant embedded subprocess; release vectors when idle."""
import json,sys,contextlib
from types import SimpleNamespace

def main():
    from .config import Settings
    from .runtime import configure,metrics
    from .vector import VectorStore
    config=json.loads(sys.stdin.readline());settings=Settings(data_dir=config['data_dir'],cpu_threads=config['threads'])
    configure(settings)
    with contextlib.redirect_stdout(sys.stderr):
        store=VectorStore(settings,SimpleNamespace(fingerprint=config['fingerprint'],dimension=config['dimension'],backend=config['backend']))
    print(json.dumps({'ready':True}),flush=True)
    try:
        for line in sys.stdin:
            try:
                req=json.loads(line);op=req.pop('op')
                with contextlib.redirect_stdout(sys.stderr):
                    if op=='search':
                        req['sparse']={int(k):v for k,v in req['sparse'].items()};result=store.search(**req)
                    elif op=='upsert':
                        req['chunks']=[SimpleNamespace(**c) for c in req['chunks']]
                        req['sparse']=[{int(k):v for k,v in sp.items()} for sp in req['sparse']]
                        store.upsert(**req);result=None
                    elif op=='delete':store.delete(**req);result=None
                    else:raise ValueError('Unknown vector operation')
                print(json.dumps({'result':result,'runtime':metrics(settings)}),flush=True)
            except Exception as exc:print(json.dumps({'error':str(exc)}),flush=True)
    finally:store.close()
if __name__=='__main__':main()
