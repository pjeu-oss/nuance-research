"""Bounded document import/export and a validated rich-text document schema."""
import io,json,re,zipfile
from xml.etree import ElementTree as ET
from fastapi import HTTPException
FONTS={'Arial','Calibri','Cambria','Georgia','Helvetica','Times New Roman','serif','sans-serif'}
NODES={'doc','paragraph','heading','text','hardBreak','bulletList','orderedList','listItem','blockquote','horizontalRule','table','tableRow','tableCell','tableHeader','citationMarker'}
MARKS={'bold','italic','underline','strike','textStyle','link','superscript','subscript','code'}

def validate_editor(node,depth=0,state=None):
    state=state if state is not None else {'nodes':0,'chars':0}
    if depth>40 or not isinstance(node,dict) or node.get('type') not in NODES:raise ValueError('Invalid editor document')
    state['nodes']+=1
    if state['nodes']>30000:raise ValueError('Too many editor nodes')
    kind=node['type'];out={'type':kind}
    if kind=='text':
        value=node.get('text','')
        if not isinstance(value,str):raise ValueError('Invalid text')
        state['chars']+=len(value)
        if state['chars']>200000:raise ValueError('Article limited to 200000 text characters')
        out['text']=value
    attrs=node.get('attrs',{});attrs=attrs if isinstance(attrs,dict) else {}
    kept={}
    if kind=='heading':kept['level']=min(3,max(1,int(attrs.get('level',1))))
    if kind in {'heading','paragraph'} and attrs.get('textAlign') in {'left','center','right','justify'}:kept['textAlign']=attrs['textAlign']
    if kind in {'tableCell','tableHeader'}:
        for key in ['colspan','rowspan']:kept[key]=min(20,max(1,int(attrs.get(key,1))))
    if kind=='orderedList':kept['start']=min(1000,max(1,int(attrs.get('start',1))))
    if kind=='citationMarker':
        for key in ['citationId','footnoteId']:
            value=attrs.get(key)
            if value is not None and not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',str(value)):raise ValueError('Invalid citation marker')
            kept[key]=value
        kept['label']=str(attrs.get('label',''))[:2000]
        kept['status']=attrs.get('status') if attrs.get('status') in {'proposed','accepted','note'} else 'proposed'
    if kept:out['attrs']=kept
    marks=[]
    if not isinstance(node.get('marks',[]),list):raise ValueError('Invalid marks')
    for mark in node.get('marks',[]):
        if not isinstance(mark,dict) or mark.get('type') not in MARKS:continue
        value={'type':mark['type']};ma=mark.get('attrs',{});ma=ma if isinstance(ma,dict) else {}
        if mark['type']=='textStyle':
            safe={}
            if ma.get('fontFamily') in FONTS:safe['fontFamily']=ma['fontFamily']
            if re.fullmatch(r'(?:[89]|[1-6]\d|7[0-2])(?:pt|px)',str(ma.get('fontSize',''))):safe['fontSize']=ma['fontSize']
            if re.fullmatch(r'#[0-9a-fA-F]{6}',str(ma.get('color',''))):safe['color']=ma['color']
            if str(ma.get('lineHeight','')) in {'1','1.15','1.5','2'}:safe['lineHeight']=ma['lineHeight']
            value['attrs']=safe
        if mark['type']=='link':
            href=str(ma.get('href',''))
            if not re.match(r'^https?://',href,re.I):continue
            value['attrs']={'href':href[:2000],'target':'_blank','rel':'noopener noreferrer'}
        marks.append(value)
    if marks:out['marks']=marks
    if kind=='text' and not out['text']:raise ValueError('Empty text node')
    if 'content' in node:
        if not isinstance(node['content'],list):raise ValueError('Invalid editor content')
        out['content']=[validate_editor(v,depth+1,state) for v in node['content']]
        allowed_children={'doc':{'paragraph','heading','bulletList','orderedList','blockquote','horizontalRule','table'},'paragraph':{'text','citationMarker','hardBreak'},'heading':{'text','citationMarker','hardBreak'},'table':{'tableRow'},'tableRow':{'tableCell','tableHeader'},'tableCell':{'paragraph','heading','bulletList','orderedList','blockquote','table'},'tableHeader':{'paragraph','heading','bulletList','orderedList','blockquote','table'},'bulletList':{'listItem'},'orderedList':{'listItem'},'listItem':{'paragraph','heading','bulletList','orderedList','blockquote'},'blockquote':{'paragraph','heading','bulletList','orderedList','blockquote'}}
        if kind not in allowed_children or any(c['type'] not in allowed_children[kind] for c in out['content']):raise ValueError('Invalid nested editor content')
    return out

def editor_text(node):
    if node.get('type')=='text':return node.get('text','')
    if node.get('type')=='citationMarker':return node.get('attrs',{}).get('label','')
    if node.get('type')=='hardBreak':return '\n'
    separator='\n\n' if node.get('type') in {'doc','tableCell'} else ('\n' if node.get('type') in {'table','tableRow','bulletList','orderedList'} else '')
    return separator.join(editor_text(c) for c in node.get('content',[]))

def plain_document(text):
    return {'type':'doc','content':[{'type':'paragraph','content':[{'type':'text','text':part}]} if part else {'type':'paragraph'} for part in text.split('\n')]}

def import_document(data,filename,settings):
    from .extract import extract
    ext=filename.rsplit('.',1)[-1].lower();notes=[];warnings=[]
    if ext=='docx':
        ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        def tag(x):return '{'+ns['w']+'}'+x
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if sum(v.file_size for v in z.infolist())>100_000_000:raise ValueError('DOCX expansion limit')
            def xml(name):
                info=z.getinfo(name)
                if info.file_size>8_000_000:raise ValueError('DOCX XML limit')
                raw=z.read(info)
                if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw:raise ValueError('XML entities are not allowed')
                return ET.fromstring(raw)
            root=xml('word/document.xml')
            def paragraph(p):
                props=p.find('w:pPr',ns);attrs={};kind='paragraph'
                if props is not None:
                    style=props.find('w:pStyle',ns)
                    if style is not None:
                        m=re.search(r'(?:Heading|Titre)([1-3])',style.get(tag('val'),''),re.I)
                        if m:kind='heading';attrs['level']=int(m.group(1))
                    align=props.find('w:jc',ns)
                    if align is not None:attrs['textAlign']={'both':'justify'}.get(align.get(tag('val')),align.get(tag('val')))
                content=[]
                for r in p.findall('.//w:r',ns):
                    marks=[];pr=r.find('w:rPr',ns)
                    if pr is not None:
                        for word,mark in [('b','bold'),('i','italic'),('u','underline'),('strike','strike')]:
                            v=pr.find('w:'+word,ns)
                            if v is not None and v.get(tag('val'),'1') not in {'0','false','none'}:marks.append({'type':mark})
                        style={};fonts=pr.find('w:rFonts',ns);size=pr.find('w:sz',ns);color=pr.find('w:color',ns)
                        if fonts is not None and fonts.get(tag('ascii')) in FONTS:style['fontFamily']=fonts.get(tag('ascii'))
                        if size is not None:
                            try:style['fontSize']=str(int(int(size.get(tag('val')))/2))+'pt'
                            except (ValueError,TypeError):pass
                        if color is not None and re.fullmatch('[0-9A-Fa-f]{6}',color.get(tag('val'),'')):style['color']='#'+color.get(tag('val'))
                        if style:marks.append({'type':'textStyle','attrs':style})
                    for child in r:
                        if child.tag==tag('t') and child.text:
                            value={'type':'text','text':child.text}
                            if marks:value['marks']=marks
                            content.append(value)
                        elif child.tag in {tag('br'),tag('cr')}:content.append({'type':'hardBreak'})
                        elif child.tag==tag('tab'):content.append({'type':'text','text':'    '})
                        elif child.tag==tag('footnoteReference'):
                            number=child.get(tag('id'));content.append({'type':'citationMarker','attrs':{'footnoteId':'import-'+number,'citationId':None,'label':number,'status':'note'}})
                result={'type':kind,'content':content}
                if attrs:result['attrs']=attrs
                return result
            content=[]
            for child in root.find('w:body',ns):
                if child.tag==tag('p'):content.append(paragraph(child))
                elif child.tag==tag('tbl'):
                    rows=[]
                    for tr in child.findall('w:tr',ns):
                        cells=[{'type':'tableCell','content':[paragraph(p) for p in tc.findall('w:p',ns)] or [{'type':'paragraph'}]} for tc in tr.findall('w:tc',ns)]
                        if cells:rows.append({'type':'tableRow','content':cells})
                    if rows:content.append({'type':'table','content':rows})
            if 'word/footnotes.xml' in z.namelist():
                for note in xml('word/footnotes.xml').findall('w:footnote',ns):
                    number=note.get(tag('id'),'')
                    if number.isdigit() and int(number)>0:notes.append({'id':'import-'+number,'text':'\n'.join(editor_text(paragraph(p)) for p in note.findall('w:p',ns))[:10000],'citationId':None})
            doc=validate_editor({'type':'doc','content':content or [{'type':'paragraph'}]})
            warnings.append('DOCX : texte, styles courants, tableaux et notes importés. Images, commentaires, suivi des modifications, en-têtes et pagination Word ne sont pas reproduits.')
    elif ext in {'txt','md','pdf'}:
        pages,meta=extract(data,filename,settings);text='\n\n'.join(p[1] for p in pages)
        if len(text)>200000:raise ValueError('Article import limited to 200000 characters')
        doc=plain_document(text)
        warnings.append('PDF : texte extrait, mise en page originale non reproduite.' if ext=='pdf' else 'Import texte : le contenu est modifiable ; les marqueurs Markdown sont conservés comme texte.')
    else:raise ValueError('Use DOCX, PDF, TXT or MD')
    return {'title':filename.rsplit('.',1)[0],'editor_json':doc,'body':editor_text(doc),'footnotes':notes,'warnings':warnings}

def export_docx(payload):
    from docx import Document
    from docx.shared import Pt,Cm,RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.opc.part import Part
    from docx.opc.packuri import PackURI
    from docx.opc.constants import RELATIONSHIP_TYPE as RT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    document=Document();layout=payload.get('layout',{})
    for section in document.sections:
        section.page_width=Cm(29.7 if layout.get('orientation')=='landscape' else 21);section.page_height=Cm(21 if layout.get('orientation')=='landscape' else 29.7)
        margin=1.5 if layout.get('margins')=='compact' else 2.5
        section.top_margin=section.bottom_margin=section.left_margin=section.right_margin=Cm(margin)
    rich=validate_editor(payload.get('editor_json') or plain_document(payload.get('body','')))
    footnotes=payload.get('footnotes',[]);numbers={note['id']:index+1 for index,note in enumerate(footnotes)}
    def fill(p,n):
        alignment=n.get('attrs',{}).get('textAlign');p.alignment={'left':WD_ALIGN_PARAGRAPH.LEFT,'center':WD_ALIGN_PARAGRAPH.CENTER,'right':WD_ALIGN_PARAGRAPH.RIGHT,'justify':WD_ALIGN_PARAGRAPH.JUSTIFY}.get(alignment)
        for child in n.get('content',[]):
            if child['type']=='hardBreak':p.add_run().add_break();continue
            if child['type']=='citationMarker':
                attrs=child.get('attrs',{});fid=attrs.get('footnoteId')
                if fid in numbers:
                    run=p.add_run();reference=OxmlElement('w:footnoteReference');reference.set(qn('w:id'),str(numbers[fid]));run._r.append(reference)
                else:
                    run=p.add_run(attrs.get('label',''))
                    if attrs.get('status')=='proposed':run.font.color.rgb=RGBColor.from_string('8A632F')
                continue
            if child['type']!='text':continue
            run=p.add_run(child.get('text',''))
            for mark in child.get('marks',[]):
                kind=mark['type']
                if kind=='bold':run.bold=True
                elif kind=='italic':run.italic=True
                elif kind=='underline':run.underline=True
                elif kind=='strike':run.font.strike=True
                elif kind=='textStyle':
                    a=mark.get('attrs',{})
                    if a.get('fontFamily'):run.font.name=a['fontFamily']
                    if a.get('fontSize'):run.font.size=Pt(float(a['fontSize'][:-2]))
                    if a.get('color'):run.font.color.rgb=RGBColor.from_string(a['color'][1:])
            p.paragraph_format.line_spacing=float(layout.get('line_spacing',1.5)) if str(layout.get('line_spacing',1.5)) in {'1','1.15','1.5','2'} else 1.5
    def blocks(parent,nodes):
        for n in nodes:
            kind=n['type']
            if kind in {'paragraph','heading'}:
                p=parent.add_paragraph(style='Heading '+str(n.get('attrs',{}).get('level',1)) if kind=='heading' else None);fill(p,n)
            elif kind in {'bulletList','orderedList'}:
                for index,item in enumerate(n.get('content',[])):
                    first=True
                    for block in item.get('content',[]):
                        if block['type']=='paragraph':
                            p=parent.add_paragraph(style='List Number' if kind=='orderedList' else 'List Bullet');fill(p,block);first=False
                        else:blocks(parent,[block])
            elif kind=='table':
                rows=n.get('content',[]);cols=max((len(row.get('content',[])) for row in rows),default=1)
                table=parent.add_table(rows=len(rows),cols=cols)
                for index,row in enumerate(rows):
                    for col,cell in enumerate(row.get('content',[])):blocks(table.cell(index,col),cell.get('content',[]))
            else:blocks(parent,n.get('content',[]))
    if payload.get('title'):document.add_heading(payload['title'],0)
    blocks(document,rich.get('content',[]))
    if footnotes:
        root=OxmlElement('w:footnotes')
        for number,kind in [(-1,'separator'),(0,'continuationSeparator')]:
            note=OxmlElement('w:footnote');note.set(qn('w:id'),str(number));note.set(qn('w:type'),kind);p=OxmlElement('w:p');r=OxmlElement('w:r');r.append(OxmlElement('w:'+kind));p.append(r);note.append(p);root.append(note)
        for note_data in footnotes:
            note=OxmlElement('w:footnote');note.set(qn('w:id'),str(numbers[note_data['id']]));p=OxmlElement('w:p');r=OxmlElement('w:r');r.append(OxmlElement('w:footnoteRef'));p.append(r);r=OxmlElement('w:r');t=OxmlElement('w:t');t.set(qn('xml:space'),'preserve');t.text=' '+note_data.get('text','');r.append(t);p.append(r);note.append(p);root.append(note)
        part=Part(PackURI('/word/footnotes.xml'),'application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml',__import__('lxml').etree.tostring(root,encoding='utf-8',xml_declaration=True),document.part.package)
        document.part.relate_to(part,RT.FOOTNOTES)
    bibliography=payload.get('bibliography',[])
    if bibliography:
        document.add_heading('Bibliographie',1)
        for entry in bibliography:document.add_paragraph(str(entry))
    output=io.BytesIO();document.save(output);return output.getvalue()


def validate_payload(payload):
    if not isinstance(payload,dict) or len(json.dumps(payload))>2_000_000:raise ValueError('Article too large')
    result=dict(payload)
    if payload.get('editor_json'):
        result['editor_json']=validate_editor(payload['editor_json'])
        if result['editor_json']['type']!='doc':raise ValueError('Root must be doc')
        result['body']=editor_text(result['editor_json'])
    elif not isinstance(payload.get('body',''),str) or len(payload.get('body',''))>200000:raise ValueError('Invalid body')
    notes=payload.get('footnotes',[])
    if not isinstance(notes,list) or len(notes)>1000:raise ValueError('Invalid notes')
    ids=set();clean=[]
    for n in notes:
        if not isinstance(n,dict) or not re.fullmatch('[a-zA-Z0-9_-]{1,100}',str(n.get('id',''))) or n['id'] in ids:raise ValueError('Invalid note')
        if not isinstance(n.get('text',''),str) or len(n.get('text',''))>10000:raise ValueError('Note too large')
        ids.add(n['id']);clean.append({'id':n['id'],'text':n.get('text',''),'citationId':n.get('citationId')})
    result['footnotes']=clean
    layout=payload.get('layout',{});layout=layout if isinstance(layout,dict) else {}
    result['layout']={'orientation':'landscape' if layout.get('orientation')=='landscape' else 'portrait','margins':'compact' if layout.get('margins')=='compact' else 'normal','line_spacing':str(layout.get('line_spacing',1.5)) if str(layout.get('line_spacing',1.5)) in {'1','1.15','1.5','2'} else '1.5'}
    if len(str(payload.get('title','')))>1000:raise ValueError('Title too long')
    entries=payload.get('bibliography',[])
    if not isinstance(entries,list) or len(entries)>1000 or any(not isinstance(e,str) or len(e)>10000 for e in entries):raise ValueError('Invalid bibliography')
    return result
