"""Bound our own disposable workers; never stop another application's process."""
import os,subprocess,threading,time,json,queue,shutil
MiB=1024*1024

def available_memory():
    import psutil
    return psutil.virtual_memory()

def ensure_disk(path,additional_bytes=0,reserve_mb=512):
    if shutil.disk_usage(path).free < reserve_mb*MiB+max(0,additional_bytes)*2:
        raise RuntimeError('Not enough free disk space. Free space before importing; existing documents are preserved.')

def stop_worker(process):
    if process.poll() is not None:return
    try:
        process.terminate()
        try:process.wait(timeout=3)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
    except (OSError,subprocess.TimeoutExpired):pass

def spawn_worker(command,env,settings,kind):
    memory=available_memory();minimum=(768 if kind=='embedding' else 256)*MiB
    if memory.available<minimum:raise RuntimeError('Not enough available memory for this operation. Close other applications and retry.')
    limit=min(getattr(settings,'worker_memory_mb',3072)*MiB,int(memory.total*.4))
    options={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}
    process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',env=env,**options)
    def watch():
        import psutil
        try:
            own=psutil.Process(process.pid)
            if os.name=='nt':
                try:own.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
                except psutil.Error:pass
            while process.poll() is None:
                if own.memory_info().rss>limit or available_memory().available<128*MiB:
                    process._nuance_failure='Operation stopped to protect available memory. Use a smaller document or a lighter model.'
                    stop_worker(process);return
                time.sleep(1)
        except (psutil.Error,OSError):pass
    threading.Thread(target=watch,daemon=True,name='nuance-worker-budget').start()
    return process

def read_reply(process,timeout=180,max_chars=64*MiB):
    result=queue.Queue(maxsize=1)
    def read():
        try:result.put(process.stdout.readline(max_chars+1))
        except (OSError,ValueError):result.put('')
    threading.Thread(target=read,daemon=True,name='nuance-worker-reply').start()
    try:line=result.get(timeout=timeout)
    except queue.Empty:
        stop_worker(process)
        raise RuntimeError('Local operation timed out; retry with a smaller scope.')
    if not line:raise RuntimeError(getattr(process,'_nuance_failure','Local worker stopped; retry the operation'))
    if len(line)>max_chars:
        stop_worker(process);raise RuntimeError('Local worker response exceeds the memory limit')
    reply=json.loads(line)
    if reply.get('error'):raise RuntimeError(reply['error'])
    return reply
