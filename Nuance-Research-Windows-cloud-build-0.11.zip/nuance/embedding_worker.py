"""Private local subprocess. JSON protocol on pipes; no network endpoint."""
import contextlib,json,sys,os

def main():
    from .config import Settings
    config=json.loads(sys.stdin.readline())
    settings=Settings(embedder=config['backend'],model_path=config['model_path'],cpu_threads=config['threads'])
    from .runtime import configure,metrics
    configure(settings)
    if settings.embedder!="demo-hash":
        import torch
        torch.set_num_threads(settings.cpu_threads)
        torch.set_num_interop_threads(1)
    from .models import Embedder
    with contextlib.redirect_stdout(sys.stderr):model=Embedder(settings)
    print(json.dumps({'ready':True,'dimension':model.dimension,'fingerprint':model.fingerprint}),flush=True)
    for line in sys.stdin:
        try:
            request=json.loads(line)
            with contextlib.redirect_stdout(sys.stderr):rows,sparse=model.encode(request['texts'],query=request.get('query',False))
            print(json.dumps({'rows':rows,'sparse':sparse,'runtime':metrics(settings)}),flush=True)
        except Exception as exc:
            print(json.dumps({'error':str(exc)}),flush=True)
if __name__=='__main__':main()
