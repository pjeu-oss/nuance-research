import re,ipaddress
from pathlib import Path
from urllib.parse import urlparse
from sqlalchemy import select
from fastapi import HTTPException,Request
from .security import require_editor
from .db import Page,ResearchRecord,audit,uid,now
from . import metadata as parser

def install_metadata_routes(app,Session,lock,identity,get_doc,visible_refs,records,dto,clean):
    from .research import MetadataRequest,ApplyMetadata
    def reference(s,i,rid):
        r=next((r for r in visible_refs(s,i) if r.id==rid),None)
        if not r:raise HTTPException(404,'Reference unavailable')
        return r
    def proposal(s,i,rid):return next((r for r in records(s,i,'metadata-proposal') if r.payload.get('reference_id')==rid),None)
    @app.post('/api/research/metadata/analyze')
    def analyze(req:MetadataRequest,request:Request):
        i=identity(request);require_editor(i)
        if req.mode=='crossref' and not req.online_consent:raise HTTPException(422,'Explicit DOI-only Crossref consent required')
        if req.mode!='local' and len(req.reference_ids)>1:raise HTTPException(422,'Service requests process one reference at a time')
        result=[]
        for rid in req.reference_ids:
            with Session() as s:
                r=reference(s,i,rid);before=dict(r.payload);base_revision=r.revision
                d=get_doc(s,before['document_id'],i) if before.get('document_id') else None
                saved_pages=[(p.number,p.text[:20000],p.label) for p in s.scalars(select(Page).where(Page.document_id==d.id).order_by(Page.number).limit(3))] if d else []
                source_hash=d.sha256 if d else None;raw=dict(d.metadata_json) if d else {};filename=d.filename if d else before['title']
                data=None
                if d and Path(filename).suffix.lower()=='.pdf':
                    root=(Path(app.state.settings.data_dir)/'sources').resolve();path=(root/i['tenant']/(d.id+'.pdf')).resolve()
                    if path.is_relative_to(root) and path.is_file() and path.stat().st_size<=20*1024*1024:data=path.read_bytes()
            warnings=[];fonts=[]
            if data:
                try:saved_pages,raw,fonts=parser.pdf_front(data)
                except Exception:warnings.append('Lecture typographique indisponible ; utilisation du texte déjà extrait.')
            proposed=parser.infer_bibliography(saved_pages,filename,raw,fonts)
            proposed['warnings']+=warnings
            if req.mode=='grobid':
                url=app.state.settings.grobid_url;host=urlparse(url).hostname
                try:private=host in {'localhost','grobid'} or ipaddress.ip_address(host or '').is_private
                except ValueError:private=False
                if not url or not private:raise HTTPException(409,'Configure a local/private GROBID_URL first')
                if not data:proposed['warnings'].append('GROBID nécessite un PDF attaché accessible.')
                else:
                    try:
                        extra=parser.grobid_header(data,url)
                        for key,value in extra.items():proposed['fields'][key]=value;proposed['evidence'][key]={'method':'grobid-header','level':'strong','page':None,'excerpt':'GROBID TEI, consolidation externe désactivée'}
                    except Exception:proposed['warnings'].append('GROBID indisponible ou en-tête non reconnu ; extraction locale conservée.')
            elif req.mode=='crossref':
                doi=parser.normalize_doi(before.get('doi') or proposed['fields'].get('doi'))
                if not doi:proposed['warnings'].append('Aucun DOI non ambigu : Crossref non interrogé.')
                else:
                    try:
                        extra=parser.crossref_metadata(doi)
                        # An article identifier in a cited reference must not replace this document.
                        words={w for w in parser.norm(extra.get('title','')).split() if len(w)>3}
                        front_words=set(parser.norm(' '.join(p[1] for p in saved_pages)).split())
                        overlap=len(words&front_words)/max(1,len(words))
                        if d and overlap<.5:
                            proposed['evidence'].get('doi',{}).update(level='conflict');proposed['alternatives']['crossref']=extra;proposed['warnings'].append('Titre Crossref insuffisamment retrouvé dans le document : possible DOI d’une référence citée. Aucun remplacement automatique.')
                        else:
                            for key,value in extra.items():proposed['fields'][key]=value;proposed['evidence'][key]={'method':'crossref-exact-doi','level':'registered','page':None,'excerpt':'DOI '+doi+' ; concordance du titre vérifiée' if d else 'DOI fourni par l’auteur : '+doi}
                    except Exception:proposed['warnings'].append('DOI non résolu ou Crossref indisponible ; extraction locale conservée.')
            with lock,Session.begin() as s:
                r=reference(s,i,rid)
                if r.revision!=base_revision:result.append({'reference_id':rid,'error':'Notice modifiée pendant l’analyse ; relancez.'});continue
                p=proposal(s,i,rid)
                if not p:p=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='metadata-proposal',payload={});s.add(p)
                p.payload={'reference_id':rid,'base_revision':base_revision,'source_sha256':source_hash,'mode':req.mode,'online_consent':req.online_consent,'result':proposed,'analyzed_at':now()};p.revision=(p.revision or 0)+1;p.updated_at=now();s.flush()
                audit(s,i,'metadata.analyze',rid);value=dto(p)
            if req.apply_safe:
                applied=apply(rid,ApplyMetadata(revision=base_revision),request);value['applied_fields']=applied['applied_fields'];value['reference']=applied['reference']
            result.append(value)
        return {'proposals':result,'warning':'Les niveaux décrivent la méthode d’extraction, pas une probabilité de vérité.'}
    @app.get('/api/research/metadata/{rid}')
    def get_proposal(rid:str,request:Request):
        with Session() as s:
            i=identity(request);reference(s,i,rid);p=proposal(s,i,rid)
            if not p:raise HTTPException(404,'Analyze this reference first')
            return dto(p)
    @app.post('/api/research/metadata/{rid}/apply')
    def apply(rid:str,req:ApplyMetadata,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=reference(s,i,rid);p=proposal(s,i,rid)
            if not p:raise HTTPException(404,'Proposal unavailable')
            if r.revision!=req.revision or p.payload['base_revision']!=r.revision:raise HTTPException(409,'Proposal stale; analyze again')
            fields=p.payload['result']['fields'];evidence=p.payload['result']['evidence'];verified=set(r.payload.get('metadata_verified_fields',[]))
            def safe(key):
                old=r.payload.get('authors' if key=='author' else key)
                return key not in verified and ('authors' not in verified or key!='author') and evidence.get(key,{}).get('level') in {'strong','registered'} and (not old or (key=='title' and parser.placeholder_title(old)))
            selected=req.fields if req.fields is not None else [k for k in fields if safe(k)]
            if any(key not in fields for key in selected):raise HTTPException(422,'Unknown proposed field')
            merged={**r.payload};changed={}
            for key in selected:
                value=fields[key]
                if key=='author':merged['author']=value;merged['author_details']=value
                else:merged[key]=value
                changed[key]=evidence.get(key,{})
            cleaned=clean(merged);cleaned['document_id']=r.payload.get('document_id');cleaned['import_provenance']=r.payload.get('import_provenance');cleaned['metadata_evidence']={**r.payload.get('metadata_evidence',{}),**changed};cleaned['metadata_verified_fields']=sorted(verified|set(selected)) if req.fields is not None else sorted(verified)
            if not selected:return {'reference':dto(r),'applied_fields':[]}
            history=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='reference-history',payload={'reference_id':rid,'target_revision':r.revision+1,'before':r.payload});s.add(history);s.flush()
            r.payload=cleaned;r.revision+=1;r.updated_at=now();audit(s,i,'metadata.apply',rid)
            remaining={k:v for k,v in fields.items() if k not in selected}
            p.payload={**p.payload,'base_revision':r.revision,'result':{**p.payload['result'],'fields':remaining}};p.revision=(p.revision or 0)+1;p.updated_at=now()
            return {'reference':dto(r),'applied_fields':selected,'history_id':history.id}
    @app.post('/api/research/metadata/{rid}/undo')
    def undo(rid:str,req:ApplyMetadata,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=reference(s,i,rid)
            if r.revision!=req.revision:raise HTTPException(409,'Reference changed')
            histories=[h for h in records(s,i,'reference-history') if h.payload.get('reference_id')==rid and h.payload.get('target_revision')==r.revision]
            if not histories:raise HTTPException(409,'No metadata change available to undo at this revision')
            history=histories[-1];r.payload=history.payload['before'];r.revision+=1;r.updated_at=now();audit(s,i,'metadata.undo',rid);return dto(r)
