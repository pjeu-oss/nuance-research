import math, re, hashlib, json
from collections import Counter
from sqlalchemy import select, func
from sqlalchemy.orm import defer
from fastapi import HTTPException
from .db import Document, Collection, Chunk, Page, Concept, Tag
from .security import can_read
from .models import tokenize
from .lexical import lexical_search

USER_MODES={"Search","Quotes","Explore","Topics","Ask"}
SCIENCE_MODES={"Standard","Exhaustive","Contradict","Explore","Strict Sources","Low Compute"}

def scope(s, identity, collection=None):
    cols={c.id:c for c in s.scalars(select(Collection).where(Collection.tenant==identity["tenant"])) if can_read(c,identity)}
    documents = [d for d in s.scalars(select(Document).where(Document.tenant==identity["tenant"],Document.status=="ready")) if d.collection_id in cols and can_read(d,identity) and (not collection or d.collection_id==collection)]
    readable_articles={(d.collection_id,d.metadata_json.get("external_id")) for d in documents if d.metadata_json.get("kind")=="article"}
    return [d for d in documents if d.metadata_json.get("kind")!="comment" or (d.collection_id,d.metadata_json.get("parent_external_id")) in readable_articles]

def bm25(query, texts):
    tokens=[tokenize(t) for t in texts]
    if not tokens: return []
    df=Counter(t for row in tokens for t in set(row)); avg=sum(map(len,tokens))/len(tokens) or 1
    q=set(tokenize(query)); scores=[]
    for row in tokens:
        tf=Counter(row); score=0
        for term in q:
            if not tf[term]: continue
            idf=math.log(1+(len(tokens)-df[term]+.5)/(df[term]+.5))
            score += idf*tf[term]*2.5/(tf[term]+1.5*(.25+.75*len(row)/avg))
        scores.append(score)
    return scores

def ranks(scores):
    return {key:i+1 for i,(key,_) in enumerate(sorted(scores.items(),key=lambda pair:(-pair[1],pair[0])))}

class SearchEngine:
    def __init__(self, settings, embedder, vectors, reranker):
        self.settings,self.embedder,self.vectors,self.reranker=settings,embedder,vectors,reranker
        self.cache={}
    def clear(self): self.cache.clear()
    def search(self, s, identity, req):
        docs=scope(s,identity,req.collection_id)
        if req.document_ids is not None:
            selected_documents=set(req.document_ids)
            docs=[d for d in docs if d.id in selected_documents]
        if req.content_kind:
            docs=[d for d in docs if d.metadata_json.get("kind","document")==req.content_kind]
        if req.parent_external_id:
            docs=[d for d in docs if d.metadata_json.get("parent_external_id")==req.parent_external_id]
        if req.exclude_external_id:
            docs=[d for d in docs if d.metadata_json.get("external_id")!=req.exclude_external_id]
        docmap={d.id:d for d in docs}
        if any(d.provenance.get("embedding_fingerprint") != self.embedder.fingerprint for d in docs):
            raise HTTPException(409,"Corpus contains another embedding version; restore its profile or reingest sources")
        passage_count=s.scalar(select(func.count()).select_from(Chunk).where(Chunk.document_id.in_(docmap))) or 0
        # ACL-scoped corpus fingerprint; no cross-user or stale-grant cache reuse.
        key=hashlib.sha256(json.dumps([identity,req.model_dump(),[(d.id,d.sha256,d.provenance) for d in docs],[(c.id,c.name,c.aliases) for c in s.scalars(select(Concept).where(Concept.tenant==identity['tenant']))]],sort_keys=True).encode()).hexdigest()
        if key in self.cache: return json.loads(json.dumps(self.cache[key]))
        low=req.scientific_mode=="Low Compute"
        exhaustive=req.scientific_mode=="Exhaustive"
        candidate_limit=min(2000 if exhaustive else 200,passage_count)
        lexical,lexical_method=lexical_search(s,req.query,list(docmap),max(1,candidate_limit))
        dense,sparse={},{}
        if passage_count and not low:
            vec,sp=self.embedder.query(req.query)
            dense,sparse=self.vectors.search(identity["tenant"],list(docmap),vec,sp,max(1,candidate_limit),exact=exhaustive)
            dense={k:v for k,v in dense.items() if v>0}
        concepts=list(s.scalars(select(Concept).where(Concept.tenant==identity["tenant"])))
        selected={c.id:c for c in concepts if c.id==req.concept_id or any(a.lower() in req.query.lower() for a in [c.name,*c.aliases])}
        if req.concept_id and req.concept_id not in {c.id for c in concepts}: raise HTTPException(404,"Concept unavailable")
        tagmap={}
        for tag in s.scalars(select(Tag).where(Tag.document_id.in_(docmap),Tag.concept_id.in_(selected))):
            tagmap.setdefault(tag.document_id,[]).append(selected[tag.concept_id].name)
        concept_rows=list(s.scalars(select(Chunk).options(defer(Chunk.vector)).where(Chunk.document_id.in_(tagmap)).order_by(Chunk.id).limit(candidate_limit))) if tagmap else []
        cscores={c.id:1.0 for c in concept_rows}
        candidate_ids=set(lexical)|set(dense)|set(sparse)|set(cscores)
        rows=list(s.scalars(select(Chunk).options(defer(Chunk.vector)).where(Chunk.id.in_(candidate_ids),Chunk.document_id.in_(docmap)))) if candidate_ids else []
        # Recheck all vector hits in SQL against the current authorized scope.
        allowed={c.id for c in rows}
        lexical={k:v for k,v in lexical.items() if k in allowed}
        dense={k:v for k,v in dense.items() if k in allowed}
        sparse={k:v for k,v in sparse.items() if k in allowed}
        lexical_signal="lexical_bm25" if s.get_bind().dialect.name=="sqlite" else "lexical_ts_rank"
        signals={lexical_signal:lexical,"dense_cosine":dense,"sparse_dot":sparse,"concept_manual":cscores}
        rankings={name:ranks(values) for name,values in signals.items()}
        weights={lexical_signal:1.,"dense_cosine":1.,"sparse_dot":.6,"concept_manual":.5}
        combined={}
        for name,ranking in rankings.items():
            # Progressive top-N fusion except in exhaustive traversal.
            for cid,rank in ranking.items():
                if rank<=candidate_limit: combined[cid]=combined.get(cid,0)+weights[name]/(60+rank)
        rowmap={c.id:c for c in rows}
        if req.concept_id:
            combined={cid:v for cid,v in combined.items() if rowmap[cid].document_id in tagmap}
        if req.scientific_mode=="Strict Sources" or req.mode=="Quotes":
            phrase=req.query.casefold()
            combined={cid:v for cid,v in combined.items() if phrase in rowmap[cid].text.casefold()}
        warnings=[]
        if exhaustive and passage_count>candidate_limit: warnings.append("Exhaustive uses exact vector search with a bounded 2000-candidate window per signal; it is not a systematic-review completeness guarantee")
        if not self.embedder.manifest.get("semantic"): warnings.append("DEMO: hashed lexical vectors; no neural semantic model loaded")
        if req.scientific_mode=="Contradict":
            # Transparent multilingual negation heuristic. This is NOT NLI.
            negatives=re.compile(r"\b(no|not|never|without|aucun|pas|jamais|sans|cependant|however|mais|but)\b",re.I)
            opposition={cid:1.0 for cid in combined if negatives.search(rowmap[cid].text)}
            for cid in opposition: combined[cid]+=0.005
            warnings.append("Contradict uses negation markers; it does not verify logical contradiction")
        else: opposition={}
        ordered=sorted(combined,key=lambda cid:(-combined[cid],cid))
        rerank_scores={}
        if req.rerank and not low:
            if self.reranker.model and ordered:
                window=ordered if exhaustive else ordered[:50]
                rerank_scores=dict(zip(window,self.reranker.score(req.query,[rowmap[cid].text for cid in window])))
                ordered=sorted(window,key=lambda cid:(-rerank_scores[cid],cid))+ordered[len(window):]
            else: warnings.append("Reranking requested but no local model configured")
        if req.mode=="Explore" or req.scientific_mode=="Explore":
            # Round robin across sources, preserving rank within each source.
            groups={}
            for cid in ordered: groups.setdefault(rowmap[cid].document_id,[]).append(cid)
            ordered=[group[i] for i in range(max(map(len,groups.values()),default=0)) for group in groups.values() if i<len(group)]
        page_ids={rowmap[cid].page_id for cid in ordered[:req.limit]}
        pages={p.id:p for p in s.scalars(select(Page).where(Page.id.in_(page_ids)))}
        results=[]
        for cid in ordered[:req.limit]:
            c=rowmap[cid]; d=docmap[c.document_id]; p=pages[c.page_id]
            assert p.text[c.start:c.end]==c.text
            results.append({"chunk_id":cid,"document_id":d.id,"title":d.title,"external_id":d.metadata_json.get("external_id"),"kind":d.metadata_json.get("kind","document"),"page":p.number,"page_label":p.label,"quote":c.text,"span":{"start":c.start,"end":c.end},"source_sha256":d.sha256,"citation_url":f"/api/documents/{d.id}/pages/{p.number}","signals":{name:{"score":values.get(cid),"rank":rankings[name].get(cid)} for name,values in signals.items()},"matched_terms":sorted(set(tokenize(req.query))&set(tokenize(c.text))),"concepts":tagmap.get(d.id,[]),"rrf":combined[cid],"reranker_score":rerank_scores.get(cid),"counterargument_marker":cid in opposition,"provenance":d.provenance})
        result={"results":results,"warnings":warnings,"mode":req.mode,"scientific_mode":req.scientific_mode,"coverage":{"authorized_documents":len(docs),"indexed_passages":passage_count,"loaded_passages":len(rows),"candidates":len(combined),"returned":len(results),"full_vector_traversal":exhaustive and not low,"truncated_output":len(ordered)>req.limit},"explanation":"Scores rank retrieval relevance; never probabilities of truth. Quotes are unchanged spans of extracted source text.","pipeline":{"fusion":"weighted RRF k=60", "weights":weights,"vector_model":self.embedder.manifest,"reranker":self.reranker.manifest,"chunk_chars":self.settings.chunk_chars,"candidate_limit":candidate_limit,"lexical":lexical_method,"candidate_bounded":True}}
        if req.mode=="Ask": result["answer"]={"type":"extractive","text":"Passages sources pertinents ; aucune synthèse générée.","citations":[r["chunk_id"] for r in results]}
        if req.mode=="Topics": result["topics"]=[{"name":c.name,"id":c.id,"aliases":c.aliases,"parent_id":c.parent_id} for c in concepts]
        if len(self.cache)>=128: self.cache.pop(next(iter(self.cache)))
        self.cache[key]=json.loads(json.dumps(result))
        return result
