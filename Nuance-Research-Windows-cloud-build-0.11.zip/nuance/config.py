import os, json, hashlib
from pathlib import Path
from dataclasses import dataclass, field

@dataclass
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", "sqlite:///./data/nuance.db"))
    data_dir: str = field(default_factory=lambda: os.getenv("DATA_DIR", "./data"))
    qdrant_url: str = field(default_factory=lambda: os.getenv("QDRANT_URL", ""))
    qdrant_key: str = field(default_factory=lambda: os.getenv("QDRANT_API_KEY", ""))
    embedder: str = field(default_factory=lambda: os.getenv("EMBEDDER", "sentence-transformers"))
    model_path: str = field(default_factory=lambda: os.getenv("MODEL_PATH", "./models/embedding"))
    reranker_path: str = field(default_factory=lambda: os.getenv("RERANKER_PATH", ""))
    extractor: str = field(default_factory=lambda: os.getenv("EXTRACTOR", "pypdf"))
    max_upload_mb: int = 20
    max_pages: int = 500
    max_chars: int = 2_000_000
    # Legacy configuration retained for compatibility; indexed search has no scope cap.
    max_scope: int = field(default_factory=lambda: int(os.getenv("MAX_SCOPE", "100000")))
    model_idle_seconds: int = field(default_factory=lambda: max(5,int(os.getenv("NUANCE_MODEL_IDLE_SECONDS","30"))))
    cpu_threads: int = field(default_factory=lambda: max(1,int(os.getenv("NUANCE_CPU_THREADS","2"))))
    worker_memory_mb: int = field(default_factory=lambda: max(256,int(os.getenv("NUANCE_WORKER_MEMORY_MB","3072"))))
    worker_timeout_seconds: int = field(default_factory=lambda: max(30,int(os.getenv("NUANCE_WORKER_TIMEOUT_SECONDS","180"))))
    isolate_extraction: bool = False
    chunk_chars: int = 900
    keys: dict = field(default_factory=lambda: json.loads(os.getenv("NUANCE_API_KEYS", "{}")))
    grobid_url: str = field(default_factory=lambda: os.getenv('GROBID_URL',''))
    llm_url: str = field(default_factory=lambda: os.getenv("LLM_URL", ""))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", ""))

    def validate(self):
        if not self.keys or any(len(k) < 24 for k in self.keys):
            raise ValueError("NUANCE_API_KEYS: configure random bearer keys of at least 24 characters")
        for identity in self.keys.values():
            if not all(identity.get(k) for k in ("tenant", "user", "role")):
                raise ValueError("Each key needs tenant, user, role")
            if identity["role"] not in {"admin", "editor", "reader"}:
                raise ValueError("Invalid role")
        if self.embedder not in {"demo-hash", "sentence-transformers", "bge-m3", "qwen"}:
            raise ValueError("Unknown embedder")
        if self.extractor not in {"pypdf", "docling"}:
            raise ValueError("Unknown extractor")
        Path(self.data_dir).mkdir(parents=True, exist_ok=True)

    def model_manifest(self):
        if self.embedder == "demo-hash":
            model = {"id": "nuance/demo-hash", "revision": "sha256-token-v1", "license": "MIT",
                     "semantic": False, "training_data": "none; deterministic lexical hashing"}
        else:
            manifest_path = Path(self.model_path) / "nuance-model.json"
            model = json.loads(manifest_path.read_text())
            if model.get("backend") != self.embedder:
                raise ValueError("Model manifest/backend mismatch")
            # Verify the local snapshot before trusting the recorded revision.
            if model.get("artifact_sha256") != tree_digest(Path(self.model_path)):
                raise ValueError("Model files changed; regenerate the verified model manifest")
            model["semantic"] = True
        return model


def tree_digest(path):
    digest = hashlib.sha256()
    for p in sorted(path.rglob("*")):
        if p.is_file() and p.name != "nuance-model.json":
            digest.update(str(p.relative_to(path)).encode())
            with p.open("rb") as f:
                for part in iter(lambda: f.read(1024 * 1024), b""):
                    digest.update(part)
    return digest.hexdigest()
