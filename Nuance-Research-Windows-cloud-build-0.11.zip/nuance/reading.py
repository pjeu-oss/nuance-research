"""Exact, private reading annotations. Original source bytes are never modified."""
import json,re,unicodedata,io,zipfile
from fastapi import HTTPException,Request,Query
from fastapi.responses import Response
from pydantic import BaseModel,Field
from sqlalchemy import select
from .db import ResearchRecord,Page,audit,now
from .security import require_editor
from .retrieval import scope

class HighlightRequest(BaseModel):
    reference_id:str
    page:int=Field(ge=1)
    source_sha256:str=Field(min_length=64,max_length=64)
    quote:str=Field(min_length=1,max_length=20000)
    start:int|None=Field(default=None,ge=0)
    end:int|None=Field(default=None,ge=1)
    color:str=Field(default='sage',pattern='^(sage|sand|blue|rose)$')
    note:str=Field(default='',max_length=4000)
class AnnotationUpdate(BaseModel):
    revision:int=Field(ge=1)
    note:str=Field(default='',max_length=4000)
    color:str=Field(default='sage',pattern='^(sage|sand|blue|rose)$')
class AnnotationRevision(BaseModel):
    revision:int=Field(ge=1)

def quote_key(text):
    chars=[];mapping=[]
    for pos,char in enumerate(text):
        if char=='\u00ad':continue
        if char=='-' and re.match(r'\s*\n',text[pos+1:pos+8]):continue
        for c in unicodedata.normalize('NFKC',char):
            if not c.isspace():chars.append(c);mapping.append(pos)
    return ''.join(chars),mapping

def locate_quote(text,quote,start=None,end=None):
    if start is not None or end is not None:
        if start is None or end is None or not 0<=start<end<=len(text) or text[start:end]!=quote:raise HTTPException(422,'Selection does not match source text')
        return start,end,'exact-text'
    pos=text.find(quote)
    if pos>=0 and text.find(quote,pos+1)<0:return pos,pos+len(quote),'exact-text'
    key,positions=quote_key(text);wanted,_=quote_key(quote)
    pos=key.find(wanted) if wanted else -1
    if pos<0 or key.find(wanted,pos+1)>=0:raise HTTPException(422,'Selection is ambiguous or differs from extracted text. Use the text view to highlight this passage.')
    return positions[pos],positions[pos+len(wanted)-1]+1,'pdf-text-normalized-to-exact-source'

def install_reading(app,Session,lock,identity,get_doc,visible_refs,records,dto):
    def ref(s,i,rid):
        r=s.get(ResearchRecord,rid)
        if r and (r.tenant!=i['tenant'] or r.owner!=i['user'] or r.kind not in {'reference','reference-trash'}):r=None
        if not r or not r.payload.get('document_id'):raise HTTPException(404,'Attach a document before reading this reference')
        d=get_doc(s,r.payload['document_id'],i)
        return r,d
    def visible(s,i,kind='citation',project_ids=None,rid=None,limit=None,offset=0):
        members=None
        if project_ids is not None:
            projects={p.id:p for p in records(s,i,'project')};members=set()
            for pid in project_ids:
                if pid not in projects:raise HTTPException(404,'Project unavailable')
                members.update(projects[pid].payload.get('reference_ids',[]))
        docmap={d.id:d for d in scope(s,i)}
        refmap={r.id:r for kind_name in ['reference','reference-trash'] for r in records(s,i,kind_name) if r.payload.get('document_id') in docmap and (members is None or r.id in members) and (rid is None or r.id==rid)}
        if not refmap:return []
        query=select(ResearchRecord).where(ResearchRecord.tenant==i['tenant'],ResearchRecord.owner==i['user'],ResearchRecord.kind==kind,ResearchRecord.payload['reference_id'].as_string().in_(list(refmap))).order_by(ResearchRecord.updated_at.desc(),ResearchRecord.id)
        if limit is not None:query=query.offset(offset).limit(limit)
        result=[]
        for c in s.scalars(query):
            r=refmap[c.payload['reference_id']];d=docmap[r.payload['document_id']]
            if d.sha256!=c.payload['source_sha256']:continue
            result.append({**dto(c),'reference':dto(r)})
        return result
    def own(s,i,cid,kind='citation'):
        c=next((c for c in records(s,i,kind) if c.id==cid),None)
        if not c:raise HTTPException(404,'Citation unavailable')
        ref(s,i,c.payload['reference_id']);return c
    @app.get('/api/research/reader/{rid}')
    def reader(rid:str,request:Request):
        with Session() as s:
            i=identity(request);r,d=ref(s,i,rid)
            pages=list(s.scalars(select(Page.number).where(Page.document_id==d.id).order_by(Page.number)))
            return {'reference':dto(r),'document_id':d.id,'filename':d.filename,'source_sha256':d.sha256,'pages':pages,'page_semantics':d.provenance.get('page_semantics','logical page'),'highlights':visible(s,i,rid=rid)}
    @app.post('/api/research/citations')
    def highlight(req:HighlightRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r,d=ref(s,i,req.reference_id)
            if d.sha256!=req.source_sha256:raise HTTPException(409,'Source version changed; reopen document')
            page=s.scalar(select(Page).where(Page.document_id==d.id,Page.number==req.page))
            if not page:raise HTTPException(404,'Page unavailable')
            start,end,method=locate_quote(page.text,req.quote,req.start,req.end)
            if end-start>20000:raise HTTPException(422,'Highlight at most 20,000 source characters')
            for c in records(s,i,'citation'):
                if (c.payload.get('document_id'),c.payload.get('page'),c.payload.get('start'),c.payload.get('end'),c.payload.get('source_sha256'))==(d.id,page.number,start,end,d.sha256):return {**dto(c),'reference':dto(r),'existing':True}
            c=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='citation',payload={'folder':'citations','reference_id':r.id,'document_id':d.id,'page':page.number,'page_label':page.label,'start':start,'end':end,'quote':page.text[start:end],'source_sha256':d.sha256,'source_filename':d.filename,'source_provenance':d.provenance,'bibliography_snapshot':dict(r.payload),'color':req.color,'note':req.note,'anchoring':method,'created_at':now()});s.add(c);s.flush();audit(s,i,'citation.highlight',c.id);return {**dto(c),'reference':dto(r),'existing':False}
    @app.get('/api/research/citations')
    def citations(request:Request,project_ids:list[str]|None=Query(default=None),limit:int=Query(default=200,ge=1,le=500),offset:int=Query(default=0,ge=0,le=1000000)):
        with Session() as s:return visible(s,identity(request),project_ids=project_ids,limit=limit,offset=offset)
    @app.get('/api/research/citations/trash')
    def citation_trash(request:Request):
        with Session() as s:return visible(s,identity(request),'citation-trash')
    @app.put('/api/research/citations/{cid}')
    def update(cid:str,req:AnnotationUpdate,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            c=own(s,i,cid)
            if c.revision!=req.revision:raise HTTPException(409,'Citation changed; reload')
            c.payload={**c.payload,'note':req.note,'color':req.color};c.revision+=1;c.updated_at=now();audit(s,i,'citation.annotate',cid);return dto(c)
    @app.post('/api/research/citations/{cid}/archive')
    def archive(cid:str,req:AnnotationRevision,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            c=own(s,i,cid)
            if c.revision!=req.revision:raise HTTPException(409,'Citation changed; reload')
            c.kind='citation-trash';c.revision+=1;c.updated_at=now();audit(s,i,'citation.archive',cid);return dto(c)
    @app.post('/api/research/citations/{cid}/restore')
    def restore(cid:str,req:AnnotationRevision,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            c=own(s,i,cid,'citation-trash')
            if c.revision!=req.revision:raise HTTPException(409,'Citation changed; reload')
            c.kind='citation';c.revision+=1;c.updated_at=now();audit(s,i,'citation.restore',cid);return dto(c)
    @app.get('/api/research/citations-export.zip')
    def export(request:Request,project_ids:list[str]|None=Query(default=None)):
        with Session.begin() as s:
            i=identity(request);items=visible(s,i,project_ids=project_ids);audit(s,i,'citation.export','zip')
        data=io.BytesIO()
        with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as z:
            for c in items:
                z.writestr('citations/'+c['id']+'.json',json.dumps(c,ensure_ascii=False,indent=2))
                z.writestr('citations/'+c['id']+'.md',c['quote']+'\n\nSource : '+c['reference']['title']+' · page '+str(c['page'])+'\nSHA-256 : '+c['source_sha256']+'\n\n'+c['note'])
        return Response(data.getvalue(),media_type='application/zip',headers={'Content-Disposition':'attachment; filename="citations.zip"'})
