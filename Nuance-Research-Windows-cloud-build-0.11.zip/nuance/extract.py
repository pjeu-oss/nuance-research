from io import BytesIO
import re, zipfile
from xml.etree import ElementTree
from pathlib import Path

class ExtractionError(ValueError): pass

def extract(data, filename, settings, temp_path=None):
    if getattr(settings,'isolate_extraction',False) and temp_path is not None:
        import os,sys,json
        from .resource_guard import spawn_worker,read_reply,stop_worker
        env=os.environ.copy();env['PYTHONPATH']=str(Path(__file__).resolve().parent.parent)+os.pathsep+env.get('PYTHONPATH','')
        command=([sys.executable,'--nuance-worker','extraction'] if getattr(sys,'frozen',False) else [sys.executable,'-u','-m','nuance.extraction_worker'])
        process=spawn_worker(command,env,settings,'extraction')
        try:
            fields={k:getattr(settings,k) for k in ('extractor','max_upload_mb','max_pages','max_chars')}
            process.stdin.write(json.dumps({'path':str(Path(temp_path).resolve()),'filename':filename,'settings':fields})+'\n');process.stdin.flush()
            reply=read_reply(process,timeout=getattr(settings,'worker_timeout_seconds',180))
            return reply['pages'],reply['metadata']
        except RuntimeError as exc:raise ExtractionError(str(exc)) from exc
        finally:
            stop_worker(process);process.stdin.close();process.stdout.close()
    ext = Path(filename).suffix.lower()
    metadata, warnings = {}, []
    if ext == ".pdf" and not data.startswith(b"%PDF-"):
        raise ExtractionError("Invalid PDF signature")
    if ext == ".pdf" and settings.extractor == "docling":
        import os
        from docling.document_converter import DocumentConverter, PdfFormatOption
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import PdfPipelineOptions
        artifacts = os.getenv("DOCLING_ARTIFACTS_PATH", "")
        if not artifacts or not Path(artifacts).is_dir():
            raise ExtractionError("Provision local Docling artifacts and set DOCLING_ARTIFACTS_PATH")
        options = PdfPipelineOptions(artifacts_path=Path(artifacts), do_ocr=True)
        doc = DocumentConverter(format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=options)}).convert(str(temp_path)).document
        grouped = {}
        for item, _ in doc.iterate_items():
            if not getattr(item, "text", ""): continue
            for prov in getattr(item, "prov", []):
                span = getattr(prov, "charspan", None)
                text = item.text[span[0]:span[1]] if span else item.text
                grouped.setdefault(prov.page_no, []).append(text)
        count = max(doc.pages) if doc.pages else 0
        pages = [(i, "\n".join(grouped.get(i, [])), str(i)) for i in range(1, count+1)]
        warnings.append("Docling layout reconstruction; quotes are exact spans of the extracted page text")
    elif ext == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(BytesIO(data))
        if reader.is_encrypted: raise ExtractionError("Encrypted PDF unsupported")
        if len(reader.pages) > settings.max_pages: raise ExtractionError("Page limit exceeded")
        m = reader.metadata or {}
        metadata = {"title": str(m.get("/Title", "")), "authors": str(m.get("/Author", "")), "pdf_creation_date": str(m.get("/CreationDate", ""))}
        labels = reader.page_labels
        pages = [(i+1, p.extract_text() or "", labels[i]) for i,p in enumerate(reader.pages)]
    elif ext in {".txt", ".md"}:
        text = data.decode("utf-8-sig")
        pages = [(i+1, t, str(i+1)) for i,t in enumerate(text.split("\f"))]
        warnings.append("Logical pages separated by form feed; no original print pagination")
    elif ext == ".docx":
        with zipfile.ZipFile(BytesIO(data)) as z:
            info = z.getinfo("word/document.xml")
            if info.file_size > settings.max_chars * 4: raise ExtractionError("DOCX expansion limit exceeded")
            xml = z.read(info)
        node = ElementTree.fromstring(xml)
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        text = "\n".join("".join(t.text or "" for t in p.findall(".//w:t", ns)) for p in node.findall(".//w:p", ns))
        pages = [(1, text, "logical-1")]
        warnings.append("DOCX: logical page only; Word pagination unavailable")
    else: raise ExtractionError("Supported: PDF, TXT, Markdown, DOCX")
    if not pages or len(pages) > settings.max_pages: raise ExtractionError("Page limit exceeded or empty document")
    if sum(len(t) for _,t,_ in pages) > settings.max_chars: raise ExtractionError("Extracted text limit exceeded")
    if not any(t.strip() for _,t,_ in pages): raise ExtractionError("No text: scanned PDFs require the optional Docling/OCR profile")
    empty = [n for n,t,_ in pages if not t.strip()]
    if empty: warnings.append(f"Empty pages: {empty}; content may require OCR")
    from .metadata import infer_bibliography,pdf_front
    fonts=[];raw=metadata;front=pages[:3]
    if ext=='.pdf':
        try:front,raw,fonts=pdf_front(data)
        except (ValueError,KeyError,AttributeError):pass
    metadata['bibliography']=infer_bibliography(front,filename,raw,fonts)
    if metadata['bibliography']['fields'].get('doi'):metadata['doi_candidate']=metadata['bibliography']['fields']['doi']
    metadata["extraction_warnings"] = warnings
    return pages, metadata

def chunks(text, size):
    start = 0
    while start < len(text):
        end = min(start+size, len(text))
        if end < len(text):
            split = text.rfind(" ", start + size//2, end)
            if split > start: end = split+1
        if text[start:end].strip(): yield start, end, text[start:end]
        start = end
