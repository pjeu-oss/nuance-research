"""Reusable application workflows. No dependence on Expo or a particular CMS."""
import hashlib,json
from io import BytesIO
from typing import Literal
from fastapi import Request,HTTPException,UploadFile
from pydantic import BaseModel,Field,model_validator
from sqlalchemy import select
from .db import Document,Concept,Page,audit
from .security import require_editor,can_read
from .retrieval import scope

class ContentInput(BaseModel):
    collection_id: str
    external_id: str = Field(min_length=1,max_length=200,pattern=r"^[a-zA-Z0-9_.:-]+$")
    kind: Literal["document","article","comment"] = "article"
    title: str = Field(min_length=1,max_length=300)
    text: str = Field(min_length=1,max_length=200000)
    readers: list[str] | None = Field(default=None,max_length=100)
    parent_external_id: str | None = Field(default=None,max_length=200)
    @model_validator(mode="after")
    def parent(self):
        if not self.text.strip(): raise ValueError("Empty text")
        if self.kind=="comment" and not self.parent_external_id: raise ValueError("A comment needs a parent article")
        if self.kind!="comment" and self.parent_external_id: raise ValueError("Only comments have a parent")
        return self

class ContentDelete(BaseModel):
    collection_id: str
    external_id: str = Field(min_length=1,max_length=200)
    kind: Literal["document","article","comment"]

class ArticleAssist(BaseModel):
    title: str = Field(min_length=1,max_length=300)
    body: str = Field(default="",max_length=30000)
    query: str | None = Field(default=None,min_length=1,max_length=2000)
    collection_id: str | None = None
    external_id: str | None = None
    limit: int = Field(default=10,ge=1,le=50)
    counterarguments: bool = False
    rerank: bool = False

class CommentRanking(BaseModel):
    collection_id: str
    article_external_id: str = Field(min_length=1,max_length=200)
    query: str | None = Field(default=None,min_length=1,max_length=2000)
    limit: int = Field(default=10,ge=1,le=100)
    rerank: bool = False
    low_compute: bool = False

def install_integrations(app,Session,lock,searcher,identity,get_collection,get_doc,ingest,remove,SearchRequest):
    def find_article(s,i,collection_id,external_id):
        get_collection(s,collection_id,i)
        d=s.scalar(select(Document).where(Document.tenant==i["tenant"],Document.collection_id==collection_id,Document.status=="ready",Document.metadata_json["kind"].as_string()=="article",Document.metadata_json["external_id"].as_string()==external_id))
        if not d: raise HTTPException(404,"Article unavailable")
        return get_doc(s,d.id,i)

    @app.post("/api/content")
    def upsert(req:ContentInput,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session() as s:
            get_collection(s,req.collection_id,i,True)
            if req.kind=="comment":find_article(s,i,req.collection_id,req.parent_external_id)
            existing=list(s.scalars(select(Document).where(Document.tenant==i["tenant"],Document.collection_id==req.collection_id,Document.status=="ready",Document.metadata_json["kind"].as_string()==req.kind,Document.metadata_json["external_id"].as_string()==req.external_id)))
            if len(existing)>1:raise HTTPException(409,"Duplicate application IDs; reconcile content")
            old=get_doc(s,existing[0].id,i,True) if existing else None
            meta={"title":req.title,"kind":req.kind,"external_id":req.external_id}
            if req.parent_external_id:meta["parent_external_id"]=req.parent_external_id
            if old and old.metadata_json.get("parent_external_id")!=req.parent_external_id:raise HTTPException(409,"A comment cannot change parent")
            digest=hashlib.sha256(req.text.encode()).hexdigest()
            if old and old.sha256==digest and all(old.metadata_json.get(k)==v for k,v in meta.items()) and old.provenance["embedding_fingerprint"]==searcher.embedder.fingerprint and (req.readers is None or req.readers==old.readers):
                audit(s,i,"content.unchanged",old.id);s.commit()
                return {"document_id":old.id,"external_id":req.external_id,"kind":req.kind,"changed":False}
            old_id=old.id if old else None
        # Reacquire and recheck after preparation; a racing update receives 409.
        with lock,Session() as s:
            # Detect a writer that won the race between validation and ingestion.
            active=s.scalar(select(Document).where(Document.tenant==i["tenant"],Document.collection_id==req.collection_id,Document.status=="ready",Document.metadata_json["kind"].as_string()==req.kind,Document.metadata_json["external_id"].as_string()==req.external_id))
            if (active.id if active else None)!=old_id:raise HTTPException(409,"Concurrent update; retry synchronization")
            result=ingest(request,UploadFile(filename=req.kind+".txt",file=BytesIO(req.text.encode())),req.collection_id,json.dumps(meta),replace_id=old_id,readers=req.readers)
            return {"document_id":result["id"],"external_id":req.external_id,"kind":req.kind,"changed":True,"previous_document_id":old_id}

    @app.post("/api/content/delete")
    def delete_content(req:ContentDelete,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session() as s:
            get_collection(s,req.collection_id,i,True)
            docs=list(s.scalars(select(Document).where(Document.tenant==i["tenant"],Document.collection_id==req.collection_id)))
            targets=[d for d in docs if d.metadata_json.get("kind")==req.kind and d.metadata_json.get("external_id")==req.external_id]
            if req.kind=="article":targets.extend(d for d in docs if d.metadata_json.get("kind")=="comment" and d.metadata_json.get("parent_external_id")==req.external_id)
            for d in targets:get_doc(s,d.id,i,True)
            for d in targets:remove(d.id,request)
            return {"external_id":req.external_id,"deleted_versions":len(targets)}

    @app.post("/api/assist/article")
    def assist(req:ArticleAssist,request:Request):
        i=identity(request)
        with lock,Session.begin() as s:
            if req.collection_id:get_collection(s,req.collection_id,i)
            query=req.query or (req.title+"\n"+req.body)[:2000]
            search_req=SearchRequest(query=query,collection_id=req.collection_id,exclude_external_id=req.external_id,limit=req.limit,scientific_mode="Contradict" if req.counterarguments else "Standard",rerank=req.rerank)
            result={"results":[],"warnings":[]} 
            # Draft assistance uses research documents/articles; never inject comments as evidence.
            # Re-run on each permitted kind and fuse results so comments cannot steal the candidate window.
            combined={}
            for kind in ("document","article"):
                part=searcher.search(s,i,search_req.model_copy(update={"content_kind":kind,"exclude_external_id":req.external_id if kind=="article" else None}))
                result["warnings"]=list(dict.fromkeys([*result["warnings"],*part["warnings"]]))
                for rank,row in enumerate(part["results"],1):
                    combined[row["chunk_id"]]=(row,1/(60+rank))
            result["results"]=[v[0] for v in sorted(combined.values(),key=lambda v:-v[1])][:req.limit]
            text=(req.title+" "+req.body).casefold()
            suggestions=[{"id":c.id,"name":c.name,"matched_aliases":[a for a in [c.name,*c.aliases] if a.casefold() in text],"method":"manual-taxonomy lexical match"} for c in s.scalars(select(Concept).where(Concept.tenant==i["tenant"])) if any(a.casefold() in text for a in [c.name,*c.aliases])]
            audit(s,i,"article.assist")
            return {"query_used":query,"draft_stored":False,"sources":result["results"],"concept_suggestions":suggestions,"warnings":result["warnings"],"explanation":"Related source passages; document/article rank lists fused with RRF k=60, signals computed within each kind. No automatic fact checking or generated prose. Draft text is used in memory only."}

    @app.post("/api/comments/rank")
    def comments(req:CommentRanking,request:Request):
        i=identity(request)
        with lock,Session.begin() as s:
            parent=find_article(s,i,req.collection_id,req.article_external_id)
            p=s.scalar(select(Page).where(Page.document_id==parent.id).order_by(Page.number))
            query=req.query or (parent.title+"\n"+(p.text if p else ""))[:2000]
            search_req=SearchRequest(query=query,collection_id=req.collection_id,content_kind="comment",parent_external_id=req.article_external_id,limit=500,scientific_mode="Low Compute" if req.low_compute else "Standard",rerank=req.rerank)
            result=searcher.search(s,i,search_req)
            docs={d.id:d for d in scope(s,i,req.collection_id)};seen=set();ranked=[]
            for row in result["results"]:
                if row["document_id"] in seen:continue
                seen.add(row["document_id"]);d=docs[row["document_id"]]
                ranked.append({"external_id":d.metadata_json["external_id"],"document_id":d.id,"relevant_excerpt":row["quote"],"evidence":row})
                if len(ranked)>=req.limit:break
            audit(s,i,"comments.rank",parent.id)
            return {"article_external_id":req.article_external_id,"query_used":query,"comments":ranked,"warnings":result["warnings"],"coverage":result["coverage"],"explanation":"Order measures relevance to the article/query. It does not measure truth, civility, popularity or author quality. One best passage per comment; candidate window can omit comments."}
