from qdrant_client import QdrantClient, models as qm

class VectorStore:
    def __init__(self, settings, embedder):
        self.client = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_key or None, timeout=30) if settings.qdrant_url else QdrantClient(path=settings.data_dir+"/qdrant")
        self.name="nuance_"+embedder.fingerprint
        self.sparse=embedder.backend == "bge-m3"
        if not self.client.collection_exists(self.name):
            self.client.create_collection(self.name, vectors_config={"dense":qm.VectorParams(size=embedder.dimension, distance=qm.Distance.COSINE)}, sparse_vectors_config={"sparse":qm.SparseVectorParams()} if self.sparse else None)
            # Payload indexes matter on the server; local Qdrant warns that they are unused.
            if settings.qdrant_url:
                for field in ["tenant", "document"]:
                    self.client.create_payload_index(self.name, field, qm.PayloadSchemaType.KEYWORD)
    def upsert(self, chunks, tenant, document, sparse):
        points=[]
        for c,sp in zip(chunks,sparse):
            vectors={"dense":c.vector}
            if self.sparse: vectors["sparse"]=qm.SparseVector(indices=list(sp),values=list(sp.values()))
            points.append(qm.PointStruct(id=c.id, vector=vectors, payload={"tenant":tenant,"document":document}))
        for i in range(0,len(points),128):
            self.client.upsert(self.name, points[i:i+128], wait=True)
    def search(self, tenant, documents, vector, sparse, limit, exact=False):
        if not documents: return {},{}
        f=qm.Filter(must=[qm.FieldCondition(key="tenant",match=qm.MatchValue(value=tenant)),qm.FieldCondition(key="document",match=qm.MatchAny(any=documents))])
        dense=self.client.query_points(self.name,query=vector,using="dense",query_filter=f,limit=limit,with_payload=False,search_params=qm.SearchParams(exact=exact)).points
        sp=self.client.query_points(self.name,query=qm.SparseVector(indices=list(sparse),values=list(sparse.values())),using="sparse",query_filter=f,limit=limit,with_payload=False,search_params=qm.SearchParams(exact=exact)).points if self.sparse and sparse else []
        return {str(p.id):p.score for p in dense}, {str(p.id):p.score for p in sp}
    def delete(self, tenant, document):
        self.client.delete(self.name,qm.FilterSelector(filter=qm.Filter(must=[qm.FieldCondition(key="tenant",match=qm.MatchValue(value=tenant)),qm.FieldCondition(key="document",match=qm.MatchValue(value=document))])),wait=True)
    def close(self): self.client.close()
