from .resource_guard import spawn_worker,read_reply
"""Release neural-model memory after inactivity; reuse the exact existing profile."""
import hashlib,json,os,subprocess,sys,threading
from pathlib import Path
from functools import lru_cache

class IdleEmbedder:
    def __init__(self,settings):
        self.settings=settings;self.backend=settings.embedder;self.manifest=settings.model_manifest()
        pooling=Path(settings.model_path)/'1_Pooling/config.json'
        if not pooling.exists():raise ValueError('Idle worker requires a SentenceTransformer pooling configuration')
        self.dimension=json.loads(pooling.read_text())['word_embedding_dimension']
        self.fingerprint=hashlib.sha256(str(sorted(self.manifest.items())).encode()).hexdigest()[:20]
        self.process=None;self.timer=None;self.lock=threading.RLock();self.last_runtime=None;self.completed_cpu=0.
    def _read(self):
        return read_reply(self.process,timeout=getattr(self.settings,'worker_timeout_seconds',180))
    def _write(self,value):
        self.process.stdin.write(json.dumps(value)+'\n');self.process.stdin.flush()
    def _start(self):
        if self.process is not None and self.process.poll() is None:return
        self.close()
        env=os.environ.copy();env['PYTHONPATH']=str(Path(__file__).resolve().parent.parent)+os.pathsep+env.get('PYTHONPATH','')
        for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):env[key]=str(self.settings.cpu_threads)
        env['TOKENIZERS_PARALLELISM']='false'
        self.process=spawn_worker(([sys.executable,'--nuance-worker','embedding'] if getattr(sys,'frozen',False) else [sys.executable,'-u','-m','nuance.embedding_worker']),env,self.settings,'embedding')
        try:
            self._write({'backend':self.backend,'model_path':self.settings.model_path,'threads':self.settings.cpu_threads})
            ready=self._read()
            if ready.get('dimension')!=self.dimension or ready.get('fingerprint')!=self.fingerprint:raise RuntimeError('Embedding worker profile mismatch')
        except Exception:self.close();raise
    def encode(self,texts,query=False):
        with self.lock:
            if self.timer:self.timer.cancel()
            self._start()
            try:
                self._write({'texts':texts,'query':query});reply=self._read();self.last_runtime=reply['runtime']
                return reply['rows'],[{int(k):v for k,v in sparse.items()} for sparse in reply['sparse']]
            except Exception:
                self.close();raise
            finally:
                self.timer=threading.Timer(self.settings.model_idle_seconds,self.close);self.timer.daemon=True;self.timer.start()
    @lru_cache(maxsize=128)
    def query(self,text):
        rows,sparse=self.encode([text],query=True);return rows[0],sparse[0]
    def status(self):
        with self.lock:
            active=self.process is not None and self.process.poll() is None
            return {'active':active,'idle_release_seconds':self.settings.model_idle_seconds,'last_sample_memory_bytes':self.last_runtime.get('memory_bytes') if active and self.last_runtime else 0,'cpu_seconds':self.completed_cpu+(self.last_runtime.get('cpu_seconds',0) if active and self.last_runtime else 0)}
    def close(self):
        with self.lock:
            if self.timer:self.timer.cancel();self.timer=None
            if self.process is not None:
                if self.process.poll() is None:
                    self.process.terminate()
                    try:self.process.wait(timeout=3)
                    except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
                if self.last_runtime:self.completed_cpu+=self.last_runtime.get('cpu_seconds',0)
                self.last_runtime=None
                self.process.stdin.close();self.process.stdout.close();self.process=None
