"""Conservative topical gating, followed by optional local semantic reranking.
Scores describe retrieval evidence, never scientific validity. No remote model.
"""
import re,unicodedata,html,math
VERSION='topic-evidence-v1'
STOP=set('a au aux avec ce ces de des du en et dans le les la un une pour sur d l the of and in on to for from with by is are how what these this study studies research article articles paper papers model models modele modeles'.split())
FAMILIES={
 'neurotechnology':['neurotechnolog','neurotech','neural technology','technologie neuronale'],
 'brain computer interface':['brain computer interface','brain machine interface','interface cerveau ordinateur','interface cerveau machine','bci','bmis','brain computer'],
 'law':['law','laws','legal','rights','regulat','droit','jurid','legislation','legislative'],
 'international relations':['international relations','relations internationales','international politics','foreign policy','foreign relations','international affairs','international political','interstate relations','world politics','global politics','diploma','geopolit'],
 'political':['politic','politiqu'],
 'legitimacy':['legitim','legitima'],
 'privacy':['privacy','vie privee','confidential','mental privacy'],
 'personal data':['personal data','donnees personnelles','data protection','protection donnees','protection des donnees'],
 'electroencephalography':['eeg','electroencephalograph','electroencephalogram'],
 'deep learning':['deep learning','apprentissage profond'],
 'artificial intelligence':['artificial intelligence','intelligence artificielle','ai','ia'],
 'technology acceptance':['technology acceptance','acceptation technologie','acceptance of technology','adoption technologique'],
}
def norm(value):
    value=html.unescape(re.sub(r'<[^>]*>',' ',str(value or '')))
    return ' '.join(re.findall(r'[a-z0-9]+',''.join(c for c in unicodedata.normalize('NFKD',value.casefold()) if not unicodedata.combining(c))))
def phrase_match(text,phrase):
    # A prefix at a word boundary supports FR/EN inflections, not arbitrary substrings.
    parts=norm(phrase).split()
    return bool(parts and re.search(r'(?<!\w)'+r'\s+'.join(re.escape(p)+ (r'\w*' if len(p)>4 else '') for p in parts)+r'(?!\w)',text))
def groups(query,theme=False):
    q=norm(query);out=[];remaining=q
    for canonical,aliases in FAMILIES.items():
        matching=[a for a in aliases if phrase_match(q,a)]
        if matching:
            out.append({'concept':canonical,'aliases':aliases})
            for alias in sorted(matching,key=len,reverse=True):
                parts=norm(alias).split();pattern=r'(?<!\w)'+r'\s+'.join(re.escape(p)+(r'\w*' if len(p)>4 else '') for p in parts)+r'(?!\w)';remaining=re.sub(pattern,' ',remaining)
    if any(g['concept']=='brain computer interface' for g in out):remaining=re.sub(r'computer interfaces?',' ',remaining)
    if any(g['concept']=='electroencephalography' for g in out):remaining=re.sub(r'\bsignals?\b',' ',remaining)
    for part in (remaining.split(' · ') if not theme else norm(remaining).split()):
        for word in part.split():
            if word not in STOP and len(word)>2 and not word.isdigit() and not any(word==g['concept'] for g in out):out.append({'concept':word,'aliases':[word]})
    return out[:16]
def plans(config):
    topics=config.get('topics') or []
    labels=topics if topics else [config['query']]
    return [{'label':label,'groups':groups(label,bool(topics)),'query':' '.join(g['concept'] for g in groups(label,bool(topics))) or label} for label in labels]
def evidence(reference,plan):
    title=norm(reference.get('title'));abstract=norm(reference.get('abstract'));matches=[]
    for group in plan['groups']:
        title_alias=next((a for a in group['aliases'] if phrase_match(title,a)),None)
        abstract_alias=next((a for a in group['aliases'] if phrase_match(abstract,a)),None)
        if title_alias or abstract_alias:matches.append({'concept':group['concept'],'term':title_alias or abstract_alias,'field':'title' if title_alias else 'abstract'})
    count=len(plan['groups'])
    # A specialist journal supplies only a missing contextual concept, never the
    # sole reason to admit a paper. At least two concepts must occur in its text.
    if count>=3 and len(matches)>=2:
        journal=norm(reference.get('journal'));present={m['concept'] for m in matches}
        for group in plan['groups']:
            if group['concept'] in present:continue
            alias=next((a for a in group['aliases'] if phrase_match(journal,a)),None)
            if alias:matches.append({'concept':group['concept'],'term':alias,'field':'journal'})
    needed=count if count<=3 else math.ceil(.7*count)
    passed=bool(count and len(matches)>=needed)
    title_hits=sum(m['field']=='title' for m in matches)
    coverage=len(matches)/count if count else 0
    score=sum({'title':1.,'abstract':.75,'journal':.35}[m['field']] for m in matches)/count if count else 0
    return {'topic':plan['label'],'passed':passed,'coverage':round(coverage,4),'score':round(score,4),'matches':matches,'required_concepts':needed,'concepts':[g['concept'] for g in plan['groups']]}
def rank(items,config,embedder=None):
    ps=plans(config);kept=[];excluded=0
    for item in items:
        if re.match(r'^(?:book\s*review|review of the book|compte rendu)\b',norm(item['reference'].get('title'))):excluded+=1;continue
        ev=[evidence(item['reference'],p) for p in ps];passing=[e for e in ev if e['passed']]
        accepted=all(e['passed'] for e in ev) if config.get('topic_mode')=='all' else bool(passing)
        if not accepted:excluded+=1;continue
        top=max(passing,key=lambda e:e['score']);item={**item,'relevance':{'version':VERSION,'lexical_score':top['score'],'score':top['score'],'semantic_score':None,'topics':passing,'method':'title/abstract concept gate'}};kept.append(item)
    warning=None
    if kept and config.get('semantic_rerank',True) and embedder and embedder.manifest.get('semantic'):
        try:
            qrows,_=embedder.encode([p['query'] for p in ps],query=True)
            vectors,_=embedder.encode([(i['reference']['title']+' '+(i['reference'].get('abstract') or ''))[:2000] for i in kept])
            for item,v in zip(kept,vectors):
                passing={e['topic'] for e in item['relevance']['topics']};scores=[]
                for p,q in zip(ps,qrows):
                    if p['label'] not in passing:continue
                    scores.append(sum(a*b for a,b in zip(v,q))/(math.sqrt(sum(a*a for a in v)*sum(a*a for a in q)) or 1))
                semantic=max(scores);r=item['relevance'];r.update(semantic_score=round(semantic,4),score=round(.65*r['lexical_score']+.35*max(0,semantic),4),method='concept gate + local cosine rerank',model=embedder.manifest)
        except Exception:warning='Local semantic reranking unavailable; explicit concept ranking retained.'
    return sorted(kept,key=lambda i:(i['relevance']['score'],i['reference'].get('date') or ''),reverse=True),{'excluded':excluded,'ranking_version':VERSION,'queries':[p['query'] for p in ps],'ranking_warning':warning}
