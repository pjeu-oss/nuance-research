"""Bounded bibliographic extraction. Evidence levels are not truth probabilities."""
import re,html,io,json
from collections import Counter
from xml.etree import ElementTree as ET
VERSION='bibliography-v2.1'
DOI=re.compile(r'10\.\d{4,9}/[^\s<>"]+',re.I)
BAD=re.compile(r'\.(?:pdf|docx?|xml|tex)$|^HAL Id:|XMLPublish|microsoft|untitled|sans titre|template|layout and consolidation|word document|acrobat|pdfcreator|adobe|firefox|chrome|viewer|^https?://|^document\s*\d*$',re.I)
AFFILIATION=re.compile(r'universit|department|laborat|faculty|faculté|school of|correspond|@|https?://|profess|chargé|professionnel|research associate|^received|^accepted|^published',re.I)
MONTHS={v:i for i,values in enumerate(['january janvier jan','february février fevrier feb','march mars mar','april avril apr','may mai','june juin jun','july juillet jul','august août aout aug','september septembre sep','october octobre oct','november novembre nov','december décembre decembre dec'],1) for v in values.split()}
ORG=re.compile(r'unesco|ocde|oecd|world health|organisation mondiale|commission européenne|european commission|council of europe|conseil de l.europe|haute autorité|parlement|parliament|assemblée|cnil|united nations',re.I)

def norm(value):return re.sub(r'\W+',' ',str(value).casefold()).strip()
def tidy(value):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>','',str(value)))).strip()
def placeholder_title(value,filename=''):
    value=tidy(value)
    return not value or bool(BAD.search(value)) or (filename and norm(value)==norm(filename))
def normalize_doi(value):
    match=DOI.search(str(value or ''))
    if not match:return ''
    text=match.group().rstrip('.,;:')
    while text.endswith(')') and text.count(')')>text.count('('):text=text[:-1]
    return text.lower()[:500]
def names(value):
    value=tidy(value);value=re.sub(r'\b(?:Ph\.?D\.?|MD|Prof\.|Dr\.)\b.*$','',value,flags=re.I).strip()
    if ORG.search(value):return [{'literal':value[:300]}]
    value=re.sub(r'[\d*†‡]+','',value)
    parts=re.split(r'\s+(?:and|et|&)\s+|\s*;\s*',value)
    result=[]
    for part in parts:
        part=part.strip(' ,')
        if not part or AFFILIATION.search(part):continue
        if ',' in part:
            tokens=part.split(',')
            # "Doe, Jane" is explicit, whereas "Jane Doe, John Smith" separates names.
            if len(tokens)==2 and len(tokens[0].split())<=2 and len(tokens[1].split())==1 and not all(len(t.split())>=2 for t in tokens):
                result.append({'family':tokens[0].strip(),'given':tokens[1].strip()});continue
            result.extend(names(';'.join(tokens)));continue
        tokens=part.split()
        if part.isupper() or any(t.casefold() in {'the','of','on','in','for','with','and','to','a','an'} for t in tokens):continue
        if not 2<=len(tokens)<=5 or any(not re.fullmatch(r'[A-ZÀ-ÖØ-Þ][\wÀ-ÿ.\-’\']*|(?:de|van|von|du|del|la|le|da)',t) for t in tokens):continue
        split=len(tokens)-1
        while split>1 and tokens[split-1].casefold() in {'de','van','von','du','del','la','le','da','der','den'}:split-=1
        family=' '.join(tokens[split:]);given=' '.join(tokens[:split])
        if tokens[0].isupper() and len(tokens[0])>2 and not tokens[-1].isupper():family=tokens[0];given=' '.join(tokens[1:])
        result.append({'family':family,'given':given})
    return result[:100]

def pdf_front(data,max_pages=3):
    """Only header pages; never extract/re-embed a whole corpus for metadata."""
    from pypdf import PdfReader
    reader=PdfReader(io.BytesIO(data));raw={};fonts=[];pages=[]
    metadata=reader.metadata or {}
    raw.update(title=str(metadata.get('/Title','')),authors=str(metadata.get('/Author','')))
    try:
        xmp=reader.xmp_metadata
        if xmp:
            titles=xmp.dc_title or {};raw['xmp_title']=titles.get('x-default') or next(iter(titles.values()),'')
            raw['xmp_authors']=list(xmp.dc_creator or [])
            for node in xmp.rdf_root.getElementsByTagName('*'):
                local=node.localName
                if local in {'doi','publicationName','publicationDate','publisher','isbn','issn'}:
                    raw['xmp_'+local]=''.join(c.data for c in node.childNodes if c.nodeType==c.TEXT_NODE)
    except (AttributeError,ValueError,TypeError):pass
    for i in range(min(max_pages,len(reader.pages))):
        def visit(text,cm,tm,font,size):
            if i==0 and len(fonts)<1500:
                for line in text.splitlines():
                    if tidy(line):fonts.append((tidy(line),float(size or 0)*(tm[0]**2+tm[1]**2)**.5*(cm[0]**2+cm[1]**2)**.5))
        text=reader.pages[i].extract_text(visitor_text=visit) or ''
        pages.append((i+1,text[:20000],str(i+1)))
    return pages,raw,fonts

def infer_bibliography(pages,filename='',raw=None,fonts=None):
    raw=raw or {};fonts=fonts or [];fields={};evidence={};alternatives={};warnings=[]
    def put(key,value,method,page=None,excerpt='',level='heuristic'):
        if value in ('',None,[]):return
        fields[key]=value;evidence[key]={'method':method,'page':page,'excerpt':tidy(excerpt or value)[:600],'level':level}
    front=pages[0][1][:16000] if pages else ''
    # A bibliography or references list is never an article's header.
    cut=re.search(r'(?im)^\s*[■•]?\s*(?:abstract|résumé|keyw\s*ords|mots.clés|introduction|références|references|bibliographie)(?:\s*[:.]|\s+|$)',front)
    header=front[:cut.start()] if cut else front[:7000]
    lines=[tidy(line) for line in header.splitlines() if tidy(line)][:100]
    if len(lines)>3 and re.match(r'^(references|bibliographie|références)$',lines[0],re.I):header='';lines=[]
    for line in lines:
        source=re.match(r'^Source:\s*(.+?),\s*((?:19|20)\d{2}).*?(?:Vol\.\s*(\d+))?.*?(?:pp\.\s*([\d–-]+))?$',line,re.I)
        if source:
            put('journal',source[1],'archive-source-label',1,line,'strong');put('year',int(source[2]),'archive-source-label',1,line,'strong');put('date',source[2],'archive-source-label',1,line,'strong')
            volume=re.search(r'Vol\.\s*(\d+)',line,re.I);pagination=re.search(r'pp\.\s*([\d–-]+)',line,re.I)
            if volume:put('volume',volume[1],'archive-source-label',1,line,'strong')
            if pagination:put('pages',pagination[1],'archive-source-label',1,line,'strong')
        for key,pattern in [('title',r'^(?:title|titre)\s*:\s*(.+)'),('journal',r'^(?:journal|revue|publication|container.title)\s*:\s*(.+)'),('publisher',r'^(?:publisher|éditeur|editeur|published by)\s*:\s*(.+)'),('book_title',r'^(?:book title|titre de l.ouvrage)\s*:\s*(.+)'),('series',r'^(?:series|collection)\s*:\s*(.+)'),('edition',r'^(?:edition|édition)\s*:\s*(.+)'),('volume',r'^(?:volume|vol\.)\s*:?\s*(\d+)'),('issue',r'^(?:issue|numéro|number)\s*:\s*(\d+)'),('pages',r'^(?:pages|pagination)\s*:\s*([\d–-]+)')]:
            m=re.match(pattern,line,re.I)
            if m:put(key,m[1], 'header-label',1,line,'strong')
        m=re.match(r'^(?:authors?(?:\(s\))?|auteurs?(?:\(s\))?|by|par)\s*:\s*(.+)',line,re.I)
        if m and names(m[1]):put('author',names(m[1]),'author-label',1,line,'strong')
    for key,xmp in [('title','xmp_title'),('journal','xmp_publicationName'),('publisher','xmp_publisher'),('date','xmp_publicationDate'),('isbn','xmp_isbn'),('issn','xmp_issn')]:
        if raw.get(xmp) and key not in fields and not (key=='title' and placeholder_title(raw[xmp],filename)):
            put(key,tidy(raw[xmp]),'pdf-xmp',None,raw[xmp],'strong')
    # Typography can distinguish the article title from a journal banner or filename.
    valid_fonts=[size for line,size in fonts if size>0 and len(line)>10]
    median=sorted(valid_fonts)[len(valid_fonts)//2] if valid_fonts else 0
    fontmap={}
    for line,size in fonts:fontmap[norm(line)]=max(size,fontmap.get(norm(line),0))
    candidates=[]
    for index,line in enumerate(lines[:45]):
        if len(line)<12 or len(line)>250 or len(line.split())<2 or AFFILIATION.search(line) or BAD.search(line):continue
        if re.search(r'10\.\d{4,9}/|©|copyright|issn|isbn|\babstract\b|\bkeywords\b',line,re.I):continue
        if re.match(r'^(?:first published|doi|journal|revue|publisher|éditeur|author|auteur|date|volume|issue|pages|received|accepted|published|https?|www)\b',line,re.I):continue
        # Avoid author bylines as titles, except genuinely large typography.
        size=fontmap.get(norm(line),0)
        if sum(len(t)==1 for t in line.split())>=3:continue
        if names(line) and (size<=median*1.1 or len(names(line))>1):continue
        score=(80+40*(size/median-1.15) if median and size>=median*1.15 else 0)+min(len(line.split()),12)*2-index*.8
        if line.endswith('.') or len(line.split())>30:score-=35
        if re.search(r'cahiers|journal of|international journal|revue de|^nature\b|^science\b',line,re.I):score-=55
        candidates.append((score,index,line,size))
    if 'title' not in fields:
        meta=raw.get('xmp_title') or raw.get('title','')
        if meta and not placeholder_title(meta,filename) and norm(meta) in norm(header):put('title',tidy(meta),'pdf-properties-header-match',1,meta,'strong')
    if 'title' not in fields:
        best=max(candidates,default=None)
        meta=raw.get('xmp_title') or raw.get('title','')
        if best and (best[0]>=50 or placeholder_title(meta,filename)):
            _,index,title,size=best;level='strong' if best[0]>=50 else 'heuristic'
            # Join consecutive similarly sized title lines, stopping before a byline.
            for next_line in lines[index+1:index+3]:
                nsize=fontmap.get(norm(next_line),0)
                if size and (abs(size-nsize)<.5 or (next_line.isupper() and nsize>=size*.6)) and (not names(next_line) or (nsize>median*1.1 and len(names(next_line))==1)) and len(next_line)>8 and not AFFILIATION.search(next_line) and not re.search('doi|©|issn',next_line,re.I):title+=' '+next_line
                else:break
            put('title',title,'pdf-title-font' if level=='strong' else 'header-title',1,title,'heuristic')
        elif meta and not placeholder_title(meta,filename):put('title',tidy(meta),'pdf-properties',None,meta,'heuristic')
    title_index=next((i for i,line in enumerate(lines) if fields.get('title') and norm(line) in norm(fields['title'])),0)
    if 'author' not in fields:
        authors=[];author_lines=[]
        title_end=title_index
        while title_end+1<len(lines) and fields.get('title') and norm(lines[title_end+1]) in norm(fields['title']):title_end+=1
        for line in lines[title_end+1:title_end+7]:
            if AFFILIATION.search(line):
                if authors:break
                continue
            parsed=names(line)
            if parsed:authors.extend(parsed);author_lines.append(line)
            elif authors:break
        if authors:put('author',authors,'header-byline',1,'; '.join(author_lines),'heuristic')
        else:
            creators=raw.get('xmp_authors') or [raw.get('authors','')]
            parsed=[a for c in creators for a in names(c)]
            if parsed:put('author',parsed,'pdf-properties',None,'; '.join(creators),'heuristic')
    for key,pattern in [('isbn',r'\bISBN(?:-1[03])?\s*:?[ \t]*([\dXx][\dXx -]{8,20})'),('issn',r'\bISSN\s*:?\s*(\d{4}-?\d{3}[\dXx])')]:
        for page,text,_ in pages[:3]:
            m=re.search(pattern,text,re.I)
            if m:
                value=re.sub('[^0-9Xx-]','',m[1]).strip('-')
                if key=='issn' or len(value.replace('-','')) in {10,13}:put(key,value,'identifier-label',page,m[0],'strong');break
    explicit=[];all_dois=[]
    for line in lines:
        found=[normalize_doi(m[0]) for m in DOI.finditer(line)]
        all_dois.extend(found)
        if re.search(r'\bdoi\b|doi\.org',line,re.I):explicit.extend(found)
    xmpdoi=normalize_doi(raw.get('xmp_doi',''))
    unique=list(dict.fromkeys([xmpdoi] if xmpdoi else explicit or all_dois))
    if len(unique)==1:put('doi',unique[0],'pdf-xmp' if xmpdoi else 'header-doi',1,unique[0],'strong' if xmpdoi or explicit else 'heuristic')
    elif unique:alternatives['doi']=unique;warnings.append('Plusieurs DOI dans l’en-tête : aucun DOI choisi automatiquement.')
    # Prefer explicitly published dates to received/revised and file creation dates.
    for line in lines:
        if re.search(r'received|revised|accepted|submitted|soumis|accepté|révisé',line,re.I):continue
        published=bool(re.search(r'published|publication date|parution|publié|date\s*:|année\s*:|year\s*:|©|copyright',line,re.I))
        m=re.search(r'\b((?:19|20)\d{2})-(\d{1,2})-(\d{1,2})\b',line)
        date=''
        if m:date=f'{m[1]}-{int(m[2]):02d}-{int(m[3]):02d}'
        else:
            m=re.search(r'\b(\d{1,2})\s+([A-Za-zéû]+)\.?\s+((?:19|20)\d{2})\b',line,re.I)
            if m and m[2].casefold() in MONTHS:date=f'{m[3]}-{MONTHS[m[2].casefold()]:02d}-{int(m[1]):02d}'
            else:
                m=re.search(r'\b([A-Za-z]+)\s+(\d{1,2}),?\s+((?:19|20)\d{2})\b',line,re.I)
                if m and m[1].casefold() in MONTHS:date=f'{m[3]}-{MONTHS[m[1].casefold()]:02d}-{int(m[2]):02d}'
        years=re.findall(r'\b(?:19|20)\d{2}\b',line)
        if published and (date or len(set(years))==1):put('date',date or years[0],'publication-date',1,line,'strong');break
    if 'date' not in fields:
        years=Counter(re.findall(r'\b(?:19|20)\d{2}\b',header))
        if len(years)==1:put('date',next(iter(years)),'header-year',1,header[:600],'heuristic')
        elif years:alternatives['year']=list(years);warnings.append('Années ambiguës : ne pas confondre publication, soumission et références citées.')
    if fields.get('date'):
        m=re.match(r'((?:19|20)\d{2})',fields['date'])
        if m:put('year',int(m[1]),evidence['date']['method'],evidence['date']['page'],evidence['date']['excerpt'],evidence['date']['level'])
    if 'journal' not in fields:
        for line in lines[:15]:
            if re.search(r'^(?:the )?(?:international |european |american |british )?journal\b|^(?:les |the )?cahiers\b|^revue\b|^\S.*\bjournal\s*$',line,re.I):
                value=re.split(r'\b(?:19|20)\d{2}\b|\b(?:vol\.?|volume|issn)\b',line,1,flags=re.I)[0].strip(' ,:-')
                if 4<len(value)<180:put('journal',value,'journal-header',1,line,'heuristic');break
    # Publisher must be stated, not guessed from a DOI prefix.
    if 'publisher' not in fields:
        for page,text,_ in pages[:3]:
            for line in text.splitlines():
                if re.search(r'©|copyright|published by|publié par|éditions|presses universitaires',line,re.I):
                    m=re.search(r'\b(Elsevier(?:\s+B\.V\.)?|Springer(?: Nature)?|Wiley|Taylor\s*&\s*Francis|Oxford University Press|Cambridge University Press|Presses universitaires[^.;\n]{0,80}|Éditions [^.;\n]{2,80})',line,re.I)
                    if m:put('publisher',tidy(m[1]),'publisher-statement',page,line,'strong');break
            if 'publisher' in fields:break
    if fields.get('journal'):put('type','article-journal','publication-context',1,fields['journal'],'heuristic')
    elif fields.get('isbn'):put('type','book','isbn-context',1,fields['isbn'],'heuristic')
    elif re.search(r'\b(?:recommendation|recommandation|guideline)\b',fields.get('title',''),re.I):put('type','recommendation','title-context',1,fields['title'],'heuristic')
    return {'version':VERSION,'fields':fields,'evidence':evidence,'alternatives':alternatives,'warnings':warnings}

def parse_tei(data):
    if len(data)>2_000_000 or b'<!DOCTYPE' in data or b'<!ENTITY' in data:raise ValueError('Unsafe TEI')
    root=ET.fromstring(data);ns={'t':'http://www.tei-c.org/ns/1.0'}
    bibl=root.find('.//t:sourceDesc/t:biblStruct',ns)
    if bibl is None:raise ValueError('GROBID header not found')
    def text(node):return tidy(''.join(node.itertext())) if node is not None else ''
    result={};analytic=bibl.find('t:analytic',ns);monogr=bibl.find('t:monogr',ns)
    if analytic is not None:
        title=analytic.find('t:title',ns)
        if text(title):result['title']=text(title)
        authors=[]
        for author in analytic.findall('t:author',ns):
            name=author.find('t:persName',ns)
            if name is None:continue
            family=text(name.find('t:surname',ns));given=' '.join(text(n) for n in name.findall('t:forename',ns))
            if family:authors.append({'family':family,'given':given})
        if authors:result['author']=authors
    if monogr is not None:
        for title in monogr.findall('t:title',ns):
            if title.get('level')=='j':result['journal']=text(title);result['type']='article-journal'
            elif title.get('level')=='m':result['book_title']=text(title)
        publisher=monogr.find('t:imprint/t:publisher',ns)
        if text(publisher):result['publisher']=text(publisher)
        date=monogr.find('t:imprint/t:date',ns)
        if date is not None and date.get('when'):result['date']=date.get('when')
        for part in monogr.findall('t:imprint/t:biblScope',ns):
            unit=part.get('unit');key={'volume':'volume','issue':'issue','page':'pages'}.get(unit)
            if key:result[key]=(part.get('from','')+'-'+part.get('to','')).strip('-') or text(part)
    for identifier in bibl.findall('.//t:idno',ns):
        key={'doi':'doi','isbn':'isbn','issn':'issn'}.get(identifier.get('type','').lower())
        if key:result[key]=normalize_doi(text(identifier)) if key=='doi' else text(identifier)
    return result

def grobid_header(data,url):
    import httpx
    response=httpx.post(url.rstrip('/')+'/api/processHeaderDocument',files={'input':('document.pdf',data,'application/pdf')},data={'consolidateHeader':'0'},timeout=30,follow_redirects=False)
    response.raise_for_status();return parse_tei(response.content)

def crossref_metadata(doi):
    import httpx
    from urllib.parse import quote
    doi=normalize_doi(doi)
    if not doi:raise ValueError('A DOI is required')
    response=httpx.get('https://api.crossref.org/works/'+quote(doi,safe=''),headers={'User-Agent':'Nuance-Research/0.7 (explicit DOI metadata request)'},timeout=12,follow_redirects=False)
    response.raise_for_status();item=response.json()['message']
    if normalize_doi(item.get('DOI'))!=doi:raise ValueError('DOI response mismatch')
    mapping={'title':'title','container-title':'journal','publisher':'publisher','volume':'volume','issue':'issue','page':'pages','ISBN':'isbn','ISSN':'issn','author':'author'};result={'doi':doi}
    for key,target in mapping.items():
        value=item.get(key)
        if not value:continue
        if target=='author':result[target]=[{k:tidy(a[k]) for k in ['family','given'] if a.get(k)} for a in value[:100]]
        else:result[target]=tidy(value[0] if isinstance(value,list) else value)[:1000]
    issued=item.get('published-print') or item.get('published-online') or item.get('published') or item.get('issued') or {}
    parts=issued.get('date-parts',[[]])[0]
    if parts:result['date']='-'.join(str(v) for v in parts[:3]);result['year']=int(parts[0])
    kind=item.get('type');result['type']={'journal-article':'article-journal','book':'book','book-chapter':'chapter','report':'report','posted-content':'document','proceedings-article':'document'}.get(kind,'document')
    if result['type']=='chapter':result['book_title']=result.pop('journal','')
    return result
