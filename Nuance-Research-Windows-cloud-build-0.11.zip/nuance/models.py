import hashlib, math, re
from functools import lru_cache
from pathlib import Path
from .config import tree_digest

def tokenize(text): return re.findall(r"[^\W_]+", text.lower(), re.UNICODE)

class Embedder:
    def __init__(self, settings):
        self.backend = settings.embedder
        self.manifest = settings.model_manifest()
        self.model = None
        if self.backend == "bge-m3":
            from FlagEmbedding import BGEM3FlagModel
            self.model = BGEM3FlagModel(settings.model_path, use_fp16=False, devices=["cpu"])
        elif self.backend != "demo-hash":
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(settings.model_path, device="cpu", local_files_only=True, trust_remote_code=False)
            self.model.max_seq_length = 512
        sample = self.encode(["dimension probe"])[0][0]
        self.dimension = len(sample)
        self.fingerprint = hashlib.sha256(str(sorted(self.manifest.items())).encode()).hexdigest()[:20]

    def encode(self, texts, query=False):
        if self.backend == "demo-hash":
            rows=[]
            for text in texts:
                vec=[0.0]*256
                for token in tokenize(text):
                    h = int.from_bytes(hashlib.sha256(token.encode()).digest()[:4], "big")
                    vec[h%256]+=1
                norm=math.sqrt(sum(v*v for v in vec)) or 1
                rows.append([v/norm for v in vec])
            return rows, [{} for _ in texts]
        if self.backend == "bge-m3":
            result=self.model.encode(texts, batch_size=8, max_length=512, return_dense=True, return_sparse=True, return_colbert_vecs=False)
            sparse=[{int(k):float(v) for k,v in row.items()} for row in result["lexical_weights"]]
            return result["dense_vecs"].tolist(), sparse
        if self.backend == "qwen" and query:
            texts=["Instruct: Retrieve relevant passages for this query.\nQuery: "+t for t in texts]
        result=self.model.encode(texts, batch_size=16, normalize_embeddings=True)
        return result.tolist(), [{} for _ in texts]

    @lru_cache(maxsize=128)
    def query(self, text):
        rows,sparse=self.encode([text],query=True)
        return rows[0],sparse[0]

class Reranker:
    def __init__(self, path):
        self.model = None
        self.manifest = None
        if path:
            import json
            from sentence_transformers import CrossEncoder
            self.manifest=json.loads((Path(path)/"nuance-model.json").read_text())
            if self.manifest.get("artifact_sha256") != tree_digest(Path(path)):
                raise ValueError("Reranker snapshot digest mismatch")
            self.model=CrossEncoder(path, device="cpu", local_files_only=True, trust_remote_code=False, max_length=512)
    def score(self, query, texts):
        return [float(v) for v in self.model.predict([(query,t) for t in texts])] if self.model else None
