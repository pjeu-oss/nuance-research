from datetime import datetime, timezone
import uuid
from sqlalchemy import create_engine, String, Text, Integer, JSON, ForeignKey, event
from sqlalchemy.orm import DeclarativeBase, mapped_column, sessionmaker

def uid(): return str(uuid.uuid4())
def now(): return datetime.now(timezone.utc).isoformat()
class Base(DeclarativeBase): pass
class Collection(Base):
    __tablename__ = "collections"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    owner = mapped_column(String)
    name = mapped_column(String)
    readers = mapped_column(JSON, default=list)
class Document(Base):
    __tablename__ = "documents"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    collection_id = mapped_column(ForeignKey("collections.id"), index=True)
    owner = mapped_column(String)
    readers = mapped_column(JSON, default=list)
    filename = mapped_column(String)
    title = mapped_column(String)
    metadata_json = mapped_column(JSON)
    sha256 = mapped_column(String)
    status = mapped_column(String, default="indexing")
    created_at = mapped_column(String, default=now)
    provenance = mapped_column(JSON)
class Page(Base):
    __tablename__ = "pages"
    id = mapped_column(String, primary_key=True, default=uid)
    document_id = mapped_column(ForeignKey("documents.id"), index=True)
    number = mapped_column(Integer)
    text = mapped_column(Text)
    label = mapped_column(String)
class Chunk(Base):
    __tablename__ = "chunks"
    id = mapped_column(String, primary_key=True, default=uid)
    document_id = mapped_column(ForeignKey("documents.id"), index=True)
    page_id = mapped_column(ForeignKey("pages.id"), index=True)
    start = mapped_column(Integer)
    end = mapped_column(Integer)
    text = mapped_column(Text)
    vector = mapped_column(JSON)
class Concept(Base):
    __tablename__ = "concepts"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    name = mapped_column(String)
    aliases = mapped_column(JSON, default=list)
    parent_id = mapped_column(String, nullable=True)
class Tag(Base):
    __tablename__ = "tags"
    id = mapped_column(String, primary_key=True, default=uid)
    document_id = mapped_column(ForeignKey("documents.id"), index=True)
    concept_id = mapped_column(ForeignKey("concepts.id"))
class Audit(Base):
    __tablename__ = "audit"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    actor = mapped_column(String)
    action = mapped_column(String)
    target = mapped_column(String)
    created_at = mapped_column(String, default=now)
class TopicRun(Base):
    __tablename__ = "topic_runs"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    actor = mapped_column(String)
    result = mapped_column(JSON)
    created_at = mapped_column(String, default=now)

class ResearchRecord(Base):
    __tablename__ = "research_records"
    id = mapped_column(String, primary_key=True, default=uid)
    tenant = mapped_column(String, index=True)
    owner = mapped_column(String, index=True)
    kind = mapped_column(String, index=True)
    payload = mapped_column(JSON)
    revision = mapped_column(Integer, default=1)
    updated_at = mapped_column(String, default=now)

def connect(url):
    engine = create_engine(url, connect_args={"check_same_thread": False} if url.startswith("sqlite") else {}, pool_pre_ping=True)
    if url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def fk(conn, _): conn.execute("PRAGMA foreign_keys=ON")
    Base.metadata.create_all(engine)
    from .lexical import install_index
    install_index(engine)
    return engine, sessionmaker(engine, expire_on_commit=False)

def audit(s, identity, action, target=""):
    s.add(Audit(tenant=identity["tenant"], actor=identity["user"], action=action, target=target))
