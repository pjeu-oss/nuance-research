"""Typed metadata and local CSL formatting. Missing fields are never invented."""
import re
from pathlib import Path
TYPES={'article-journal','book','chapter','report','recommendation','legislation','legal_case','webpage','thesis','document'}
FIELDS={'publisher':'publisher','publisher_place':'publisher-place','series':'collection-title','volume':'volume','issue':'issue','pages':'page','edition':'edition','isbn':'ISBN','issn':'ISSN','url':'URL','number':'number','jurisdiction':'jurisdiction','authority':'authority','version':'version','institution':'institution','accessed':'accessed','date':'date','book_title':'book-title'}

def enrich_reference(item,result):
    supplied=item.get('type',item.get('document_type'))
    title=result['title'].casefold()
    inferred=not supplied
    if not supplied:
        if re.search(r'\b(règlement|loi|décret|legislation|regulation|code civil)\b',title):supplied='legislation'
        elif re.search(r'\b(recommandation|recommendation|guideline)\b',title):supplied='recommendation'
        elif item.get('ISBN',item.get('isbn')):supplied='book'
        elif result.get('journal'):supplied='article-journal'
        else:supplied='document'
    if supplied not in TYPES:raise ValueError('Unsupported reference type')
    result['type']=supplied;result['type_inferred']=item.get('type_inferred',inferred)
    for key,csl in FIELDS.items():
        value=item.get(csl,item.get(key,''))
        if key=='accessed' and isinstance(value,dict):
            parts=value.get('date-parts',[[]])[0];value='-'.join(str(part) for part in parts)
        result[key]=str(value or '')[:1000]
    issued=item.get('issued',{})
    if not result['date'] and isinstance(issued,dict) and issued.get('date-parts'):
        result['date']='-'.join(str(part) for part in issued['date-parts'][0][:3])
    details=item.get('author_details',item.get('author',[]))
    if not isinstance(details,list):details=[]
    result['author_details']=[{key:str(a[key])[:300] for key in ['family','given','literal','suffix','non-dropping-particle'] if a.get(key)} for a in details if isinstance(a,dict)][:100]
    result['authors']=result['authors'][:100]
    return result

def reference_to_csl(ref):
    kind=ref.get('type','document');kind={'recommendation':'report','document':'report'}.get(kind,kind)
    out={'id':str(ref.get('id','reference')),'type':kind,'title':ref['title']}
    if ref.get('author_details'):out['author']=ref['author_details']
    elif ref.get('authors'):
        out['author']=[]
        for name in ref['authors']:
            # Only parse the explicit "family, given" convention; keep other names literal.
            parts=name.split(',',1)
            out['author'].append({'family':parts[0].strip(),'given':parts[1].strip()} if len(parts)==2 else {'literal':name})
    if not out.get('author') and ref.get('authority'):out['author']=[{'literal':ref['authority']}]
    date=ref.get('date') or str(ref.get('year') or '')
    if re.fullmatch(r'\d{4}(?:-\d{1,2}){0,2}',date):out['issued']={'date-parts':[[int(part) for part in date.split('-')]]}
    if ref.get('journal'):out['container-title']=ref['journal']
    elif ref.get('book_title'):out['container-title']=ref['book_title']
    if ref.get('doi'):out['DOI']=ref['doi']
    for key,csl in FIELDS.items():
        if not ref.get(key) or key in {'date','accessed','book_title','institution'}:continue
        out[csl]=ref[key]
    if ref.get('institution') and not out.get('publisher'):out['publisher']=ref['institution']
    if ref.get('type')=='recommendation':out['genre']='Recommandations'
    if ref.get('accessed') and re.fullmatch(r'\d{4}(?:-\d{1,2}){0,2}',ref['accessed']):out['accessed']={'date-parts':[[int(part) for part in ref['accessed'].split('-')]]}
    return out

def metadata_missing(ref):
    missing=[]
    if not ref.get('authors') and not ref.get('authority'):missing.append('auteur ou organisme')
    if not ref.get('year') and not ref.get('date'):missing.append('date')
    kind=ref.get('type','document')
    if kind=='article-journal' and not ref.get('journal'):missing.append('revue')
    if kind in {'book','chapter','report','recommendation'} and not(ref.get('publisher') or ref.get('institution')):missing.append('éditeur ou organisme éditeur')
    if kind=='legislation' and not ref.get('jurisdiction'):missing.append('juridiction')
    return missing

def format_reference(ref,style='apa',placement='inline',locator=None):
    from citeproc import CitationStylesStyle,CitationStylesBibliography,Citation,CitationItem,Locator
    from citeproc.source.json import CiteProcJSON
    from citeproc import formatter
    if style not in {'apa','chicago'}:raise ValueError('Unsupported citation style')
    data=reference_to_csl(ref);rid=data['id']
    def make(bibliography=False):
        filename='chicago-author-date' if style=='chicago' and placement=='inline' else style
        return CitationStylesBibliography(CitationStylesStyle(str(Path(__file__).parent/'styles'/f'{filename}.csl'),locale='en-US',validate=False),CiteProcJSON([data]),formatter.plain)
    proc=make();item=CitationItem(rid,**({'locator':Locator('page',str(locator))} if locator else {}));citation=Citation([item]);proc.register(citation)
    text=str(proc.cite(citation,lambda item:None))
    # A fresh register avoids letting a citation locator contaminate bibliography pages.
    proc=make();citation=Citation([CitationItem(rid)]);proc.register(citation)
    bibliography=''.join(str(v) for v in proc.bibliography()[0])
    if placement=='footnote' and style=='apa':text=bibliography+(f' Page source : {locator}.' if locator else '')
    warnings=['Informations à compléter : '+', '.join(metadata_missing(ref))] if metadata_missing(ref) else []
    if not ref.get('author_details') and ref.get('authors'):warnings.append('Noms fournis comme texte : vérifier les noms de famille et les initiales.')
    return {'citation':text,'bibliography':bibliography,'style':style,'placement':placement,'warnings':warnings,'csl':data}
