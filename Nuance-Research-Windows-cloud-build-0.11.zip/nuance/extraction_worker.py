"""One-document parser process; input/output stays local, without credentials."""
import json,sys
from pathlib import Path
from types import SimpleNamespace
from .extract import extract

def main():
    try:
        request=json.loads(sys.stdin.readline())
        settings=SimpleNamespace(**request['settings'],isolate_extraction=False)
        path=Path(request['path'])
        if path.stat().st_size>settings.max_upload_mb*1024*1024:raise ValueError('Upload too large')
        pages,metadata=extract(path.read_bytes(),request['filename'],settings,path)
        reply={'pages':pages,'metadata':metadata}
    except Exception as exc:reply={'error':str(exc)}
    sys.stdout.write(json.dumps(reply,ensure_ascii=False)+'\n');sys.stdout.flush()
if __name__=='__main__':main()
