"""Bound CPU pools without forcing a platform-specific process priority."""
import os,time
_started=time.monotonic()
def configure(settings):
    count=max(1,settings.cpu_threads)
    for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        os.environ[name]=str(count)
    os.environ['TOKENIZERS_PARALLELISM']='false'
    try:
        from threadpoolctl import threadpool_limits
        threadpool_limits(limits=count)
    except ImportError:pass

def metrics(settings):
    cpu=os.times()
    result={'cpu_seconds':cpu.user+cpu.system,'uptime_seconds':time.monotonic()-_started,'cpu_threads':settings.cpu_threads,'memory_bytes':None,'memory_kind':'unavailable'}
    try:
        import psutil
        result.update(memory_bytes=psutil.Process().memory_info().rss,memory_kind='resident')
    except (ImportError,OSError):
        try:
            import resource,sys
            value=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            result.update(memory_bytes=value if sys.platform=='darwin' else value*1024,memory_kind='peak resident')
        except ImportError:pass
    return result

def release_unused_memory():
    """After heavy completed jobs, ask the allocator to return already-free pages."""
    import gc,ctypes,sys
    gc.collect()
    try:
        library=ctypes.CDLL(None)
        if sys.platform=='darwin':
            function=library.malloc_zone_pressure_relief
            function.argtypes=[ctypes.c_void_p,ctypes.c_size_t];function.restype=ctypes.c_size_t
            function(None,0)
        elif sys.platform.startswith('linux') and hasattr(library,'malloc_trim'):
            library.malloc_trim.argtypes=[ctypes.c_size_t];library.malloc_trim.restype=ctypes.c_int
            library.malloc_trim(0)
    except (AttributeError,OSError):pass
