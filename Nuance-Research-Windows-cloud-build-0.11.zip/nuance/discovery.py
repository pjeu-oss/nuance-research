"""Opt-in journal metadata discovery and authenticated, read-only Zotero sync."""
import base64,json,os,re,hashlib,threading,time,unicodedata,ipaddress
from datetime import datetime,timezone,timedelta,date
from pathlib import Path
from urllib.parse import urlparse,urlencode
import httpx
from pydantic import BaseModel,Field
from typing import Annotated
from .watch_relevance import plans,rank,evidence,VERSION
from fastapi import HTTPException,Request
from sqlalchemy import select
from .db import ResearchRecord,uid,now,audit
from .security import require_editor
from .metadata import normalize_doi,tidy

class ConnectionRequest(BaseModel):
    provider:str=Field(pattern='^(zotero|institution)$')
    name:str=Field(min_length=1,max_length=150)
    library_id:str=Field(default='',pattern=r'^\d{0,15}$')
    api_key:str=Field(default='',max_length=256)
    portal_url:str=Field(default='',max_length=1000)
class WatchRequest(BaseModel):
    name:str=Field(min_length=1,max_length=150)
    query:str=Field(min_length=2,max_length=500)
    provider:str=Field(default='crossref',pattern='^(crossref|zotero)$')
    connection_id:str|None=None
    journal:str=Field(default='',max_length=200)
    issn:str=Field(default='',pattern=r'^(?:\d{4}-\d{3}[\dXx])?$')
    since:str=Field(default_factory=lambda:(date.today()-timedelta(days=365)).isoformat(),pattern=r'^\d{4}-\d{2}-\d{2}$')
    project_ids:list[str]|None=Field(default=None,max_length=20)
    topics:list[Annotated[str,Field(min_length=2,max_length=180)]]=Field(default_factory=list,max_length=4)
    topic_mode:str=Field(default='any',pattern='^(any|all)$')
    semantic_rerank:bool=True
    online_consent:bool=False
    automatic:bool=False
    interval_hours:int=Field(default=24,ge=6,le=720)
    auto_add_metadata:bool=False
    revision:int=Field(default=0,ge=0)
class RevisionRequest(BaseModel):
    revision:int=Field(ge=1)
class WatchContext(BaseModel):
    watch_id:str|None=None
class AddDiscovery(BaseModel):
    project_ids:list[str]=Field(default_factory=list,max_length=20)

def public_url(value):
    if not value:return ''
    p=urlparse(value)
    if p.scheme not in {'http','https'} or p.username or p.password or not p.hostname:return ''
    host=p.hostname.casefold()
    if host in {'localhost','grobid','metadata.google.internal'} or host.endswith(('.localhost','.local','.internal')):return ''
    try:
        if not ipaddress.ip_address(host).is_global:return ''
    except ValueError:pass
    return value[:2000]

def fetch_json(url,params=None,headers=None):
    # Fixed API origins only. Never follows redirects or downloads source files.
    with httpx.Client(timeout=20,follow_redirects=False,headers={'User-Agent':'Nuance-Research/0.9 (local literature discovery)',**(headers or {})}) as c:
        with c.stream('GET',url,params=params) as response:
            response.raise_for_status();parts=[];size=0
            for chunk in response.iter_bytes():
                size+=len(chunk)
                if size>4_000_000:raise ValueError('Metadata response too large')
                parts.append(chunk)
            return json.loads(b''.join(parts)),dict(response.headers)

def _crossref_candidates(config):
    filters=['type:journal-article','from-pub-date:'+config['since'],'until-pub-date:'+date.today().isoformat()]
    if config.get('issn'):filters.append('issn:'+config['issn'])
    params={'query.bibliographic':config['query'],'rows':80,'filter':','.join(filters),'sort':'score','order':'desc'}
    if config.get('journal'):params['query.container-title']=config['journal']
    data,_=fetch_json('https://api.crossref.org/works',params)
    items=[]
    for work in data.get('message',{}).get('items',[])[:80]:
        title=(work.get('title') or [''])[0]
        if not title:continue
        doi=normalize_doi(work.get('DOI'));issued=work.get('published-print') or work.get('published-online') or work.get('published') or work.get('issued') or {}
        parts=issued.get('date-parts',[[]])[0]
        authors=[{k:tidy(a[k]) for k in ('family','given') if a.get(k)} for a in work.get('author',[])[:100]]
        ref={'title':tidy(title),'author':authors,'year':parts[0] if parts else None,'date':'-'.join(str(p) if index==0 else str(p).zfill(2) for index,p in enumerate(parts[:3])),'doi':doi,'journal':tidy((work.get('container-title') or [''])[0]),'publisher':tidy(work.get('publisher','')),'type':'article-journal','abstract':tidy(work.get('abstract',''))[:4000],'volume':str(work.get('volume','')),'issue':str(work.get('issue','')),'pages':str(work.get('page','')),'url':public_url(work.get('URL','')) or ('https://doi.org/'+doi if doi else '')}
        items.append({'external_id':doi or hashlib.sha256(ref['title'].encode()).hexdigest(),'reference':ref,'provider':'crossref','provider_score':work.get('score'),'source_url':ref['url']})
    return items,{'more_available':len(items)==80}

def crossref_search(config):
    unique={};more=False
    for plan in plans(config):
        rows,info=_crossref_candidates({**config,'query':plan['query']})
        more=more or info['more_available']
        for row in rows:unique.setdefault(row['external_id'],row)
    return list(unique.values()),{'more_available':more,'coverage':'Up to 80 relevance-ranked candidates per topic (maximum four topics); explicit concept filtering, then at most 40 proposals. Not exhaustive.'}

def zotero_reference(work):
    d=work.get('data',{});title=d.get('title','')
    if d.get('itemType') in {'attachment','note'}:return None
    if not title:return None
    kinds={'journalArticle':'article-journal','book':'book','bookSection':'chapter','report':'report','thesis':'thesis','webpage':'webpage','statute':'legislation','case':'legal_case'}
    authors=[({'literal':a['name']} if a.get('name') else {'family':a.get('lastName',''),'given':a.get('firstName','')}) for a in d.get('creators',[]) if a.get('creatorType') in {'author','inventor'}][:100]
    rawdate=tidy(d.get('date',''));year=re.search(r'\b(?:1[5-9]|20)\d{2}\b',rawdate)
    ref={'title':tidy(title),'author':authors,'year':int(year[0]) if year else None,'date':rawdate if re.fullmatch(r'\d{4}(?:-\d{2}){0,2}',rawdate) else '', 'doi':normalize_doi(d.get('DOI','')),'type':kinds.get(d.get('itemType'),'document'),'journal':tidy(d.get('publicationTitle','')),'book_title':tidy(d.get('bookTitle','')),'publisher':tidy(d.get('publisher','')),'volume':str(d.get('volume','')),'issue':str(d.get('issue','')),'pages':str(d.get('pages','')),'isbn':str(d.get('ISBN','')),'issn':str(d.get('ISSN','')),'abstract':tidy(d.get('abstractNote',''))[:4000],'url':public_url(d.get('url','')),'tags':[tidy(t.get('tag','')) for t in d.get('tags',[])][:50]}
    return {'external_id':work['key'],'provider':'zotero','reference':ref,'source_url':ref['url']}

class Vault:
    def __init__(self,path):self.path=Path(path)/'connection-vault.key';self.guard=threading.Lock()
    def cipher(self):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        with self.guard:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            if not self.path.exists():
                try:
                    fd=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                    with os.fdopen(fd,'wb') as f:f.write(os.urandom(32))
                except FileExistsError:pass
            if self.path.is_symlink():raise ValueError('Vault key must be a regular private file')
            if os.name!='nt':os.chmod(self.path,0o600)
            return AESGCM(self.path.read_bytes())
    def seal(self,value,owner):
        nonce=os.urandom(12);return base64.b64encode(nonce+self.cipher().encrypt(nonce,value.encode(),owner.encode())).decode()
    def open(self,value,owner):
        data=base64.b64decode(value);return self.cipher().decrypt(data[:12],data[12:],owner.encode()).decode()

class Scheduler:
    def __init__(self,settings,Session,run):self.settings=settings;self.Session=Session;self.run=run;self.stop_event=threading.Event();self.thread=None
    def start(self):
        self.thread=threading.Thread(target=self.loop,name='nuance-literature-watch',daemon=True);self.thread.start()
    def stop(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=2)
    def loop(self):
        while not self.stop_event.wait(60):
            with self.Session() as s:
                watches=[(w.id,w.tenant,w.owner,dict(w.payload)) for w in s.scalars(select(ResearchRecord).where(ResearchRecord.kind=='literature-watch'))]
            for wid,tenant,owner,payload in watches:
                if self.stop_event.is_set():return
                if not payload.get('automatic') or not payload.get('online_consent'):continue
                active=next((i for i in self.settings.keys.values() if i['tenant']==tenant and i['user']==owner and i['role'] in {'editor','admin'}),None)
                if not active:continue
                last=payload.get('last_checked')
                if last and (datetime.now(timezone.utc)-datetime.fromisoformat(last)).total_seconds()<payload.get('interval_hours',24)*3600:continue
                try:self.run(wid,active)
                except Exception:pass # Run records its bounded error status, without logging queries or keys.

def install_discovery(app,Session,lock,identity,visible_refs,scoped_refs,records,dto,clean):
    vault=Vault(app.state.settings.data_dir);running=set();guard=threading.Lock()
    def owner(i,cid):return i['tenant']+'\0'+i['user']+'\0'+cid
    def own(s,i,rid,kind):
        r=s.get(ResearchRecord,rid)
        if not r or r.tenant!=i['tenant'] or r.owner!=i['user'] or r.kind!=kind:raise HTTPException(404,'Item unavailable')
        return r
    def connection_dto(c):
        return {'id':c.id,'revision':c.revision,'name':c.payload['name'],'provider':c.payload['provider'],'library_id':c.payload.get('library_id'),'portal_url':c.payload.get('portal_url'),'key_saved':bool(c.payload.get('encrypted_key'))}
    def checked_connection(s,i,cid):
        c=own(s,i,cid,'library-connection')
        if c.payload['provider']!='zotero':raise HTTPException(422,'This institutional portal requires its own approved connector; browser sign-in is available.')
        return c
    def add(s,i,item,project_ids):
        scoped_refs(s,i,project_ids)
        refs=visible_refs(s,i);candidate=clean(item.payload['reference']);doi=candidate.get('doi');key=re.sub(r'\W+','',candidate['title'].casefold())
        existing=next((r for r in refs if (doi and doi==r.payload.get('doi')) or key==re.sub(r'\W+','',r.payload['title'].casefold())),None)
        was_existing=existing is not None
        if not existing:
            candidate['import_provenance']={'format':'literature-discovery','provider':item.payload['provider'],'external_id':item.payload['external_id'],'discovered_at':item.payload['discovered_at'],'source_url':item.payload['source_url']};candidate['read_status']='to-read'
            existing=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='reference',payload=candidate);s.add(existing);s.flush();audit(s,i,'discovery.add-reference',existing.id)
        for pid in project_ids or []:
            p=own(s,i,pid,'project');members=set(p.payload.get('reference_ids',[]))
            if existing.id not in members:p.payload={**p.payload,'reference_ids':sorted(members|{existing.id})};p.revision+=1;p.updated_at=now()
        item.payload={**item.payload,'status':'added','reference_id':existing.id};item.revision+=1;item.updated_at=now()
        return {'reference':dto(existing),'existing':was_existing,'full_text_imported':False}
    def run(wid,i):
        with guard:
            if wid in running:raise HTTPException(409,'This watch is already checking')
            running.add(wid)
        try:
            with Session() as s:
                watch=own(s,i,wid,'literature-watch');config=dict(watch.payload);revision=watch.revision;scoped_refs(s,i,config.get('project_ids'))
                if not config.get('online_consent'):raise HTTPException(422,'Activate online discovery explicitly')
                credential=None
                if config['provider']=='zotero':
                    c=checked_connection(s,i,config.get('connection_id'));credential=vault.open(c.payload['encrypted_key'],owner(i,c.id));library_id=c.payload['library_id']
            info={}
            if config['provider']=='crossref':items,info=crossref_search(config)
            else:
                params={'format':'json','limit':100,'itemType':'-attachment','q':config['query'],'qmode':'titleCreatorYear','since':config.get('sync_since',0),'start':config.get('sync_start',0),'sort':'dateModified','direction':'asc'}
                data,headers=fetch_json('https://api.zotero.org/users/'+library_id+'/items/top',params,{'Zotero-API-Key':credential,'Zotero-API-Version':'3'})
                items=[r for w in data[:100] if (r:=zotero_reference(w))]
                for item in items:item['external_id']=library_id+':'+item['external_id']
                version=int(headers.get('last-modified-version',0));more=len(data)==100
                info={'more_available':more,'sync_start':config.get('sync_start',0)+100 if more else 0,'sync_since':config.get('sync_since',0) if more else version,'coverage':'100 changed matching Zotero records per run; next run continues pagination. No attachments downloaded.'}
            considered=len(items);items,ranking=rank(items,config,app.state.searcher.embedder);info.update(ranking);info['considered']=considered;items=items[:40]
            with lock,Session.begin() as s:
                watch=own(s,i,wid,'literature-watch')
                if watch.revision!=revision:raise HTTPException(409,'Watch settings changed while checking; results discarded')
                scoped_refs(s,i,config.get('project_ids'));existing={r.payload['provider']+':'+r.payload['external_id']:r for r in records(s,i,'discovery-item')};refs=visible_refs(s,i);known={r.payload.get('doi') for r in refs if r.payload.get('doi')};created=0;added=0
                for item in items:
                    key=item['provider']+':'+item['external_id'];record=existing.get(key)
                    if record:
                        states=dict(record.payload.get('watch_statuses',{}));states.setdefault(wid,'known' if item['reference'].get('doi') in known else 'new');watches=set(record.payload.get('watch_ids',[]))|{wid};record.payload={**record.payload,'watch_ids':sorted(watches),'watch_statuses':states,'watch_scores':{**record.payload.get('watch_scores',{}),wid:item['relevance']}}
                        if config.get('auto_add_metadata') and states[wid]=='new':add(s,i,record,config.get('project_ids') or []);added+=1
                        continue
                    payload={**item,'watch_ids':[wid],'discovered_at':now(),'status':'known' if item['reference'].get('doi') in known else 'new','query':config['query'],'watch_scores':{wid:item['relevance']},'watch_statuses':{wid:'known' if item['reference'].get('doi') in known else 'new'}}
                    record=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='discovery-item',payload=payload);s.add(record);s.flush();existing[key]=record;created+=1
                    if config.get('auto_add_metadata') and payload['status']=='new':add(s,i,record,config.get('project_ids') or []);added+=1
                watch.payload={**watch.payload,**info,'last_checked':now(),'last_error':None,'last_new':created,'last_added':added};watch.updated_at=now();audit(s,i,'discovery.check',wid)
                return {'new':created,'added':added,'returned':len(items),**info}
        except Exception as exc:
            with lock,Session.begin() as s:
                watch=s.get(ResearchRecord,wid)
                if watch and watch.tenant==i['tenant'] and watch.owner==i['user'] and watch.kind=='literature-watch':watch.payload={**watch.payload,'last_checked':now(),'last_error':'Check unavailable. Verify the connection, permissions or service availability.'};watch.updated_at=now()
            if isinstance(exc,HTTPException):raise
            raise HTTPException(502,'Provider unavailable or credentials rejected; no private source files were sent')
        finally:
            with guard:running.discard(wid)
    @app.get('/api/research/connections')
    def connections(request:Request):
        with Session() as s:return [connection_dto(c) for c in records(s,identity(request),'library-connection')]
    @app.post('/api/research/connections')
    def connect(req:ConnectionRequest,request:Request):
        i=identity(request);require_editor(i)
        if req.provider=='zotero':
            if not req.library_id or len(req.api_key)<20:raise HTTPException(422,'Enter the Zotero numeric user ID and a dedicated read-only API key')
            try:fetch_json('https://api.zotero.org/users/'+req.library_id+'/items/top',{'limit':1,'format':'json'},{'Zotero-API-Key':req.api_key,'Zotero-API-Version':'3'})
            except Exception:raise HTTPException(502,'Zotero rejected this connection or is unavailable')
        elif not public_url(req.portal_url) or not req.portal_url.startswith('https://'):raise HTTPException(422,'Enter the public HTTPS homepage of your institutional library')
        with lock,Session.begin() as s:
            cid=uid();payload={'name':req.name,'provider':req.provider,'library_id':req.library_id,'portal_url':public_url(req.portal_url)}
            if req.provider=='zotero':payload['encrypted_key']=vault.seal(req.api_key,owner(i,cid))
            c=ResearchRecord(id=cid,tenant=i['tenant'],owner=i['user'],kind='library-connection',payload=payload);s.add(c);s.flush();audit(s,i,'library.connect',cid);return connection_dto(c)
    @app.post('/api/research/connections/{cid}/disconnect')
    def disconnect(cid:str,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            c=own(s,i,cid,'library-connection');c.kind='connection-disconnected';c.payload={k:v for k,v in c.payload.items() if k!='encrypted_key'}
            for w in records(s,i,'literature-watch'):
                if w.payload.get('connection_id')==cid:w.payload={**w.payload,'automatic':False};w.revision+=1
            audit(s,i,'library.disconnect',cid);return {'disconnected':True}
    @app.get('/api/research/watches')
    def watches(request:Request):
        with Session() as s:return [dto(w) for w in records(s,identity(request),'literature-watch')]
    def save(req,i,wid=None):
        if not req.online_consent:raise HTTPException(422,'Explicit consent to send the displayed query to the selected provider is required')
        try:date.fromisoformat(req.since)
        except ValueError:raise HTTPException(422,'Invalid publication date')
        with lock,Session.begin() as s:
            scoped_refs(s,i,req.project_ids)
            if req.provider=='zotero':checked_connection(s,i,req.connection_id)
            w=own(s,i,wid,'literature-watch') if wid else ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='literature-watch',payload={})
            if wid and w.revision!=req.revision:raise HTTPException(409,'Watch changed; reload')
            w.payload={**req.model_dump(exclude={'revision'}),'last_checked':None};w.updated_at=now()
            if wid:w.revision+=1
            else:s.add(w)
            s.flush();audit(s,i,'discovery.save-watch',w.id);return dto(w)
    @app.post('/api/research/watches')
    def create_watch(req:WatchRequest,request:Request):i=identity(request);require_editor(i);return save(req,i)
    @app.put('/api/research/watches/{wid}')
    def update_watch(wid:str,req:WatchRequest,request:Request):i=identity(request);require_editor(i);return save(req,i,wid)
    @app.post('/api/research/watches/{wid}/check')
    def check(wid:str,request:Request):i=identity(request);require_editor(i);return run(wid,i)
    @app.post('/api/research/watches/{wid}/archive')
    def archive(wid:str,req:RevisionRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            w=own(s,i,wid,'literature-watch')
            if w.revision!=req.revision:raise HTTPException(409,'Watch changed; reload')
            w.kind='watch-archive';w.payload={**w.payload,'automatic':False};w.revision+=1;audit(s,i,'discovery.archive',wid);return {'archived':True}
    @app.post('/api/research/watches/{wid}/reset')
    def reset_watch(wid:str,req:RevisionRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            w=own(s,i,wid,'literature-watch')
            if w.revision!=req.revision:raise HTTPException(409,'Watch changed; reload')
            previous=[]
            for item in records(s,i,'discovery-item'):
                p=item.payload
                if wid not in p.get('watch_ids',[]):continue
                previous.append({'id':item.id,'score':p.get('watch_scores',{}).get(wid),'status':p.get('watch_statuses',{}).get(wid,p.get('status','new'))})
                item.payload={**p,'watch_ids':[v for v in p['watch_ids'] if v!=wid],'watch_scores':{k:v for k,v in p.get('watch_scores',{}).items() if k!=wid},'watch_statuses':{k:v for k,v in p.get('watch_statuses',{}).items() if k!=wid}};item.revision+=1
            snap=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='watch-reset',payload={'watch_id':wid,'previous_payload':dict(w.payload),'items':previous});s.add(snap);s.flush()
            w.payload={**w.payload,'last_checked':None,'last_error':None,'last_new':0,'last_added':0,'sync_since':0,'sync_start':0,'last_reset_id':snap.id};w.revision+=1;w.updated_at=now();audit(s,i,'discovery.reset',wid)
            return {'watch':dto(w),'reset_id':snap.id,'cleared':len(previous)}
    @app.post('/api/research/watch-resets/{rid}/restore')
    def restore_watch_reset(rid:str,req:RevisionRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            snap=own(s,i,rid,'watch-reset');wid=snap.payload['watch_id'];w=own(s,i,wid,'literature-watch')
            if w.revision!=req.revision or w.payload.get('last_reset_id')!=rid:raise HTTPException(409,'Watch changed; reload')
            previous={v['id']:v for v in snap.payload['items']}
            for item in records(s,i,'discovery-item'):
                p=item.payload;ids=set(p.get('watch_ids',[]))-{wid};scores={k:v for k,v in p.get('watch_scores',{}).items() if k!=wid};states={k:v for k,v in p.get('watch_statuses',{}).items() if k!=wid}
                if item.id in previous:
                    ids.add(wid);states[wid]=previous[item.id]['status']
                    if previous[item.id]['score']:scores[wid]=previous[item.id]['score']
                item.payload={**p,'watch_ids':sorted(ids),'watch_scores':scores,'watch_statuses':states};item.revision+=1
            w.payload=dict(snap.payload['previous_payload']);w.revision+=1;w.updated_at=now();snap.kind='watch-reset-restored';audit(s,i,'discovery.restore-reset',wid);return dto(w)
    @app.get('/api/research/discovery')
    def inbox(request:Request,watch_id:str|None=None):
        with Session() as s:
            i=identity(request)
            if watch_id:own(s,i,watch_id,'literature-watch')
            profiles={w.id:w.payload for w in records(s,i,'literature-watch')};items=[]
            known={r.payload.get('doi') for r in visible_refs(s,i) if r.payload.get('doi')}
            for r in records(s,i,'discovery-item'):
                ids=[watch_id] if watch_id else r.payload.get('watch_ids',[])
                for wid in ids:
                    if wid not in profiles or wid not in r.payload.get('watch_ids',[]):continue
                    config=profiles[wid];rows,_=rank([r.payload],{**config,'semantic_rerank':False})
                    if not rows:continue
                    item=dto(r);fresh=rows[0]['relevance'];saved=r.payload.get('watch_scores',{}).get(wid)
                    item['relevance']=saved if saved and saved.get('version')==VERSION else fresh
                    item['status']=r.payload.get('watch_statuses',{}).get(wid,r.payload.get('status','new'))
                    if item['reference'].get('doi') in known and item['status']=='new':item['status']='known'
                    item['query']=config['query'];item['watch_id']=wid;items.append(item);break
            return sorted(items,key=lambda r:(r['relevance']['score'],r['discovered_at']),reverse=True)[:300]
    @app.post('/api/research/discovery/{rid}/add')
    def add_reference(rid:str,req:AddDiscovery,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:return add(s,i,own(s,i,rid,'discovery-item'),req.project_ids)
    @app.post('/api/research/discovery/{rid}/dismiss')
    def dismiss(rid:str,req:WatchContext,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=own(s,i,rid,'discovery-item')
            if req.watch_id:
                own(s,i,req.watch_id,'literature-watch')
                if req.watch_id not in r.payload.get('watch_ids',[]):raise HTTPException(404,'Proposal unavailable')
                r.payload={**r.payload,'watch_statuses':{**r.payload.get('watch_statuses',{}),req.watch_id:'dismissed'}}
            else:r.payload={**r.payload,'status':'dismissed','watch_statuses':{wid:'dismissed' for wid in r.payload.get('watch_ids',[])}}
            r.revision+=1;return dto(r)
    app.state.discovery=Scheduler(app.state.settings,Session,run)
