"""Bound actual ASGI request bytes before any multipart parser allocation."""
from starlette.responses import JSONResponse
from .security import authenticate
from fastapi import HTTPException

class BodyLimit:
    def __init__(self, app, settings):
        self.app,self.settings=app,settings
        self.limit=(settings.max_upload_mb+1)*1024*1024
    async def __call__(self, scope, receive, send):
        if scope['type']!='http' or not scope.get('path','').startswith('/api/') or scope.get('method') not in {'POST','PUT','PATCH'}:
            return await self.app(scope,receive,send)
        headers={k.decode().lower():v.decode() for k,v in scope['headers']}
        try: authenticate(headers.get('authorization'),self.settings)
        except HTTPException as exc:
            return await JSONResponse({'detail':exc.detail},status_code=exc.status_code,headers=exc.headers)(scope,receive,send)
        length=headers.get('content-length')
        if length is None:
            return await JSONResponse({'detail':'Content-Length required'},status_code=411)(scope,receive,send)
        try: valid=0<=int(length)<=self.limit
        except ValueError: valid=False
        if not valid:
            return await JSONResponse({'detail':'Body limit exceeded'},status_code=413)(scope,receive,send)
        parts=[];total=0
        while True:
            message=await receive()
            if message['type']=='http.disconnect': return
            total+=len(message.get('body',b''))
            if total>self.limit:
                return await JSONResponse({'detail':'Body limit exceeded'},status_code=413)(scope,receive,send)
            parts.append(message.get('body',b''))
            if not message.get('more_body',False): break
        first=True
        async def replay():
            nonlocal first
            if first:
                first=False
                return {'type':'http.request','body':b''.join(parts),'more_body':False}
            return await receive()
        await self.app(scope,replay,send)
