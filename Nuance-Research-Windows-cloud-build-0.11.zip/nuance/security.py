import secrets
from fastapi import HTTPException

def authenticate(header, settings):
    token = (header or "").removeprefix("Bearer ") if (header or "").startswith("Bearer ") else ""
    for key, identity in settings.keys.items():
        if secrets.compare_digest(token, key): return dict(identity)
    raise HTTPException(401, "Invalid bearer credential", headers={"WWW-Authenticate": "Bearer"})

def require_editor(identity):
    if identity["role"] not in {"admin", "editor"}: raise HTTPException(403, "Editor role required")

def can_read(obj, identity):
    return obj.tenant == identity["tenant"] and (identity["role"] == "admin" or obj.owner == identity["user"] or identity["user"] in obj.readers or "*" in obj.readers)

def can_manage(obj, identity):
    return obj.tenant == identity["tenant"] and identity["role"] in {"admin", "editor"} and (identity["role"] == "admin" or obj.owner == identity["user"])
