"""Persistent lexical indexes. Authorization is applied before top-k selection."""
import re
from sqlalchemy import text, bindparam

def install_index(engine):
    with engine.begin() as c:
        if engine.dialect.name == 'sqlite':
            # A regular FTS table stores identifiers as well as searchable text.
            # Triggers also cover deletes, rollback, and writes outside the API.
            c.exec_driver_sql('CREATE VIRTUAL TABLE IF NOT EXISTS chunk_fts USING fts5(chunk_id UNINDEXED, document_id UNINDEXED, body, tokenize="unicode61 remove_diacritics 2")')
            c.exec_driver_sql("CREATE TRIGGER IF NOT EXISTS chunk_fts_insert AFTER INSERT ON chunks BEGIN INSERT INTO chunk_fts(rowid,chunk_id,document_id,body) VALUES(new.rowid,new.id,new.document_id,new.text); END")
            c.exec_driver_sql("CREATE TRIGGER IF NOT EXISTS chunk_fts_delete AFTER DELETE ON chunks BEGIN DELETE FROM chunk_fts WHERE rowid=old.rowid; END")
            c.exec_driver_sql("CREATE TRIGGER IF NOT EXISTS chunk_fts_update AFTER UPDATE OF text,document_id,id ON chunks BEGIN DELETE FROM chunk_fts WHERE rowid=old.rowid; INSERT INTO chunk_fts(rowid,chunk_id,document_id,body) VALUES(new.rowid,new.id,new.document_id,new.text); END")
            # Incremental migration of existing libraries: embeddings stay intact.
            c.exec_driver_sql('INSERT INTO chunk_fts(rowid,chunk_id,document_id,body) SELECT c.rowid,c.id,c.document_id,c.text FROM chunks c WHERE NOT EXISTS (SELECT 1 FROM chunk_fts f WHERE f.rowid=c.rowid)')
        elif engine.dialect.name == 'postgresql':
            c.exec_driver_sql("CREATE INDEX IF NOT EXISTS chunks_text_search ON chunks USING gin(to_tsvector('simple', text))")
        else:
            raise ValueError('Indexed search requires SQLite FTS5 or PostgreSQL')

def lexical_search(session, query, documents, limit):
    dialect=session.get_bind().dialect.name
    method=('SQLite FTS5 BM25; index-wide frequency statistics; ACL filter before top-k' if dialect=='sqlite' else 'PostgreSQL full-text ts_rank_cd (not BM25); ACL filter before top-k')
    terms=list(dict.fromkeys(re.findall(r'[^\W_]+',query,flags=re.UNICODE)))[:64]
    if not documents or not terms: return {},method
    if dialect=='sqlite':
        match=' OR '.join('"'+term+'"' for term in terms)
        sql='SELECT chunk_id, -bm25(chunk_fts,0,0,1) AS score FROM chunk_fts WHERE chunk_fts MATCH :q AND document_id IN :docs ORDER BY bm25(chunk_fts,0,0,1),chunk_id LIMIT :lim'
    else:
        match=' | '.join(terms)
        sql="SELECT id AS chunk_id, ts_rank_cd(to_tsvector('simple',text),to_tsquery('simple',:q)) AS score FROM chunks WHERE document_id IN :docs AND to_tsvector('simple',text) @@ to_tsquery('simple',:q) ORDER BY score DESC,id LIMIT :lim"
    statement=text(sql).bindparams(bindparam('docs',expanding=True))
    return {row.chunk_id:float(row.score) for row in session.execute(statement,{'q':match,'docs':documents,'lim':limit})},method
