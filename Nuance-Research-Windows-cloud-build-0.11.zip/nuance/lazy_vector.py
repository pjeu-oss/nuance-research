from .resource_guard import spawn_worker,read_reply
import json,subprocess,sys,threading,os
from pathlib import Path

class IdleVectorStore:
    """Same Qdrant storage, ownership and filters; no in-memory vector copy at rest."""
    def __init__(self,settings,embedder):
        self.settings=settings;self.name='nuance_'+embedder.fingerprint
        self.config={'data_dir':settings.data_dir,'threads':settings.cpu_threads,'fingerprint':embedder.fingerprint,'dimension':embedder.dimension,'backend':embedder.backend}
        self.process=None;self.timer=None;self.lock=threading.RLock();self.last_runtime=None;self.completed_cpu=0.
    def _read(self):
        return read_reply(self.process,timeout=getattr(self.settings,'worker_timeout_seconds',180))
    def _write(self,payload):self.process.stdin.write(json.dumps(payload)+'\n');self.process.stdin.flush()
    def _call(self,payload):
        with self.lock:
            if self.timer:self.timer.cancel()
            if self.process is None or self.process.poll() is not None:
                self.close()
                env=os.environ.copy();env['PYTHONPATH']=str(Path(__file__).resolve().parent.parent)+os.pathsep+env.get('PYTHONPATH','')
                for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):env[key]=str(self.settings.cpu_threads)
                self.process=spawn_worker(([sys.executable,'--nuance-worker','vector'] if getattr(sys,'frozen',False) else [sys.executable,'-u','-m','nuance.vector_worker']),env,self.settings,'vector')
                try:self._write(self.config);self._read()
                except Exception:self.close();raise
            try:
                self._write(payload);reply=self._read();self.last_runtime=reply['runtime'];return reply['result']
            except Exception:
                self.close();raise
            finally:
                self.timer=threading.Timer(self.settings.model_idle_seconds,self.close);self.timer.daemon=True;self.timer.start()
    def search(self,tenant,documents,vector,sparse,limit,exact=False):
        # Empty scopes should not start or open a private vector collection.
        if not documents:return {},{}
        dense,sp=self._call(dict(op='search',tenant=tenant,documents=documents,vector=vector,sparse={int(k):v for k,v in sparse.items()},limit=limit,exact=exact))
        return dense,sp
    def upsert(self,chunks,tenant,document,sparse):
        self._call(dict(op='upsert',chunks=[{'id':c.id,'vector':c.vector} for c in chunks],tenant=tenant,document=document,sparse=sparse))
    def delete(self,tenant,document):self._call(dict(op='delete',tenant=tenant,document=document))
    def status(self):
        with self.lock:
            active=self.process is not None and self.process.poll() is None
            return {'active':active,'idle_release_seconds':self.settings.model_idle_seconds,'last_sample_memory_bytes':self.last_runtime.get('memory_bytes') if active and self.last_runtime else 0,'cpu_seconds':self.completed_cpu+(self.last_runtime.get('cpu_seconds',0) if active and self.last_runtime else 0)}
    def close(self):
        with self.lock:
            if self.timer:self.timer.cancel();self.timer=None
            if self.process is not None:
                if self.process.poll() is None:
                    self.process.terminate()
                    try:self.process.wait(timeout=3)
                    except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
                if self.last_runtime:self.completed_cpu+=self.last_runtime.get('cpu_seconds',0)
                self.last_runtime=None;self.process.stdin.close();self.process.stdout.close();self.process=None
