"""Private research workspace. Source access is rechecked on every request."""
import json, re, math
from collections import Counter
from typing import Literal
from fastapi import HTTPException, Request, UploadFile, File, Query
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from pathlib import Path
from .db import ResearchRecord, Document, Collection, Chunk, Page, audit, now, uid
from .writing import validate_payload, import_document, export_docx
from .security import require_editor
from .retrieval import scope
from .bibliography import enrich_reference,reference_to_csl,format_reference,metadata_missing

class SaveRecord(BaseModel):
    revision: int = Field(ge=0)
    payload: dict
class ImportRequest(BaseModel):
    format: Literal['ris','csl-json']
    text: str = Field(max_length=8_000_000)
class SuggestRequest(BaseModel):
    query: str = Field(min_length=1,max_length=2000)
    collection_id: str | None = None
    project_ids: list[str] | None = Field(default=None,max_length=20)
class MapRequest(BaseModel):
    article: str = Field(default='',max_length=200000)
    topics: int = Field(default=8,ge=2,le=20)
    project_ids: list[str] | None = Field(default=None,max_length=20)

class ProjectRequest(BaseModel):
    name: str = Field(min_length=1,max_length=200)
    reference_ids: list[str] = Field(default_factory=list,max_length=10000)
    revision: int = Field(default=0,ge=0)
class MetadataRequest(BaseModel):
    reference_ids: list[str] = Field(min_length=1,max_length=10)
    mode: Literal['local','crossref','grobid'] = 'local'
    online_consent: bool = False
    apply_safe: bool = False
class ApplyMetadata(BaseModel):
    revision: int = Field(ge=0)
    fields: list[str] | None = Field(default=None,max_length=30)

class MetaRequest(BaseModel):
    measure: Literal['SMD','MD','logOR','logRR']
    outcome: str = Field(min_length=1,max_length=300)
    timepoint: str = Field(min_length=1,max_length=100)
    rows: list[dict] = Field(min_length=2,max_length=500)
    comparability_confirmed: bool = False

def clean_reference(item):
    if not isinstance(item,dict): raise ValueError('Each reference must be an object')
    authors=item.get('author',item.get('authors',[]))
    if not isinstance(authors,list): authors=[authors]
    names=[]
    for a in authors:
        names.append(str(a.get('literal') or ' '.join(filter(None,[a.get('family'),a.get('given')])) if isinstance(a,dict) else a)[:300])
    issued=item.get('issued',{})
    parts=issued.get('date-parts',[]) if isinstance(issued,dict) else []
    year=item.get('year') or (parts[0][0] if parts and parts[0] else None) or item.get('date')
    match=re.search(r'\b(1[5-9]\d{2}|20\d{2}|2100)\b',str(year or ''))
    doi=str(item.get('DOI',item.get('doi',''))).strip().lower()
    doi=re.sub(r'^https?://(?:dx\.)?doi.org/','',doi)
    title=str(item.get('title','')).strip()[:1000]
    if not title: raise ValueError('Reference without a title')
    result={'title':title,'authors':names,'year':int(match.group()) if match else None,'doi':doi[:500],
      'journal':str(item.get('container-title',item.get('journal','')))[:500],
      'abstract':str(item.get('abstract',''))[:30000], 'tags':[str(t)[:200] for t in item.get('tags',[])][:100],
      'notes':str(item.get('notes',''))[:30000], 'document_id':None}
    return enrich_reference(item,result)

def parse_references(fmt,text):
    if fmt=='csl-json':
        raw=json.loads(text)
        if not isinstance(raw,list): raise ValueError('CSL JSON must be an array')
    else:
        raw=[]; row={}; last=None
        for line in text.splitlines():
            m=re.match(r'^([A-Z0-9]{2})  - ?(.*)$',line)
            if not m:
                if line.strip() and last: row[last][-1]+=' '+line.strip()
                continue
            key,value=m.groups()
            if key=='TY':
                if row: raise ValueError('RIS record missing ER terminator')
                row={'TY':[value]}; last='TY'
            elif key=='ER':
                if row:
                    first=lambda *ks: next((row[k][0] for k in ks if row.get(k)),'')
                    raw.append({'type':{'JOUR':'article-journal','BOOK':'book','CHAP':'chapter','RPRT':'report','STAT':'legislation','THES':'thesis','ELEC':'webpage'}.get(first('TY'),'document'),'publisher':first('PB'),'publisher_place':first('CY'),'volume':first('VL'),'issue':first('IS'),'pages':first('SP')+('-'+first('EP') if first('EP') else ''),'isbn':first('SN'),'url':first('UR'),'date':first('DA'),'series':first('T3'),'title':first('TI','T1'),'authors':row.get('AU',row.get('A1',[])),
                      'year':first('PY','Y1','DA'),'doi':first('DO'),'journal':first('JO','JF','T2'),
                      'abstract':first('AB','N2'),'tags':row.get('KW',[]),'notes':first('N1')})
                row={};last=None
            else: row.setdefault(key,[]).append(value);last=key
        if row: raise ValueError('RIS record missing ER terminator')
    if len(raw)>10000: raise ValueError('At most 10000 references per import')
    return [clean_reference(v) for v in raw]

def reference_key(payload):
    return 'doi:'+payload['doi'] if payload.get('doi') else 'title:'+re.sub(r'\W+','',payload['title'].casefold())+':'+str(payload.get('year'))

def meta_analysis(req):
    if not req.comparability_confirmed: raise HTTPException(422,'Confirm comparability of outcome, population, measure, units, timepoint and independent studies')
    studies=set(); rows=[]
    for row in req.rows:
        if row.get('validated') is not True or not str(row.get('source','')).strip() or not str(row.get('study_id','')).strip():
            raise HTTPException(422,'Every row needs source, unique study_id and explicit validation')
        sid=str(row['study_id'])
        if sid in studies: raise HTTPException(422,'One independent effect per study required')
        studies.add(sid)
        try: y=float(row['effect']); se=float(row['se'])
        except (ValueError,TypeError,KeyError): raise HTTPException(422,'Numeric effect and standard error required')
        if not math.isfinite(y) or not math.isfinite(se) or not 1e-8<=se<=1e8 or abs(y)>1e8: raise HTTPException(422,'Invalid effect or standard error')
        rows.append({'study_id':sid,'source':str(row['source'])[:1000],'effect':y,'se':se,'variance':se*se})
    weights=[1/r['variance'] for r in rows]; total=sum(weights)
    fixed=sum(w*r['effect'] for w,r in zip(weights,rows))/total
    q=sum(w*(r['effect']-fixed)**2 for w,r in zip(weights,rows)); df=len(rows)-1
    denominator=total-sum(w*w for w in weights)/total
    if denominator<=0: raise HTTPException(422,'Numerically unstable variances; inspect data')
    tau2=max(0.,(q-df)/denominator); random_weights=[1/(r['variance']+tau2) for r in rows]
    total_random=sum(random_weights); pooled=sum(w*r['effect'] for w,r in zip(random_weights,rows))/total_random
    uncertainty=math.sqrt(1/total_random)
    for r,w in zip(rows,random_weights):r.update(ci95=[r['effect']-1.95996398454*r['se'],r['effect']+1.95996398454*r['se']],weight_percent=100*w/total_random)
    return {'method':'Random effects inverse variance; DerSimonian-Laird tau²; normal 95% CI',
      'measure':req.measure,'outcome':req.outcome,'timepoint':req.timepoint,'k':len(rows),'pooled':pooled,
      'se':uncertainty,'ci95':[pooled-1.95996398454*uncertainty,pooled+1.95996398454*uncertainty],
      'Q':q,'I2_percent':100*max(0.,(q-df)/q) if q>0 else 0.,'tau2':tau2,'studies':rows,
      'warning':'Exploratory calculation. Normal CI and DL may underestimate uncertainty with few studies. No risk-of-bias assessment, dependence correction, REML/HKSJ or publication-bias test. LogOR/logRR outputs stay on log scale.'}


def normalized_title(title):
    import unicodedata
    return re.sub(r'[^a-z0-9]+','',unicodedata.normalize('NFKD',title.casefold()).encode('ascii','ignore').decode())

def find_duplicates(refs,hashes):
    from difflib import SequenceMatcher
    groups=[]; memberships={}; exact_groups={}
    for r in refs:
        keys=[]
        if r.get('doi'):keys.append(('doi',r['doi']))
        if hashes.get(r.get('document_id')):keys.append(('file_sha256',hashes[r['document_id']]))
        title=normalized_title(r['title'])
        if len(title)>=15:keys.append(('title',title))
        for key in keys:exact_groups.setdefault(key,[]).append(r['id'])
    seen=set()
    for (reason,value),ids in exact_groups.items():
        if len(ids)>1:
            signature=tuple(sorted(ids))
            if signature not in seen:
                seen.add(signature);groups.append({'ids':ids,'reason':reason,'confidence':'exact signal; check metadata before merging'})
    # Near-title candidates use inverted word buckets, avoiding an all-library N² comparison.
    buckets={};candidates=set();titles={r['id']:normalized_title(r['title']) for r in refs};lookup={r['id']:r for r in refs}
    for r in refs:
        for word in set(re.findall(r'[a-z]{5,}',r['title'].casefold())):
            peers=buckets.setdefault(word,[])
            if len(peers)<80:
                for peer in peers:candidates.add(tuple(sorted([peer,r['id']])))
                peers.append(r['id'])
    truncated=len(candidates)>50000
    for left,right in sorted(candidates)[:50000]:
        a,b=lookup[left],lookup[right]
        if a.get('doi') and b.get('doi') and a['doi']!=b['doi']:continue
        if a.get('year') and b.get('year') and a['year']!=b['year']:continue
        if (left,right) in seen or len(titles[left])<25:continue
        ratio=SequenceMatcher(None,titles[left],titles[right]).ratio()
        if .92<=ratio<1:groups.append({'ids':[left,right],'reason':'similar_title','similarity':ratio,'confidence':'candidate, not confirmed duplicate'})
    return {'groups':groups,'references_scanned':len(refs),'near_title_candidates_truncated':truncated,'warning':'No automatic merges. Common/generic titles and editions may differ. Near-title search uses bounded candidate buckets.'}

def export_bibtex(refs):
    escapes={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','%':r'\%','&':r'\&','_':r'\_','#':r'\#','$':r'\$','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    def tex(value):return ''.join(escapes.get(c,c) for c in re.sub(r'\s+',' ',str(value)).strip())
    entries=[]
    for r in refs:
        key='ref'+re.sub(r'[^A-Za-z0-9]','',r['id'])
        fields={'title':'{'+tex(r['title'])+'}'}
        if r.get('authors'):fields['author']=' and '.join(tex(a) for a in r['authors'])
        for field,source in [('year','year'),('journal','journal'),('doi','doi'),('publisher','publisher'),('volume','volume'),('number','issue'),('pages','pages'),('edition','edition'),('isbn','isbn'),('url','url'),('series','series'),('booktitle','book_title'),('institution','institution')]:
            if r.get(source):fields[field]=tex(r[source])
        if r.get('number'):fields['number']=tex(r['number'])
        if r.get('authority') or r.get('jurisdiction'):fields['note']=tex(' · '.join(filter(None,[r.get('authority'),r.get('jurisdiction'),r.get('date')])))
        entries.append('@'+({'article-journal':'article','book':'book','chapter':'incollection','report':'techreport','thesis':'phdthesis'}.get(r.get('type'),'article' if r.get('journal') else 'misc'))+'{'+key+',\n'+',\n'.join('  '+k+' = {'+v+'}' for k,v in fields.items())+'\n}')
    return '% Nuance-Research UTF-8 export; check author names and missing metadata.\n\n'+'\n\n'.join(entries)+'\n'

TOPIC_STOP_WORDS=list(set("the and for with from dans les des une pour sur de of et la le in du au aux par ces cette est sont qui que comme plus pas nous vous leurs leur ses son sa un ce to as on is are was were be been it its this that these those by or an at not our can may also have has using used use study studies research paper article review results conclusion figure table copyright reserved doi http https www com org edu pdf js viewer html xml txt docx md javascript elsevier springer downloaded download author authors journal volume pages page abstract introduction references full text etal accepted published publication preprint manuscript university press all rights based et al peer licence license en chez between into through how which both other such than two each some many data document documents file files access open new retrieved available source sources und von der die das mit zu im den nih ncbi pmc pubmed sciencedirect reader enhanced télécharger téléchargé téléchargement via presses universitaires france ieee trans proceedings sat udo etal fig figures header footer cookie cookies browser javascript moderator peut être selon dont ainsi même entre sous tout toute tous toutes sans avec aussi encore cependant lorsque".split()))

def clean_topic_text(value):
    # Remove URLs, identifiers, file suffixes and code before extracting scientific terms.
    value=re.sub(r'https?://\S+|www\.\S+|10\.\d{4,9}/\S+',' ',value,flags=re.I)
    value=re.sub(r'\b[^\s]+\.(?:pdf|js|xml|html|txt|docx|md)\b',' ',value,flags=re.I)
    value=re.sub(r'\b[0-9a-f]{12,}\b|\b\w*\d\w*\b',' ',value,flags=re.I)
    return value.lower().replace('_',' ')

def topic_keywords(terms,scores):
    ranked=sorted(range(len(terms)),key=lambda j:(-float(scores[j]),str(terms[j])))
    selected=[]
    # Prefer meaningful phrases where their score is comparable to the top unigram.
    peak=max(scores,default=0)
    phrases=[j for j in ranked if ' ' in terms[j] and scores[j]>=peak*.35]
    for j in phrases+ranked:
        term=str(terms[j])
        if scores[j]<=0 or term in selected or (len(term.split())>1 and len(set(term.split()))==1):continue
        if any(set(term.split())<=set(old.split()) or set(old.split())<=set(term.split()) for old in selected):continue
        selected.append(term)
        if len(selected)==3:break
    return selected

def topic_map(refs,docs,s,embedder,article,topic_count):
    import numpy as np
    refs=sorted(refs,key=lambda ref:ref["id"])
    from sklearn.cluster import KMeans
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import PCA
    if not embedder.manifest.get('semantic'):raise HTTPException(409,'A neural embedding model is required for the semantic map')
    if len(refs)>10000:raise HTTPException(413,'Map limited to 10000 references')
    attached={r.get("document_id") for r in refs}
    docs=[d for d in docs if d.id in attached]
    docmap={d.id:d for d in docs}; bydoc={}; samples={}; model_mismatches=set()
    for d in docs:
        if d.provenance.get('embedding_fingerprint')!=embedder.fingerprint:model_mismatches.add(d.id)
    # Stream all accessible ingested vectors and average per source. No 200-candidate search cutoff.
    if docmap:
        for did,vector,source_text in s.execute(select(Chunk.document_id,Chunk.vector,Chunk.text).where(Chunk.document_id.in_(docmap)).order_by(Chunk.document_id,Chunk.page_id,Chunk.start)).yield_per(500):
            if did in model_mismatches:continue
            if len(samples.get(did,""))<8000:samples[did]=samples.get(did,"")+" "+source_text[:800]
            arr=np.asarray(vector,dtype=float)
            if did not in bydoc:bydoc[did]=[arr,1]
            else:bydoc[did][0]+=arr;bydoc[did][1]+=1
    texts=[];vectors=[];included=[];seen_docs=set();excluded=[]
    for r in refs:
        did=r.get('document_id')
        if did and did in seen_docs:excluded.append({'id':r['id'],'reason':'same attached document already represented'});continue
        if did in bydoc:
            vector=bydoc[did][0]/bydoc[did][1]
            if did:seen_docs.add(did)
        else:
            if did in model_mismatches:excluded.append({'id':r['id'],'reason':'embedding model mismatch'});continue
            text=(r['title']+' '+r.get('abstract',''))[:20000]
            vector=np.asarray(embedder.encode([text])[0][0],dtype=float)
        norm=np.linalg.norm(vector)
        if norm==0:excluded.append({'id':r['id'],'reason':'zero vector'});continue
        vectors.append(vector/norm);included.append(r);texts.append(clean_topic_text((r['title']+' ')*3+' '+r.get('abstract','')+' '+samples.get(did,'')))
    if len(vectors)<2:raise HTTPException(422,'At least two accessible distinct references are required')
    x=np.vstack(vectors);k=min(topic_count,len(x),len(np.unique(np.round(x,8),axis=0)))
    model=KMeans(n_clusters=k,random_state=42,n_init=10).fit(x);centers=model.cluster_centers_
    centers=centers/np.maximum(np.linalg.norm(centers,axis=1,keepdims=True),1e-12)
    # PCA provides a reproducible two-dimensional projection, not a proof of conceptual absence.
    coordinates=PCA(n_components=min(2,k,len(x[0]))).fit_transform(centers) if k>1 else np.zeros((1,2))
    if coordinates.shape[1]==1:coordinates=np.column_stack([coordinates,np.zeros(k)])
    topic_texts=[' '.join(texts[j] for j in np.where(model.labels_==i)[0]) for i in range(k)]
    try:
        tfidf=TfidfVectorizer(stop_words=TOPIC_STOP_WORDS,ngram_range=(1,3),token_pattern=r"(?u)\b[^\W\d_]{3,}\b",max_features=12000,sublinear_tf=True,min_df=2 if len(texts)>3 else 1,max_df=.7 if len(texts)>3 else 1.).fit(texts)
        terms=tfidf.get_feature_names_out();tf=tfidf.transform(texts)
    except ValueError:tf=None
    article_vector=None
    if article.strip():
        article_vector=np.asarray(embedder.encode([article[i:i+900] for i in range(0,len(article),900)])[0],dtype=float).mean(axis=0);article_vector/=max(np.linalg.norm(article_vector),1e-12)
    nodes=[]
    for index in range(k):
        positions=np.where(model.labels_==index)[0];members=[included[j] for j in positions]
        label='Topic '+str(index+1)
        if tf is not None:
            scores=np.asarray(tf[positions].mean(axis=0)).ravel()
            keywords=topic_keywords(terms,scores)
            if keywords:label=' · '.join(keywords)
        sim=float(article_vector@centers[index]) if article_vector is not None else None
        nodes.append({'id':index,'label':label,'x':float(coordinates[index,0]),'y':float(coordinates[index,1]),'count':len(members),
            'density':float(np.mean(x[positions]@centers[index])),'article_similarity':sim,
            'representative_titles':[included[j]['title'] for j in sorted(positions,key=lambda j:float(x[j]@centers[index]),reverse=True)[:3]],
            'members':[{'id':r['id'],'title':r['title'],'year':r.get('year'),'basis':'full-text mean' if r.get('document_id') in bydoc else 'title/abstract'} for r in members]})
    edges=[];distances=[]
    for a in range(k):
        for b in range(a+1,k):
            similarity=float(centers[a]@centers[b]);distances.append({'source':a,'target':b,'cosine_distance':1-similarity})
            if similarity>=.35:edges.append({'source':a,'target':b,'similarity':similarity})
    return {'nodes':nodes,'edges':edges,'distances':distances,'excluded':excluded,'coverage':{'references':len(refs),'represented':len(included),'full_text_basis':sum(r.get('document_id') in bydoc for r in included)},
      'method':{'clustering':'KMeans on normalized mean document embeddings','projection':'PCA of normalized topic centroids','labeling':'document TF-IDF with up to three-word phrases on cleaned titles, abstracts and up to 8000 sampled text characters per document; labels are proposals','seed':42,'model':embedder.manifest,'edge_threshold':.35,'article_aggregation':'mean of 900-character windows','max_article_characters':200000},
      'warning':'Bubble area = represented reference count; opacity = within-topic cohesion, not quality. Coordinates approximate semantic distances in 2D; use pairwise cosine distances for analysis. Sparse areas do not demonstrate research gaps. Title/abstract-only records have weaker coverage. Duplicates attached as different documents may still inflate topic counts.'}

def install_research(app,Session,lock,searcher,identity,get_collection,get_doc,SearchRequest):
    def records(s,i,kind):
        return list(s.scalars(select(ResearchRecord).where(ResearchRecord.tenant==i['tenant'],ResearchRecord.owner==i['user'],ResearchRecord.kind==kind)))
    def visible_references(s,i):
        visible={d.id for d in scope(s,i)}
        return [r for r in records(s,i,'reference') if not r.payload.get('document_id') or r.payload['document_id'] in visible]
    def scoped_references(s,i,project_ids=None):
        refs=visible_references(s,i)
        if project_ids is None:return refs
        if len(project_ids)>20:raise HTTPException(422,'Select at most 20 projects')
        projects={r.id:r for r in records(s,i,'project')};members=set()
        for pid in project_ids:
            if pid not in projects:raise HTTPException(404,'Project unavailable')
            members.update(projects[pid].payload.get('reference_ids',[]))
        return [r for r in refs if r.id in members]
    @app.get('/api/research/projects')
    def list_projects(request:Request):
        with Session() as s:
            i=identity(request);visible={r.id for r in visible_references(s,i)}
            return [{**dto(r),'visible_references':len(set(r.payload.get('reference_ids',[]))&visible)} for r in records(s,i,'project')]
    @app.post('/api/research/projects')
    def create_project(req:ProjectRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            visible={r.id for r in visible_references(s,i)}
            if not set(req.reference_ids)<=visible:raise HTTPException(404,'Reference unavailable')
            if not req.name.strip():raise HTTPException(422,'Project name is empty')
            record=ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='project',payload={'name':req.name.strip(),'reference_ids':sorted(set(req.reference_ids))});s.add(record);s.flush();audit(s,i,'project.create',record.id);return dto(record)
    @app.put('/api/research/projects/{pid}')
    def update_project(pid:str,req:ProjectRequest,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            project=next((r for r in records(s,i,'project') if r.id==pid),None)
            if not project:raise HTTPException(404,'Project unavailable')
            if project.revision!=req.revision:raise HTTPException(409,'Project changed; reload before saving')
            visible={r.id for r in visible_references(s,i)};previous=set(project.payload.get('reference_ids',[]))
            # Hidden/revoked memberships may remain, but cannot be newly granted or leaked through source DTOs.
            if not (set(req.reference_ids)-previous)<=visible:raise HTTPException(404,'Reference unavailable')
            if not req.name.strip():raise HTTPException(422,'Project name is empty')
            project.payload={'name':req.name.strip(),'reference_ids':sorted(set(req.reference_ids))};project.revision+=1;project.updated_at=now();audit(s,i,'project.update',pid);return dto(project)
    def dto(r):return {'id':r.id,'revision':r.revision,'updated_at':r.updated_at,**r.payload}
    @app.get('/workspace')
    def workspace():return FileResponse(Path(__file__).parent/'static'/'workspace.html')
    @app.get('/api/research/references')
    def references(request:Request,project_ids:list[str]|None=Query(default=None)):
        with Session() as s:
            i=identity(request);docmap={d.id:d for d in scope(s,i)};cols={c.id:c.name for c in s.scalars(select(Collection).where(Collection.tenant==i['tenant']))}
            memberships={r.id:set(r.payload.get('reference_ids',[])) for r in records(s,i,'project')};proposals={r.payload.get('reference_id'):r for r in records(s,i,'metadata-proposal')}
            items=[]
            for r in scoped_references(s,i,project_ids):
                value=dto(r);value=enrich_reference(value,value);doc=docmap.get(value.get('document_id'));value['collection_name']=cols.get(doc.collection_id,'') if doc else '';value['missing_metadata']=metadata_missing(value);value['project_ids']=[pid for pid,members in memberships.items() if r.id in members];proposal=proposals.get(r.id);value['metadata_proposal_available']=bool(proposal and proposal.payload.get('base_revision')==r.revision and proposal.payload.get('result',{}).get('fields'));items.append(value)
            return items
    @app.post('/api/research/import')
    def import_library(req:ImportRequest,request:Request):
        i=identity(request);require_editor(i)
        try: items=parse_references(req.format,req.text)
        except (ValueError,TypeError,KeyError,IndexError):raise HTTPException(422,'Invalid reference export; use RIS with TY/ER records or CSL JSON')
        with lock,Session.begin() as s:
            known={reference_key(r.payload) for r in records(s,i,'reference')}; created=0;duplicates=0
            for p in items:
                k=reference_key(p)
                if k in known:duplicates+=1;continue
                known.add(k);p['import_provenance']={'format':req.format,'time':now()}
                s.add(ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='reference',payload=p));created+=1
            audit(s,i,'bibliography.import',str(created))
            return {'created':created,'duplicates':duplicates,'warning':'Attachments are imported separately; duplicate DOI or normalized title/year is skipped, not merged.'}
    @app.post('/api/research/sync-documents')
    def sync_documents(request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            all_refs=records(s,i,'reference');linked={r.payload.get('document_id') for r in [*all_refs,*records(s,i,'reference-trash')]};count=0
            for d in scope(s,i):
                if d.id in linked or d.metadata_json.get('kind','document')!='document':continue
                matches=[r for r in all_refs if not r.payload.get('document_id') and r.payload['title'].strip().casefold()==d.title.strip().casefold()]
                if len(matches)==1:
                    r=matches[0];r.payload={**r.payload,'document_id':d.id};r.revision+=1
                else:
                    p=clean_reference({**d.metadata_json,'title':d.title,**d.metadata_json.get('bibliography',{}).get('fields',{})});p['metadata_evidence']=d.metadata_json.get('bibliography',{}).get('evidence',{});p['document_id']=d.id;p['import_provenance']={'format':'extracted-document','source_sha256':d.sha256}
                    s.add(ResearchRecord(tenant=i['tenant'],owner=i['user'],kind='reference',payload=p))
                count+=1
            audit(s,i,'bibliography.sync',str(count));return {'linked_or_created':count}
    @app.put('/api/research/references/{rid}')
    def update_reference(rid:str,req:SaveRecord,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=next((v for v in visible_references(s,i) if v.id==rid),None)
            if not r:raise HTTPException(404,'Reference unavailable')
            if r.revision!=req.revision:raise HTTPException(409,'Reference changed; reload before saving')
            try:p=clean_reference(req.payload)
            except (ValueError,TypeError):raise HTTPException(422,'Invalid reference')
            did=req.payload.get('document_id')
            if did:get_doc(s,did,i);p['document_id']=did
            p['import_provenance']=r.payload.get('import_provenance');p['metadata_evidence']=r.payload.get('metadata_evidence',{});p['metadata_verified_fields']=sorted(set(r.payload.get('metadata_verified_fields',[]))|{k for k in p if k in req.payload and p.get(k)!=r.payload.get(k) and k not in {'notes','tags','document_id','type_inferred'}});r.payload=p;r.revision+=1;r.updated_at=now()
            audit(s,i,'reference.update',rid);return dto(r)
    @app.get('/api/research/export')
    def export(request:Request,project_ids:list[str]|None=Query(default=None)):
        with Session() as s:
            return [reference_to_csl(dto(r)) for r in scoped_references(s,identity(request),project_ids)]
    @app.get('/api/research/drafts')
    def draft_summaries(request:Request):
        with Session() as s:
            i=identity(request)
            rows=s.execute(select(ResearchRecord.id,ResearchRecord.revision,ResearchRecord.updated_at,ResearchRecord.payload['title'].as_string().label('title')).where(ResearchRecord.tenant==i['tenant'],ResearchRecord.owner==i['user'],ResearchRecord.kind=='draft').order_by(ResearchRecord.updated_at.desc()))
            return [dict(row._mapping) for row in rows]
    @app.get('/api/research/records/{kind}/{rid}')
    def record_detail(kind:Literal['draft','review'],rid:str,request:Request):
        with Session() as s:
            i=identity(request);r=s.get(ResearchRecord,rid)
            if not r or r.tenant!=i['tenant'] or r.owner!=i['user'] or r.kind!=kind:raise HTTPException(404,'Record unavailable')
            return dto(r)
    @app.post('/api/research/writing/import')
    def import_article(request:Request,file:UploadFile=File(...)):
        i=identity(request);require_editor(i)
        data=file.file.read(20*1024*1024+1)
        if len(data)>20*1024*1024:raise HTTPException(413,'Writing import limited to 20 MB')
        try:
            result=import_document(data,file.filename or '',app.state.settings)
        except Exception as exc:
            raise HTTPException(422,'Document import failed: use a valid DOCX, text PDF, TXT or MD file') from exc
        with Session.begin() as s:audit(s,i,'writing.import','local-document')
        return result
    @app.post('/api/research/writing/export.docx')
    def export_article(req:SaveRecord,request:Request):
        i=identity(request);require_editor(i)
        try:payload=validate_payload(req.payload)
        except (ValueError,TypeError,KeyError):raise HTTPException(422,'Invalid article')
        # Reuse the same exact-source validation as saving, without persisting a draft.
        with Session() as s:check_citations(s,i,payload.get('citations',[]))
        try:data=export_docx(payload)
        except (ValueError,TypeError,KeyError):raise HTTPException(422,'Invalid article layout')
        return Response(data,media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',headers={'Content-Disposition':'attachment; filename="article.docx"'})
    @app.post('/api/research/citation/format')
    def citation_format(payload:dict,request:Request):
        i=identity(request)
        with Session() as s:
            ref=next((r for r in [*visible_references(s,i),*records(s,i,'reference-trash')] if r.id==payload.get('reference_id')),None)
            if not ref:raise HTTPException(404,'Reference unavailable')
            if ref.payload.get('document_id'):get_doc(s,ref.payload['document_id'],i)
            page=None
            if payload.get('chunk_id'):
                chunk=s.get(Chunk,payload['chunk_id'])
                if not chunk or chunk.document_id!=ref.payload.get('document_id'):raise HTTPException(404,'Passage unavailable')
                get_doc(s,chunk.document_id,i);page=s.get(Page,chunk.page_id).number
            if payload.get('placement','inline') not in {'inline','footnote'}:raise HTTPException(422,'Invalid placement')
            try:return format_reference(dto(ref),payload.get('style','apa'),payload.get('placement','inline'),page)
            except ValueError:raise HTTPException(422,'Unsupported citation style')
    def check_citations(s,i,citations):
        if not isinstance(citations,list) or len(citations)>1000:raise HTTPException(422,'Invalid citation list')
        for citation in citations:
            if not isinstance(citation,dict):raise HTTPException(422,'Invalid citation')
            chunk=s.get(Chunk,citation.get('chunk_id',''))
            if not chunk:raise HTTPException(422,'Citation passage unavailable')
            doc=get_doc(s,chunk.document_id,i);page=s.get(Page,chunk.page_id)
            if citation.get('page')!=page.number or citation.get('title')!=doc.title:raise HTTPException(422,'Citation page/title do not match the source')
            if citation.get('quote')!=chunk.text or citation.get('document_id')!=doc.id or citation.get('source_sha256')!=doc.sha256:raise HTTPException(422,'Citation must match its exact source passage')
    @app.get('/api/research/records/{kind}')
    def list_records(kind:Literal['draft','review','analysis'],request:Request):
        with Session() as s:return [dto(r) for r in records(s,identity(request),kind)]
    @app.put('/api/research/records/{kind}/{rid}')
    def save_record(kind:Literal['draft','review'],rid:str,req:SaveRecord,request:Request):
        i=identity(request);require_editor(i)
        if len(json.dumps(req.payload))>2_000_000:raise HTTPException(413,'Research record too large')
        with lock,Session.begin() as s:
            r=s.get(ResearchRecord,rid)
            if r and (r.tenant!=i['tenant'] or r.owner!=i['user'] or r.kind!=kind):raise HTTPException(404,'Record unavailable')
            if not r:
                if req.revision!=0:raise HTTPException(409,'New record requires revision 0')
                if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',rid):raise HTTPException(422,'Invalid record identifier')
                r=ResearchRecord(id=rid,tenant=i['tenant'],owner=i['user'],kind=kind,payload={},revision=0);s.add(r)
            if r.revision!=req.revision:raise HTTPException(409,'Newer version exists; reload before saving')
            if kind=='draft':
                try:req.payload=validate_payload(req.payload)
                except (ValueError,TypeError,KeyError):raise HTTPException(422,'Invalid rich article document')
                scoped_references(s,i,req.payload.get('project_ids'))
                check_citations(s,i,req.payload.get('citations',[]))
            r.payload=req.payload;r.revision+=1;r.updated_at=now();audit(s,i,kind+'.save',rid);return dto(r)
    @app.post('/api/research/suggest')
    def suggest(req:SuggestRequest,request:Request):
        i=identity(request)
        with lock,Session() as s:
            if req.collection_id:get_collection(s,req.collection_id,i)
            refs={r.payload.get('document_id'):r for r in scoped_references(s,i,req.project_ids)}
            result=searcher.search(s,i,SearchRequest(query=req.query,collection_id=req.collection_id,document_ids=[did for did in refs if did],limit=6,content_kind='document'))
            result['project_ids']=req.project_ids
            result['results']=[item for item in result['results'] if item['document_id'] in refs]
            for item in result['results']:
                r=refs.get(item['document_id']);item['reference']=dto(r) if r else None
            return result
    @app.get('/api/research/statistics')
    def statistics(request:Request):
        with Session() as s:
            refs=visible_references(s,identity(request));ps=[r.payload for r in refs]
            count=lambda values:dict(Counter(values).most_common())
            return {'references':len(ps),'full_texts':sum(bool(p.get('document_id')) for p in ps),
              'missing_year':sum(p.get('year') is None for p in ps),'years':count(str(p['year']) for p in ps if p.get('year')),
              'authors':count(a for p in ps for a in set(p['authors'])),'themes':count(t for p in ps for t in set(p['tags'])),
              'journals':count(p['journal'] for p in ps if p['journal']),
              'warning':'Descriptive metadata counts, not study quality or causal evidence. Author names are not disambiguated.'}
    @app.post('/api/research/references/{rid}/archive')
    def archive_reference(rid:str,req:SaveRecord,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=next((r for r in visible_references(s,i) if r.id==rid),None)
            if not r:raise HTTPException(404,'Reference unavailable')
            if req.revision!=r.revision:raise HTTPException(409,'Reference changed; reload')
            r.kind='reference-trash';r.revision+=1;r.updated_at=now();audit(s,i,'reference.archive',rid)
            return {'id':rid,'revision':r.revision,'restorable':True}
    @app.get('/api/research/trash')
    def trash(request:Request):
        i=identity(request)
        with Session() as s:
            visible={d.id for d in scope(s,i)}
            return [dto(r) for r in records(s,i,'reference-trash') if not r.payload.get('document_id') or r.payload['document_id'] in visible]
    @app.post('/api/research/references/{rid}/restore')
    def restore_reference(rid:str,req:SaveRecord,request:Request):
        i=identity(request);require_editor(i)
        with lock,Session.begin() as s:
            r=next((r for r in records(s,i,'reference-trash') if r.id==rid),None)
            if not r:raise HTTPException(404,'Reference unavailable')
            if r.payload.get('document_id'):get_doc(s,r.payload['document_id'],i)
            if req.revision!=r.revision:raise HTTPException(409,'Reference changed; reload')
            r.kind='reference';r.revision+=1;r.updated_at=now();audit(s,i,'reference.restore',rid);return dto(r)
    @app.get('/api/research/duplicates')
    def duplicates(request:Request):
        with Session() as s:
            refs=visible_references(s,identity(request))
            return find_duplicates([dto(r) for r in refs],{d.id:d.sha256 for d in scope(s,identity(request))})
    @app.get('/api/research/export.bib')
    def bibtex(request:Request,project_ids:list[str]|None=Query(default=None)):
        with Session() as s:
            return Response(export_bibtex([dto(r) for r in scoped_references(s,identity(request),project_ids)]),media_type='application/x-bibtex',headers={'Content-Disposition':'attachment; filename="bibliography.bib"'})
    @app.post('/api/research/search')
    def library_search(req:SearchRequest,request:Request):
        with lock,Session.begin() as s:
            i=identity(request)
            documents=sorted({r.payload.get('document_id') for r in scoped_references(s,i,req.project_ids) if r.payload.get('document_id')})
            selected=documents if req.document_ids is None else sorted(set(documents)&set(req.document_ids))
            result=searcher.search(s,i,req.model_copy(update={'document_ids':selected}))
            audit(s,i,'research.search',req.mode+':'+req.scientific_mode)
            return result
    @app.post('/api/research/map')
    def conceptual_map(req:MapRequest,request:Request):
        with lock,Session() as s:
            i=identity(request); refs=[dto(r) for r in scoped_references(s,i,req.project_ids)]; docs=scope(s,i)
            result=topic_map(refs,docs,s,searcher.embedder,req.article,req.topics)
            result['project_ids']=req.project_ids
            from .runtime import release_unused_memory
            release_unused_memory()
            return result

    from .metadata_routes import install_metadata_routes
    install_metadata_routes(app,Session,lock,identity,get_doc,visible_references,records,dto,clean_reference)

    @app.post('/api/research/meta-analysis')
    def calculate_meta(req:MetaRequest,request:Request):
        i=identity(request);require_editor(i);result=meta_analysis(req)
        with lock,Session.begin() as s:
            r=ResearchRecord(id=uid(),tenant=i['tenant'],owner=i['user'],kind='analysis',payload={'input':req.model_dump(),'result':result});s.add(r)
            audit(s,i,'meta-analysis.calculate',r.id);return {'id':r.id,**result}

    from .reading import install_reading
    install_reading(app,Session,lock,identity,get_doc,visible_references,records,dto)
    from .discovery import install_discovery
    install_discovery(app,Session,lock,identity,visible_references,scoped_references,records,dto,clean_reference)
