# Interface et performances — Nuance-Research 0.5

## Interface

La bibliothèque intègre la recherche documentaire : bouton Filtres, champ de recherche, mode scientifique et bouton Avancé. Filtres contient les critères de notice (titre, auteur, thème), collection et concept. Les critères de notice filtrent la liste bibliographique ; collection et concept limitent la recherche des passages. Les résultats intégrés utilisent uniquement les documents associés aux références actives de la bibliothèque : les sources retirées ne sont plus proposées. Avancé contient Search/Quotes/Explore/Topics/Ask, nombre de résultats, reranking, gestion des collections/concepts, association de concepts et registre des modèles. Import, exports, corbeille et découverte de thèmes restent dans la bibliothèque.

Les surfaces sont blanches et gris clair ; le brun Nuance reste un accent. Le logo est conservé. Cinquante références sont rendues par page, avec navigation ; toutes les sources restent utilisables par le moteur. Les sources sans métadonnées fiables affichent encore leur nom de fichier : les noms des notices ne sont pas inventés.

## Intitulés de carte

Le regroupement utilise les embeddings existants. Les noms de thèmes sont proposés à partir de titres, résumés et jusqu’à 8 000 caractères de passages échantillonnés par document, avec suppression des URL, identifiants, extensions et termes de lecteurs PDF. TF-IDF sur les documents, expressions de un à trois mots. Ce ne sont pas des catégories validées ni des titres générés par LLM. Une bulle donne accès aux sources représentatives et à tous ses documents. Les espaces vides ne démontrent pas une lacune de la littérature.

Exemples réellement obtenus sur cette bibliothèque : technology acceptance / information systems, international relations / civil society, vie privée / protection des données, artificial intelligence / world models, EEG / brain–computer interfaces. Les noms restent exploratoires et dépendent de la qualité des textes importés.

## Réduction de l’impact système

- Deux threads de calcul par défaut (`NUANCE_CPU_THREADS=2`) et parallélisme du tokenizer désactivé.
- Dans le profil local SentenceTransformer, le modèle et Qdrant embarqué vivent dans deux processus locaux chargés à la demande. Ils se ferment après 30 secondes sans opération (`NUANCE_MODEL_IDLE_SECONDS`). Les embeddings et fichiers existants restent sur disque.
- Recherche lexicale sans lancer ces processus. Cache de requêtes et de résultats ; un résultat en cache ne relance pas les modèles.
- Suggestions après deux secondes de pause de rédaction ; aucun nouveau calcul automatique lorsque la page est masquée. Annulation des requêtes obsolètes côté interface ; une opération serveur déjà commencée peut terminer.
- Carte calculée uniquement sur demande. Restitution de mémoire inutilisée après ce travail et après démarrage, via GC et l’allocateur système lorsque disponible.
- Fenêtres de passages candidates et pagination des notices évitent de rendre ou charger toute la bibliothèque à chaque recherche.

## Mesures réelles sur ce Mac, 8 octobre 2026

Bibliothèque : 439 documents, 48 932 passages, MiniLM multilingue CPU. Mesures du moteur et de ses processus, pas de la totalité du navigateur ou du système.

| Situation | Mesure observée |
|---|---|
| Repos initial, modèles/vecteurs arrêtés | 138 Mio de RSS ; environ 0,2 % d’un cœur CPU sur 10 s |
| Recherche Low Compute | 0,060 s ; environ 145 Mio pour le moteur |
| Première recherche hybride après arrêt des processus | environ 10 s |
| Requête hybride différente, processus déjà prêts | 2,05 s |
| Même requête servie par le cache | environ 0,017 s |
| Calcul de carte complète | environ 7,4 s avant ajout des expressions de trois mots ; durée variable |
| Mémoire en activité | environ 2 807 Mio, somme du moteur et des dernières mesures RSS des deux processus ; ce n’est pas une mesure du pic absolu |
| Repos après carte et libération des processus | environ 350 Mio pour le moteur, les deux processus arrêtés |

Le démarrage à la demande réduit fortement la mémoire au repos, au prix d’une première recherche plus lente. Il ne rend pas un calcul sémantique gratuit : l’activité peut encore mobiliser environ 2,8 Go. Pour un ordinateur avec peu de mémoire ou une session chargée, Low Compute évite ces processus. Pour plusieurs milliers de documents et une faible empreinte sur les postes utilisateurs, le moteur et Qdrant serveur peuvent être hébergés sur une autre machine ou un serveur UE.

53 tests passent, dont conservation/rechargement des vecteurs après arrêt, filtres de tenant/document, fermeture des processus, cache d’embeddings et accès administrateur aux mesures. Parcours interface vérifié sur le Mac : filtres, recherche intégrée et avancée, pagination, carte. Mesures ponctuelles : aucun benchmark Windows, test prolongé de batterie/pression mémoire ou garantie de latence sur tous les OS. Docker/PostgreSQL restent à valider sur leur cible.

La version native Mac termine le moteur qu’elle a elle-même lancé à sa fermeture. Si elle utilise un moteur préexistant (comme celui lancé ici pour vérification), ce moteur reste disponible ; ses processus lourds se libèrent néanmoins après inactivité.

API des allocateurs : [Apple malloc_zone_pressure_relief](https://github.com/apple-oss-distributions/libmalloc/blob/main/include/malloc/malloc.h), [GNU malloc_trim](https://www.gnu.org/s/gnulib/manual/html_node/malloc_005ftrim.html). Seules les pages déjà libérées par le programme sont concernées.
