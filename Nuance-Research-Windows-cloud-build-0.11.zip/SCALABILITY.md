# Recherche sur de grandes bibliothèques

La recherche n’a plus de plafond de passages. L’ancien paramètre MAX_SCOPE est ignoré pour compatibilité. Les limites par fichier et par ingestion restent appliquées.

## Ce qui a changé

- Index lexical persistant FTS5/BM25 en SQLite ; GIN/ts_rank_cd en PostgreSQL. Le moteur ne relit et ne retokenise plus toute la bibliothèque à chaque recherche.
- Migration automatique du texte existant au démarrage ; aucun recalcul des embeddings ni modification des documents originaux.
- Triggers SQLite assurant la mise à jour transactionnelle après ajout, modification ou suppression de passages. L’index PostgreSQL suit les transactions nativement.
- Recherche vectorielle Qdrant filtrée par tenant et documents autorisés. Revalidation SQL des passages retournés avant de construire une citation.
- Chargement SQL des seuls candidats, sans leurs vecteurs stockés, et des seules pages finalement citées. Fenêtres de 200 candidats par signal en Standard et 2 000 en Exhaustive. L’affichage reste limité à 500 résultats.
- Exhaustive demande une recherche vectorielle exacte, mais ne garantit pas de retrouver toutes les études : limites de candidats, mots, embeddings et expression à cheval sur deux passages.

## Mesures sur ce Mac, 8 octobre 2026

48 tests automatisés passent. Test synthétique : 2 500 documents et 125 000 passages, recherche lexicale à froid en 0,355 s, au plus 200 passages chargés. Ce test vérifie le dépassement du précédent plafond et l’isolation utilisateur ; il ne constitue pas un benchmark sémantique sur 2 500 PDF réels.

Bibliothèque réelle : 439 documents, 48 932 passages. Requête « autonomie consentement » : Low Compute 0,053 s, hybride Standard 2,072 s, Exhaustive 2,087 s. Mesures ponctuelles, sans reranker, moteur CPU MiniLM local ; pas de garantie de latence ni de test de concurrence.

## Configuration pour plusieurs milliers de documents

L’index lexical local est utilisable à cette échelle. Qdrant embarqué effectue en revanche une recherche vectorielle exhaustive en mémoire ; ce n’est pas un index ANN serveur. Pour une bibliothèque de plusieurs milliers de documents avec recherche sémantique régulière, utiliser Qdrant serveur et PostgreSQL, déjà configurés dans compose.yaml. Qdrant serveur utilise son index HNSW et les index de filtres tenant/document. Pas de GPU obligatoire ; préférer au moins 16 Go de RAM et un SSD, dimensionnement à mesurer selon le nombre de passages et la dimension des embeddings.

Le déploiement Docker PostgreSQL/Qdrant n’a pas été exécuté sur ce Mac : Docker n’est pas installé. Ne pas remplacer la bibliothèque locale par un serveur vide : prévoir et vérifier une migration de métadonnées, sources et vecteurs avant de changer la configuration. Le moteur actuel conserve la bibliothèque locale intacte.

## Limites et isolation

Les passages et pages sont filtrés selon les ACL, y compris avant le top-k lexical. SQLite BM25 utilise des statistiques de fréquence de l’index entier, et non un recalcul par utilisateur ; cela peut influencer le classement entre corpus et expose une information statistique agrégée via les scores. Pour des tenants nécessitant une isolation statistique totale, séparer leurs bases SQLite ; PostgreSQL ts_rank_cd ne dépend pas des fréquences des autres documents. La taxonomie et le cache restent filtrés par identité.

L’inventaire ACL des documents est encore chargé en mémoire. L’import reste synchrone. Les suggestions de citations, revues et recherche partagent le moteur amélioré ; la carte thématique et BERTopic ont leur propre coût de calcul et ne deviennent pas instantanés grâce à cet index. Pour la production : jobs d’import en arrière-plan, pagination des bibliothèques, cache persistant, tests de concurrence et sauvegardes restaurées en test.
