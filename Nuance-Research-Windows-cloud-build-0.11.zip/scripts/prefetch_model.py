"""Explicit one-time network download; inference uses local files only."""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from nuance.config import tree_digest
from huggingface_hub import snapshot_download, HfApi
p=argparse.ArgumentParser()
p.add_argument("--id",default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
p.add_argument("--revision",default="e8f8c211226b894fcb81acc59f3b34ba3efd5f42")
p.add_argument("--backend",choices=["sentence-transformers","bge-m3","qwen","reranker"],default="sentence-transformers")
p.add_argument("--license",default="apache-2.0")
p.add_argument("--output",default="models/embedding")
a=p.parse_args()
info=HfApi().model_info(a.id,revision=a.revision)
card_license=info.card_data.get("license") if info.card_data else None
if card_license not in {"mit","apache-2.0","bsd-3-clause"} or card_license!=a.license:
    raise SystemExit(f"License mismatch or unapproved model: {card_license}; review model card manually")
path=Path(a.output)
if path.exists() and any(path.iterdir()): raise SystemExit("Use a new empty output directory to avoid mixed revisions")
path.mkdir(parents=True,exist_ok=True)
snapshot_download(a.id,revision=info.sha,local_dir=str(path),ignore_patterns=["*.onnx","onnx/*","openvino/*","*.h5","*.msgpack"])
# Hub bookkeeping is not inference content; exclude it from the artifact digest.
import shutil
shutil.rmtree(path/".cache",ignore_errors=True)
manifest={"id":a.id,"revision":info.sha,"backend":a.backend,"license":a.license,"training_data":"Consult model card; no guarantee of full dataset provenance","source":"https://huggingface.co/"+a.id,"artifact_sha256":tree_digest(path)}
(path/"nuance-model.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest,indent=2))
