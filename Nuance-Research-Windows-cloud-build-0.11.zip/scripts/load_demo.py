import os, json
from pathlib import Path
import httpx
url=os.getenv("NUANCE_URL","http://localhost:8000")
key=os.getenv("NUANCE_DEMO_KEY")
if not key:
    keys=json.loads(os.environ.get("NUANCE_API_KEYS","{}"))
    key=next(iter(keys),None)
if not key: raise SystemExit("Set NUANCE_DEMO_KEY or source .env")
with httpx.Client(base_url=url,headers={"Authorization":"Bearer "+key},timeout=300) as c:
    r=c.post("/api/collections",json={"name":"Nuance — corpus synthétique"});r.raise_for_status();cid=r.json()["id"]
    concept=c.post("/api/concepts",json={"name":"Autonomie","aliases":["autonomy","consentement"]});concept.raise_for_status()
    for p in sorted((Path(__file__).resolve().parents[1]/"demo").glob("*")):
        if p.suffix not in {".pdf",".txt"}: continue
        with p.open("rb") as f:
            r=c.post("/api/documents",data={"collection_id":cid,"metadata":json.dumps({"title":p.stem,"license":"CC0-1.0","authors":"Nuance synthetic demo","year":2026})},files={"file":(p.name,f)})
        r.raise_for_status();did=r.json()["id"]
        tag=c.put(f"/api/documents/{did}/concepts/{concept.json()['id']}");tag.raise_for_status()
        print(p.name,r.json()["pages"],"pages")
    print("Collection:",cid)
