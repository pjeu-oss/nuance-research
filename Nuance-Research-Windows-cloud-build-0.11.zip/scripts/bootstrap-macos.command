#!/bin/bash
set -euo pipefail
nuance_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$nuance_root"
command -v docker >/dev/null || { echo 'Install Docker Desktop first, then run this installer again.'; exit 1; }
docker info >/dev/null || { echo 'Start Docker Desktop first.'; exit 1; }
if [ ! -f .env ]; then
  docker run --rm -v "$nuance_root:/work" -w /work python:3.12-alpine python scripts/init_env.py
fi
mkdir -p models
printf '\nBuilding the local research engine…\n'
docker compose build
if [ ! -f models/embedding/nuance-model.json ]; then
  docker compose run --rm --no-deps --user root -e HF_HUB_OFFLINE=0 -e TRANSFORMERS_OFFLINE=0 -v "$nuance_root/models:/download" -v "$nuance_root/scripts:/prefetch:ro" --entrypoint python api /prefetch/prefetch_model.py --output /download/embedding
fi
docker compose up -d
printf '\nOpen http://127.0.0.1:8000/install once the engine is ready. Keep your access key private.\n'
open 'http://127.0.0.1:8000/install'
