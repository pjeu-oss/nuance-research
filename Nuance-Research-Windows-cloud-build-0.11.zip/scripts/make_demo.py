from pathlib import Path
from reportlab.pdfgen.canvas import Canvas
from textwrap import wrap
root=Path(__file__).resolve().parents[1]/"demo"
sets={
 "01-autonomie":[
 "Autonomie et consentement. Un système documentaire doit rendre les sources accessibles. Le consentement décrit un accord situé, et non une autorisation illimitée.",
 "Une politique de contrôle offre à chaque utilisateur le droit de retirer un document. L'autonomie implique des choix compréhensibles et réversibles.",
 "However, autonomy alone does not guarantee safety. A consent form cannot replace independent scrutiny of the infrastructure.",
 "La transparence montre les modèles, leurs paramètres et les données utilisées. Une explication de classement ne prouve pas la vérité d'un passage."],
 "02-sobriete":[
 "La sobriété informatique réduit les calculs répétés. Les embeddings des documents sont calculés une fois à l'ingestion et les requêtes fréquentes bénéficient d'un cache.",
 "Un petit modèle peut fonctionner sur CPU pour un corpus limité. Un reranker plus coûteux intervient seulement sur une courte liste de candidats.",
 "Cependant, un faible coût de calcul ne garantit pas une bonne pertinence. Il faut mesurer les omissions sur un corpus représentatif.",
 "Sparse retrieval and lexical search provide complementary evidence. A semantic similarity score is a ranking signal, not a probability that a statement is true."],
 "03-souverainete":[
 "La souveraineté permet de choisir le lieu de stockage et le fournisseur de calcul. Un déploiement local conserve les documents dans le réseau choisi.",
 "Les licences du code et les licences des poids sont distinctes. Une licence permissive doit être accompagnée de ses notices et d'une vérification des dépendances.",
 "Mais l'auto-hébergement ne suffit pas à assurer la sécurité. Des règles d'accès, des sauvegardes et une procédure de suppression restent nécessaires.",
 "Strict tenant isolation prevents one library from disclosing another library's documents. Access control is applied before candidate retrieval."]}
for name,pages in sets.items():
    (root/(name+'.txt')).write_text('\f'.join(pages))
canvas=Canvas(str(root/'04-demo-pages.pdf'));canvas.setTitle('Nuance synthetic pagination demo');canvas.setAuthor('Nuance synthetic demo')
for i,text in enumerate(sum(sets.values(),[]),1):
    canvas.setFont('Helvetica',12);canvas.drawString(60,785,'Nuance Core — synthetic example — page '+str(i))
    y=735
    for line in wrap(text,width=85):canvas.drawString(60,y,line);y-=20
    canvas.showPage()
canvas.save()
print('Created three TXT documents and one 12-page PDF.')
