"""Generate private local credentials. Never overwrite an existing .env."""
import secrets, json
from pathlib import Path
path=Path(".env")
if path.exists(): raise SystemExit(".env already exists; preserve your credentials")
key=secrets.token_urlsafe(32)
values={"POSTGRES_PASSWORD":secrets.token_hex(24),"QDRANT_API_KEY":secrets.token_hex(32),"NUANCE_API_KEYS":json.dumps({key:{"tenant":"demo","user":"owner","role":"admin"}},separators=(",",":")),"EMBEDDER":"sentence-transformers","INSTALL_EXTRAS":"ml"}
# Shell-safe single quoting also accepted by Docker Compose dotenv parser.
path.write_text("\n".join(k+"='"+v+"'" for k,v in values.items())+"\n")
path.chmod(0o600)
print("Created .env (0600). Your UI bearer key is:",key)
