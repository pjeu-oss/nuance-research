$ErrorActionPreference = 'Stop'
$nuanceRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $nuanceRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Install Docker Desktop first, then rerun this script.' }
docker info | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop first.' }
if (-not (Test-Path '.env')) {
  docker run --rm -v "${nuanceRoot}:/work" -w /work python:3.12-alpine python scripts/init_env.py
  if ($LASTEXITCODE -ne 0) { throw 'Credential initialization failed.' }
}
New-Item -ItemType Directory -Force models | Out-Null
docker compose build
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
if (-not (Test-Path 'models/embedding/nuance-model.json')) {
  docker compose run --rm --no-deps --user root -e HF_HUB_OFFLINE=0 -e TRANSFORMERS_OFFLINE=0 -v "${nuanceRoot}/models:/download" -v "${nuanceRoot}/scripts:/prefetch:ro" --entrypoint python api /prefetch/prefetch_model.py --output /download/embedding
  if ($LASTEXITCODE -ne 0) { throw 'Model download failed.' }
}
docker compose up -d
if ($LASTEXITCODE -ne 0) { throw 'Startup failed.' }
Write-Host 'Once ready, open http://127.0.0.1:8000/install. Keep the generated access key private.'
Start-Process 'http://127.0.0.1:8000/install'
