"""Offline recovery: remove uncommitted vector points; verify ready documents.
Run with API stopped, identical environment/model. Does not re-embed automatically.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sqlalchemy import select
from qdrant_client import models as qm
from nuance.config import Settings
from nuance.db import connect,Document,Chunk
from nuance.models import Embedder
from nuance.vector import VectorStore
s=Settings();s.validate();engine,Session=connect(s.database_url);v=VectorStore(s,Embedder(s))
with Session() as db:
    docs={d.id:d for d in db.scalars(select(Document))}
    valid={c.id for c in db.scalars(select(Chunk)) if c.document_id in docs and docs[c.document_id].status=="ready"}
    found=set();offset=None
    while True:
        points,offset=v.client.scroll(v.name,offset=offset,limit=256,with_payload=True)
        stale=[str(p.id) for p in points if str(p.id) not in valid]
        found.update(str(p.id) for p in points)
        if stale:v.client.delete(v.name,qm.PointIdsList(points=stale),wait=True)
        if offset is None: break
    print("Missing vector IDs:",sorted(valid-found))
    print("Reingest documents with missing vectors after restoring from backups.")
v.close();engine.dispose()
