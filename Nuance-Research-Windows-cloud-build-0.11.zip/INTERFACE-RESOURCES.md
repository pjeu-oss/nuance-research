# Language, appearance and local resource safeguards — 0.11

The top-right selectors provide French/English and Light/Dark/System. Choices are local to each browser profile/desktop web view and stored without an external service. The Mac launcher retains preferences across changes of the local port; Windows reuses its local port on relaunch. If another application occupies that port or Windows has not released it yet, a new free port is chosen and browser appearance preferences may need selecting again. Interface labels, explanations, status messages and native confirmation prompts are localized. Documents, bibliographic fields supplied by the author, project names, draft contents and exact quotations keep their original text. Translation never writes to the bibliography or manuscript. Scientific modes and citation styles retain their identifiers. APA/Chicago source formatting is not machine-translated.

Dark mode uses charcoal surfaces and restrained sage accents. The manuscript and original PDF retain their white page and authored colours. Low-cost CSS styling adds no perpetual animation. Interface translation processes new or changed UI nodes rather than polling the whole document; no idle translation job runs. The JSON API stays language-neutral; a developer integrating the API must localize their own interface.

## Resource protection

Portable builds isolate document parsing, embeddings and local vectors in their own processes. Two CPU threads are the default; MiniLM is the bundled CPU model. Embedding and vector workers close after 30 seconds idle. Admission requires 768 MiB available for model work and 256 MiB for other workers. A watchdog samples our own workers once per second and terminates an operation if that process exceeds the lower of 3 GiB and 40% of physical RAM, or if system available RAM falls below 128 MiB. It never terminates another application's process. Replies have a bounded size and a 180-second timeout; failed workers are closed and can be restarted for subsequent operations.

`NUANCE_WORKER_MEMORY_MB`, `NUANCE_WORKER_TIMEOUT_SECONDS`, `NUANCE_CPU_THREADS` and `NUANCE_MODEL_IDLE_SECONDS` are operator settings, not automatic recommendations to raise limits. Extraction isolation is enabled by the desktop entrypoint; custom server deployments can pass `Settings(isolate_extraction=True)`. Server installations otherwise retain their current parser configuration.

Before a document write, the engine requires 512 MiB spare space plus twice the incoming file size. Uploads are limited to 20 MiB, extraction to 500 pages / two million characters, and DOCX expansion is checked. Failed ingestion rolls back its new record and removes its failed upload; pre-existing sources are retained. Vector cleanup is attempted if indexing started. An abrupt power loss or worker kill during index writes can still require index repair; maintain backups.

Windows installs per user without a background startup service or required GPU. A named launcher mutex and a separate library lock prevent duplicate engines. Heavy workers request below-normal priority on Windows; failure to set priority does not disable the memory watchdog. Quit waits for authenticated engine shutdown. Desktop logs rotate at 2 MiB with two backups. Installer space checks add a 1 GiB reserve beyond the packaged files. No uninstall rule deletes user data.

## Verification and limits

Python regression tests cover low-disk refusal, low-memory admission, hung/oversized workers, isolated parser provenance and invalid parser inputs. Existing tenancy, citations, ACL, reader, watch and research tests remain required. Browser checks cover translation, switch-back to French, retained settings and dark/light rendering. Frozen-engine tests use synthetic documents in a temporary library.

A sampled watchdog cannot guarantee zero memory spikes, zero crashes or a fixed total app footprint. Storage grows with the imported bibliography. Windows builds and native tests are still pending on Windows; Mac measurements must not be presented as Windows measurements. Use `desktop/BUILD-WINDOWS.md` to produce and validate the installer.
