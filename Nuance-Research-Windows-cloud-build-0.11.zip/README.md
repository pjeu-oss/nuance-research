Version 0.5 : recherche intégrée à la bibliothèque, Filtres/Avancé, thème éclairci, intitulés de carte issus de textes nettoyés, modèles et vecteurs libérés au repos. Voir [PERFORMANCE.md](PERFORMANCE.md) pour les mesures et limites.

# Nuance-Research 0.4

Compact bibliography, reversible removal, duplicate detection, BibTeX export, a whole-library reflexive topic map and website installation/distribution have been added. Read [DISTRIBUTION.md](DISTRIBUTION.md) for setup, validation and limits. `/workspace` is the research interface and `/install` is the installation page.

# Atelier de recherche Mac 0.3

Une préversion locale de l’application Mac, de la bibliothèque, de la rédaction et des revues a été ajoutée. Lire [RESEARCH-WORKSPACE.md](RESEARCH-WORKSPACE.md) pour les fonctionnalités réelles, les limites et la dépendance à l’installation locale. L’atelier est accessible à `/workspace`. La version 0.8 ajoute lecture PDF, surlignages privés et veille : lire [READING-DISCOVERY.md](READING-DISCOVERY.md) pour les usages, connexions et limites. Le reste de ce README décrit le moteur et son déploiement.

# Nuance Core 0.2 — moteur documentaire et bloc d'intégration

Service Python/FastAPI self-hosted + interface web minimale + SDK portable TypeScript/JavaScript. Le moteur fonctionne sans LLM obligatoire. La v0.2 ajoute recherche réutilisable, aide à la rédaction et classement de commentaires avec synchronisation d'identifiants applicatifs. Voir **[INTEGRATION.md](INTEGRATION.md)** pour le branchement à Expo/web/backend et `sdk/` pour le package local `@nuance/core-client`.

## Installation Mac / Linux

Python 3.12 recommandé (>=3.11), venv, SSD. Docker Desktop Mac ou Docker Engine + Compose v2 Linux pour PostgreSQL/Qdrant.

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install '.[ml,dev]'
python scripts/init_env.py
python scripts/prefetch_model.py
# Crée un snapshot local vérifié de MiniLM multilingue.
docker compose up --build -d
set -a
source .env
set +a
python scripts/load_demo.py
```

Ouvrir http://localhost:8000 et saisir la clé affichée par `init_env.py`. `.env` est généré avec secrets aléatoires, privé (0600), exclu du versionnement et de l'archive. Le modèle n'est pas fourni dans le ZIP : téléchargement explicite initial, puis inference locale/offline. Le chargement de la démo crée une nouvelle collection à chaque exécution.

### Sans Docker ni téléchargement neuronal

```sh
pip install '.[dev]'
python scripts/init_env.py
set -a; source .env; set +a
export EMBEDDER=demo-hash
export DATA_DIR=./data
export DATABASE_URL=sqlite:///./data/nuance.db
uvicorn nuance.main:create_app --factory --host 127.0.0.1 --port 8000 --workers 1 --no-access-log
# Autre terminal : activer venv, charger .env et lancer scripts/load_demo.py
```

`demo-hash` est un vecteur lexical déterministe de test, **pas** un modèle sémantique ; chaque recherche l'indique. SQLite/Qdrant embarqué utilisent les vrais chemins de persistance des tests. Ne pas lancer plusieurs processus sur la même base Qdrant embarquée. On peut utiliser le profil MiniLM hors Docker avec `EMBEDDER=sentence-transformers`, `MODEL_PATH=./models/embedding` et le même stockage local.

## Architecture

```text
Expo / web / Node
   → SDK @nuance/core-client
   → backend existant Nuance : session + bridge authentifié
   → API FastAPI : rôle + tenant + ACL collection ET document
       → recherche lexicale BM25 / dense / sparse / concepts
       → fusion RRF / reranker optionnel / citations expliquées

Backend Nuance : événements article/commentaire saved/deleted
   → client d'indexation privé
   → extraction/texte → pages/passages → embeddings à l'ingestion
   → PostgreSQL : metadata, pages, passages, ACL, audit, concepts, topics
   → Qdrant : dense et sparse (BGE-M3)
   → stockage privé : original et SHA-256
```

Le site nuance-app.eu n'a pas été modifié. Les exemples se branchent à son code/backend/authentification existants, qui ne sont pas présents dans ce projet. L'API/SDK ne lit pas spontanément sa base : importer les contenus et transmettre leurs événements. La génération de comptes OIDC/jetons signés à grande échelle reste un travail de production ; le MVP utilise des clés serveur fixes par identité.

## Cœur documentaire

- PDF texte par pypdf, TXT/MD UTF-8, DOCX par extraction XML ; Docling/OCR facultatif. PDF : page physique 1-based + label ; TXT/MD : pages logiques séparées par form feed ; DOCX : une page logique, sans prétendre retrouver la pagination Word.
- Citations : substring exact de la page **extraite**, avec offsets, fichier original, hash et paramètres d'extraction. Ne certifie pas la transcription visuelle, l'OCR, ni la vérité d'une source.
- Métadonnées : titre/auteur/date PDF si présents, DOI candidat détecté, métadonnées utilisateur, origines distinguées. Pas de Crossref externe obligatoire, pas d'auteur inventé.
- Recherche lexicale indexée : FTS5/BM25 sur SQLite local ; index GIN et `ts_rank_cd` sur PostgreSQL (ce dernier n’est pas BM25). Les filtres d’accès précèdent la sélection des meilleurs candidats. SQLite utilise des statistiques de fréquence globales à l’index, qui ne représentent pas la vérité ni une probabilité.
- Qdrant réel avec filtres tenant + IDs documentaires autorisés avant recherche, puis croisement SQL. Index nommé par empreinte du modèle. Pas de mélange silencieux de modèles : restauration de l'ancien profil ou réingestion requise si les versions diffèrent.
- Fusion RRF k=60 : lexical 1, dense 1, sparse .6, concepts .5. Scores exposés comme signaux de pertinence, jamais probabilités de vérité.
- Concepts manuels, aliases et parent ; tags documentaires. BERTopic sur les embeddings d'ingestion, runs sous contrôle d'accès.
- Cache de 128 requêtes embeddings et 128 résultats, en mémoire ; scope/identité/configuration du corpus dans la clé ; mutations invalident les résultats. Les requêtes/brouillons peuvent rester en RAM, mais ne sont pas persistés ni écrits dans l'audit.

Modes utilisateur : Search, Quotes (phrase exacte case-insensitive dans un passage), Explore (alternance des sources), Topics (taxonomie + discovery séparée), Ask (sources extractives).

Modes scientifiques : Exhaustive (recherche vectorielle exacte et fenêtre de 2 000 candidats par signal, sortie bornée), Contradict (marqueurs FR/EN de négation/adversativité, **heuristique et non NLI**), Explore, Strict Sources (phrase exacte), Low Compute (lexical/concepts, sans embedding de requête/rerank).

Plafonds : 20 Mo/fichier, 500 pages, 2 M caractères extraits, 5 000 passages/ingestion, aucun plafond de passages accessibles/recherche, 500 résultats. Fenêtre standard de 200 candidats/signal, rerank des 50 premiers ; Exhaustive élargit la fenêtre à 2 000 candidats/signal et conserve une sortie bornée. Une revue systématique exige un contrôle humain de la couverture. Les citations ne franchissent pas une frontière de passage ; une expression à cheval peut être manquée. Les vecteurs utilisent au plus 512 tokens ; la citation source n'est pas tronquée pour ce motif.

## Options de modèles et OCR

Default : `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`, 384 dimensions, environ 118 M paramètres, Apache-2.0. Snapshot épinglé `e8f8c211226b894fcb81acc59f3b34ba3efd5f42`. Le script de provisionnement enregistre ID, SHA de révision, licence, provenance déclarée et digest des fichiers ; le digest est vérifié au chargement.

Toutes les commandes suivantes exigent un dossier de modèle vide, sauf stockage dans un nouveau chemin. Un changement de modèle exige une réingestion ; pas de reindexation en ligne.

```sh
# BGE-M3 MIT : vrai dense + sparse ; CPU FP32
pip install '.[ml,bge]'
python scripts/prefetch_model.py --id BAAI/bge-m3 --revision main --backend bge-m3 --license mit --output models/embedding
# .env : EMBEDDER='bge-m3', INSTALL_EXTRAS='ml,bge'

# Qwen3 embedding Apache-2.0 (0.6B ou remplacer par 4B, plus coûteux)
python scripts/prefetch_model.py --id Qwen/Qwen3-Embedding-0.6B --revision main --backend qwen --license apache-2.0 --output models/embedding
# .env : EMBEDDER='qwen'

# Reranker local facultatif (CrossEncoder)
python scripts/prefetch_model.py --id BAAI/bge-reranker-v2-m3 --revision main --backend reranker --license apache-2.0 --output models/reranker
# .env : RERANKER_PATH='/models/reranker'

# Docling/OCR : code MIT ; poids OCR/layout à auditer séparément
pip install '.[docling]'
docling-tools models download --output-dir models/docling
# .env : EXTRACTOR='docling', INSTALL_EXTRAS='ml,docling'
# .env : DOCLING_ARTIFACTS_PATH='/models/docling'
```

`main` est résolu à un SHA immuable par le script ; conserver ce SHA pour reproduire. Pas de ColBERT dans le MVP. BERTopic : `pip install '.[ml,topics]'`, puis `/api/topics/discover` ou bouton de l'UI ; 10–2 000 passages, seed 42, clusters exploratoires/outliers. Le mini-corpus n'établit pas la qualité scientifique.

LLM optionnel : `LLM_URL=http://serveur-local:8080/v1`, `LLM_MODEL=...`, endpoint `/api/ask/generate`. Compatible serveur chat/completions local, désactivé par défaut. Citations reprises du moteur et IDs validés ; synthèse explicitement marquée interprétation, soutien factuel non validé. Aucun LLM nécessaire pour les trois blocs v0.2. Le SDK n'expose pas automatiquement cet endpoint de génération.

## Sécurité / threat model

Frontières : utilisateur non fiable → backend Nuance existant → Core ; document non fiable → parseur ; Core → bases privées ; LLM optionnel → sortie non fiable.

- Identité fixe dans `NUANCE_API_KEYS` : tenant, user, role. Admin limité à son tenant ; editor gère ses collections/documents ; reader lit uniquement. Pas de tenant choisi par header client. Collection **et** document doivent être lisibles. Commentaires : ACL parent article aussi exigée.
- Origin checks/JSON obligatoire/allowlist de routes dans le bridge ; session et éventuelle protection CSRF du backend à connecter. Vérification de correspondance `/api/me` : aucune clé admin commune substituée à un lecteur.
- Aucun port DB publié en Compose. API loopback ; TLS via reverse proxy Caddy/Nginx, secrets en coffre en production, rotation, chiffrage des volumes/backups, MFA admin.
- Middleware ASGI borne les octets réellement reçus avant parseur multipart, même avec faux Content-Length. Types et taille/pages/caractères bornés. Les parseurs restent dans le process API : sandbox, limites CPU/RAM/temps et anti-malware à prévoir avant uploads publics hostiles.
- UI `textContent`, CSP, pas de HTML documentaire exécuté. LLM désactivé par défaut, risque de prompt injection toujours à évaluer avant usage.
- Limiter 120 requêtes/minute par identité, cache borné ; quotas et rate limiting distribués au proxy à prévoir.
- Audit tenant/acteur/action/cible/date sans source/requête brute, non immuable. Accès DB de confiance ; refus d'authentification non persistés dans ce MVP.

Une seule instance/worker API : sérialisation des mutations/recherches coûteuses ; ingestion synchrone pouvant bloquer la recherche. Pas d'Alembic/RLS/outbox distribuée dans ce MVP. Original, index, metadata et base de l'application ne partagent pas une transaction globale. `scripts/reconcile.py` détecte nettoie les points sans passage ready et signale les vecteurs manquants ; source orpheline/ancien index à purger selon politique. Les anciennes versions applicatives sont inaccessibles en lecture mais conservées jusqu'à `deleteContent` ; backups à traiter séparément pour effacement RGPD complet.

Déploiement souverain : données/compute locaux ou hébergeur UE au choix, aucune API extérieure obligatoire. Provisionnement initial des packages/images/poids via réseau. Variables offline activées et snapshots locaux ; pour une garantie réseau, appliquer une politique d'egress au niveau hôte/réseau, pas seulement des variables.

## Compute et sobriété

Recommandations de planification, pas des benchmarks/SLA : démo lexical 2–4 cœurs / 4 Go ; MiniLM CPU 4–8 cœurs / 8–16 Go ; BGE-M3 ou Qwen 0.6B 8 cœurs / 16–32 Go ; Qwen4B/reranker/OCR peuvent demander davantage. Aucun GPU permanent requis. SSD recommandé ; embeddings à l'ingestion, cache, fenêtres progressives, rerank à la demande. Low Compute évite les inférences de requête mais le modèle configuré est déjà chargé au démarrage.

Vecteur brut float32 : passages × dimensions × 4 octets, plus HNSW/payloads/JSON SQL/replication. Le JSON SQL des embeddings pour BERTopic duplique du stockage. Mesurer recall@k, p95 et pages/sec sur vos données ; grande bibliothèque → index lexical réel, jobs et workers séparés.

## Licences / checklist juridique

Voir [LICENSES.md](LICENSES.md), code MIT et corpus synthétique CC0. Licences des dépendances et modèles distinctes ; driver psycopg LGPL, poids Docling/OCR à auditer séparément. Rien ne certifie les droits des données d'entraînement ou des documents utilisateur.

Avant exploitation : collecter notices/licences et SBOM ; auditer transitives/images/poids/tokenizers/datasets, exclure NC/research-only incompatibles ; vérifier droits d'import/citation/publication ; base légale, DPA, conservation, export/effacement RGPD, accès administrateurs et transferts ; vérifier régime juridique/AI Act selon usage avec conseil compétent ; prévoir retrait et évaluations de biais. Aucun apprentissage sur les données utilisateur dans ce projet.

## Vérification et suite production

```sh
pip install '.[dev]'
pytest -q
cd sdk
node --test test/*.test.js
# Test React facultatif : installer React et react-test-renderer pour ce test.
```

[VALIDATION.md](VALIDATION.md) décrit les vérifications exécutées jusqu’à la v0.8. Docker/Compose, PostgreSQL réel, OCR et gros modèles restent à valider sur l'environnement cible. Les exemples Expo sont à monter dans votre application ; aucun déploiement/modification de nuance-app.eu n'a été effectué.

Avant production : OIDC/jetons courts, hooks backend/session et import réel de Nuance ; queue/outbox d'événements idempotents ; migrations/RLS ; vrai index lexical scalable ; sandbox parsing ; TLS/secrets/backup/restore/purge ; observabilité sans contenu ; tests services Docker et corpus expert FR/EN ; évaluation spécifique des sources/commentaires. La pertinence thématique des commentaires n'est ni une note de vérité, ni une modération/civilité automatique.

Bibliothèques importantes : voir `SCALABILITY.md` pour les mesures, les limites locales et le déploiement avec Qdrant serveur.

## Article editor (0.6)

See [WRITING.md](WRITING.md) for the Word-like offline editor, editable DOCX imports, APA/Chicago citation proposals, footnotes, density controls, source verification, article-specific map, typed metadata and export limits. The Publish button opens Nuance without uploading a draft.

Project bibliographies and bibliographic reanalysis: [METADATA-PROJECTS.md](METADATA-PROJECTS.md). Crossref is opt-in; local GROBID is optional.

La version 0.9 ajoute la sélection multiple de thèmes pour la veille, le filtrage explicable des candidats, la réinitialisation réversible et la navigation horizontale du lecteur. Voir [le guide lecture et veille](READING-DISCOVERY.md) et [la validation](VALIDATION.md).

Interface preferences and resource safeguards (0.11): [INTERFACE-RESOURCES.md](INTERFACE-RESOURCES.md). Windows build and test instructions: [desktop/BUILD-WINDOWS.md](desktop/BUILD-WINDOWS.md). The Windows installer must be built and tested on Windows; no Windows executable is supplied by the Mac build.
