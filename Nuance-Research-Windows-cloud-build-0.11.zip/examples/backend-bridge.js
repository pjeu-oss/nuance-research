import {createNuanceBridge} from '@nuance/core-client/bridge';

/** Adapt the returned Fetch Request/Response handler to your actual backend.
 * These two callbacks MUST use the existing trusted authentication service and
 * a server-side per-identity credential store. No tenant/user from form headers.
 */
export function nuanceRoutes({coreURL,authenticateNuanceSession,lookupCoreUserKey}) {
  return createNuanceBridge({
    coreURL:coreURL+'/api',
    authenticate:authenticateNuanceSession,
    resolveCoreToken:identity=>lookupCoreUserKey(identity.tenant,identity.user,identity.role)
  });
}
