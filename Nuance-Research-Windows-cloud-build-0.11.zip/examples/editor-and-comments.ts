import type {NuanceClient} from '@nuance/core-client';

/** Bind to a "Trouver des sources" button in the existing article editor.
 * Preview drafts remain transient; publish/index only through backend events.
 */
export async function suggestSources(client:NuanceClient,draft:{id?:string;title:string;body:string},collectionId?:string) {
  return client.assistArticle({title:draft.title,body:draft.body,externalId:draft.id,collectionId,limit:6});
}

/** Bind to a "Pertinents" comments tab, using app IDs to join your own UI/data. */
export async function relevantComments(client:NuanceClient,collectionId:string,articleId:string,query?:string) {
  return client.rankComments({collectionId,articleExternalId:articleId,query,limit:10});
}
