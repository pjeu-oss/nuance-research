import {createNuanceClient} from '@nuance/core-client';

/** Construct once and reuse throughout Expo/web. Access token belongs to the
 * existing Nuance session. Core admin/indexing credentials stay in the backend.
 */
export function clientForNuanceSession(backendURL:string,getSessionToken:()=>Promise<string|null>) {
  return createNuanceClient({
    baseURL:backendURL.replace(/\/$/,'')+'/api/nuance',
    getAccessToken:getSessionToken,
    credentials:'include'
  });
}
