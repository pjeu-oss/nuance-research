import React,{useState} from 'react';
import {View,Text,TextInput,FlatList,Pressable} from 'react-native';
import type {NuanceClient,Source} from '@nuance/core-client';
import {useNuanceSearch} from '@nuance/core-client/react';

/** Drop into an existing Expo screen. The caller chooses its navigation. */
export function NuanceSearch({client,collectionId,onOpen}:{client:NuanceClient;collectionId?:string;onOpen:(source:Source)=>void}) {
  const [query,setQuery]=useState('');
  const state=useNuanceSearch(client,query,{collectionId,debounceMs:300,limit:10});
  return <View>
    <TextInput accessibilityLabel="Rechercher dans Nuance" value={query} onChangeText={setQuery} placeholder="Une idée, un sujet…" />
    {state.status==='loading' && <Text>Recherche…</Text>}
    {state.error && <Text accessibilityRole="alert">Recherche indisponible. Réessayez.</Text>}
    <FlatList data={state.data?.results ?? []} keyExtractor={row=>row.chunk_id}
      renderItem={({item})=><Pressable onPress={()=>onOpen(item)}>
        <Text>{item.title} · p. {item.page}</Text><Text>{item.quote}</Text>
      </Pressable>} />
  </View>;
}
