import {createNuanceClient} from '@nuance/core-client';

/** Run in the existing Nuance BACKEND, after its own content transaction commits.
 * getIndexingKey and getReaders use trusted server data, not form input.
 * Queue/retry these events in production; ingestion is synchronous in the MVP.
 */
export function createNuanceEvents({coreURL,getIndexingKey,collectionId,getReaders}) {
  const indexer=createNuanceClient({baseURL:coreURL+'/api',getAccessToken:getIndexingKey,timeoutMs:120000});
  return {
    articleSaved: async article => indexer.upsertContent({
      collectionId, externalId:String(article.id), kind:'article', title:article.title,
      text:article.body, readers:await getReaders(article)
    }),
    commentSaved: async comment => indexer.upsertContent({
      collectionId, externalId:String(comment.id), kind:'comment',
      title:'Commentaire '+comment.id, text:comment.body,
      parentExternalId:String(comment.articleId), readers:await getReaders(comment)
    }),
    articleDeleted: async id => indexer.deleteContent({collectionId,externalId:String(id),kind:'article'}),
    commentDeleted: async id => indexer.deleteContent({collectionId,externalId:String(id),kind:'comment'})
  };
}
