# Nuance Core comme bloc réutilisable — v0.2

Le moteur est un service installé une fois. Un SDK léger s'importe partout : barre de recherche, éditeur d'article, onglet de commentaires. Il n'embarque aucun modèle sur le téléphone et n'impose aucun LLM. Le transport est `fetch`, avec déclarations TypeScript ; Expo, React Native, web et Node peuvent l'appeler. Le hook React est une entrée facultative.

## Installation du petit client

Depuis votre projet d'application :

```sh
npm install /chemin/vers/nuance-core-client-0.2.0.tgz
# Ou, depuis le dossier de ce projet :
npm install /chemin/vers/nuance-core/sdk
```

Le package est local, non publié sur npm. Le tarball contient JavaScript, déclarations `.d.ts`, bridge backend et hook React. Pas de build ni de dépendance de modèles côté application. React >=18 est une peer dependency facultative, uniquement pour `@nuance/core-client/react`.

## Les trois branchements

```ts
import {createNuanceClient} from '@nuance/core-client';

const core = createNuanceClient({
  baseURL: 'https://votre-backend-nuance/api/nuance',
  getAccessToken: () => getExistingNuanceSessionToken(),
});

// 1. Barre de recherche
const hits = await core.search({query: 'autonomie', limit: 10});

// 2. Lors de la rédaction : suggérer des sources, sans réécrire le texte
const help = await core.assistArticle({
  title: draft.title, body: draft.body, externalId: draft.id,
});

// 3. Extraire les commentaires pertinents pour un article ou un angle précis
const comments = await core.rankComments({
  collectionId, articleExternalId: article.id, query: 'consentement',
});
```

`getExistingNuanceSessionToken`, `draft` et `article` représentent **vos** données/session ; ce sont des points de branchement, pas une authentification implémentée à votre place. En session web avec cookie, le SDK peut omettre `getAccessToken` et utiliser `credentials:'include'` vers le backend de l'application. Expo nécessite une URL absolue accessible depuis l'appareil et votre jeton de session ; `localhost` d'un téléphone désigne le téléphone, pas le serveur.

Recherche React/Expo : `useNuanceSearch(core, query, {debounceMs:300})`, avec annulation des requêtes précédentes et protection contre les réponses tardives. Conserver un client stable (module, contexte ou useMemo), sinon le hook redémarre à chaque rendu. Exemple d'écran : `examples/NuanceSearch.tsx`. Les actions de rédaction/commentaires sont illustrées dans `examples/editor-and-comments.ts`.

## Synchroniser les contenus de Nuance

L'API ne peut pas chercher les articles/commentaires qui sont encore uniquement dans votre base d'application. Installer les événements suivants **dans le backend Nuance**, après sa transaction de sauvegarde :

- `articleSaved` / `commentSaved` → `upsertContent` ;
- `articleDeleted` / `commentDeleted` → `deleteContent` ;
- import initial → parcourir les contenus existants et envoyer les mêmes événements.

Un article/commentaire conserve son ID applicatif `externalId`. Le moteur crée un ID documentaire séparé, renvoyé par le SDK. Les mises à jour identiques n'effectuent pas de nouvelle ingestion. Un texte, titre ou ACL modifié crée une nouvelle version ; une seule reste active pour la recherche. Les commentaires sont liés à l'ID applicatif stable de leur article, donc restent liés après édition de l'article. Les anciennes versions sont conservées mais ne sont plus consultables en lecture ; `deleteContent` les purge. Supprimer un article par `deleteContent` supprime aussi ses commentaires indexés et leurs versions.

```ts
// Ce client et cette clé sont réservés au BACKEND, jamais à Expo ou au navigateur.
const indexer = createNuanceClient({
  baseURL: 'http://nuance-core:8000/api',
  getAccessToken: () => indexingKeyForTenant,
  timeoutMs: 120000,
});
await indexer.upsertContent({
  collectionId, externalId: article.id, kind: 'article',
  title: article.title, text: article.body,
  readers: ['*'], // seulement si PUBLIC dans ce tenant ; choisir depuis les ACL du backend
});
await indexer.upsertContent({
  collectionId, externalId: comment.id, kind: 'comment',
  parentExternalId: article.id, title: 'Commentaire', text: comment.body,
  readers: ['*'],
});
```

Exemple d'adaptateur d'événements : `examples/application-events.js`. Les ACL sont choisies depuis les données serveur de Nuance, jamais depuis une déclaration libre du formulaire. `readers:[]` rend le contenu privé au propriétaire/admin ; `readers:['*']` l'ouvre à ce tenant, sous réserve de l'ACL de collection. Pour un commentaire, l'article parent doit aussi être lisible : une ACL de commentaire plus large ne permet pas de contourner la confidentialité de l'article.

Le backend d'indexation peut utiliser une identité administrateur dédiée par tenant, conservée côté serveur. La recherche des utilisateurs utilise leurs identités propres. L'autorité de publication/indexation ne doit jamais être exposée dans l'app mobile.

## Brancher l'authentification existante

`@nuance/core-client/bridge` fournit un handler standard `Request → Response`, portable entre backends compatibles Fetch. Il expose seulement les routes prévues et ne transmet pas les headers d'identité arbitraires du client. Votre backend fournit :

1. `authenticate(request)` : vérifie la session Nuance et renvoie `{tenant,user,role}` depuis un contexte de confiance ;
2. `resolveCoreToken(identity)` : retrouve la clé Core de cette identité dans un stockage privé.

Le bridge exige du JSON, refuse les origines navigateur différentes de l'origine du backend sauf allowlist `allowedOrigins`, et vérifie `/api/me` avant de relayer : une clé admin commune ne peut pas remplacer silencieusement l'identité d'un lecteur. Les clés Core ne sont jamais envoyées au client. Les droits d'écriture restent vérifiés par Core.

**Limite actuelle :** Core utilise des clés statiques provisionnées dans `NUANCE_API_KEYS`. La gestion automatisée des comptes/OIDC n'est pas encore construite. Pour un grand nombre d'utilisateurs, remplacer ce mécanisme par une validation de jetons courts signés/OIDC avec les mêmes ACL, plutôt que distribuer une clé administrateur à l'application. L'adaptateur de session et l'accès au stockage d'articles de votre application nécessitent son code.

En Expo/web, pointer le SDK vers ce bridge de votre backend. En mode serveur privé, le SDK peut appeler Core directement. Le moteur ne configure pas de CORS public permissif : web via le backend de l'application, avec votre authentification/cookies et protection CSRF selon votre système.

## Ce que renvoient les blocs

| Bloc | Résultat | Garantie / limite |
|---|---|---|
| `search` | passages, pages, offsets, signaux et provenance | ACL avant recherche ; pertinence, pas vérité |
| `assistArticle` | sources liées + concepts manuels détectés | brouillon non indexé et non journalisé ; pas de génération ni fact checking automatique |
| `rankComments` | IDs applicatifs + un passage pertinent par commentaire + explication | uniquement commentaires autorisés du parent ; pertinence au sujet, sans note de vérité, popularité ou auteur |
| `upsertContent` | ID documentaire/version, ID applicatif, changed | idempotent pour contenu/config identiques ; conflit concurrent 409 à réessayer |
| `deleteContent` | nombre de versions supprimées | purge des versions/commentaires concernés ; sauvegardes à gérer séparément |

L'aide à la rédaction utilise le titre et les 2 000 premiers caractères titre+corps pour construire la requête par défaut ; `query` permet de choisir un angle ou passage précis. Elle exclut l'article en cours (par ID applicatif) et les commentaires des sources proposées. Elle conserve deux listes de candidats, documents et articles, avec fusion des rangs. Le texte du brouillon passe en mémoire et dans les caches de recherche, sans persistance ni audit du texte ; « non stocké » signifie non persisté, pas absent de la RAM.

Le classement des commentaires utilise votre `query`, sinon le titre+début de l'article. Il regroupe les passages par commentaire et renvoie le meilleur extrait par commentaire selon l'ordre du moteur. La fenêtre de candidats est bornée ; pas de garantie d'exhaustivité sur des milliers de commentaires. Les réactions, likes, réputation d'auteur, civilité et détection NLI ne participent pas au classement actuel.

## Paramètres opérationnels

Le SDK gère timeout et AbortSignal. Prévoir une debounce de 250–400 ms pour la barre de recherche, une action explicite ou une pause longue pour l'aide à la rédaction, et le chargement du classement des commentaires à l'ouverture de son onglet. Aucun recalcul d'embedding des articles à chaque frappe : uniquement la requête, les embeddings de contenus restent calculés à l'ingestion.

Ingestion synchrone, une instance/worker Core ; passer par une queue/outbox et des retries dans votre backend avant production. Une panne d'indexation doit laisser l'article original dans votre base Nuance ; les événements peuvent être rejoués. La mise à jour d'article crée sa nouvelle version et désactive l'ancienne dans la même transaction SQL, avec nettoyage de nouveaux vecteurs en cas d'échec. Les anciennes versions/index doivent être purgés selon vos délais de conservation. Le moteur et votre base Nuance ne partagent pas une transaction distribuée. Les champs `text`/`body` attendent du texte : convertir les blocs de votre éditeur ou HTML riche côté backend avec son sérialiseur, puis garder le lien vers le contenu applicatif original.

## État de livraison

Le SDK et les endpoints sont fournis et testés localement. Le site nuance-app.eu n'a pas été modifié. Aucun composant n'est encore monté dans votre vraie barre de recherche, votre éditeur ou vos commentaires, faute de code de cette application. Les exemples montrent les branchements et laissent explicites les hooks d'authentification et les événements de votre backend.
