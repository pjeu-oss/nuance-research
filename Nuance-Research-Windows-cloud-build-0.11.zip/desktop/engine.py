"""Portable local engine entrypoint. Never imports an existing user's library."""
import os,sys,json,secrets,socket,threading,time,webbrowser,runpy,argparse
from pathlib import Path
for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[variable]='2'
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')

def main():
    if len(sys.argv)>2 and sys.argv[1]=='--nuance-worker':
        if sys.argv[2] not in {'embedding','vector','extraction'}:raise SystemExit('Unknown worker')
        runpy.run_module('nuance.'+sys.argv[2]+'_worker',run_name='__main__');return
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir');parser.add_argument('--runtime-file');parser.add_argument('--open-browser',action='store_true');parser.add_argument('--managed-log',action='store_true');args=parser.parse_args()
    bundle=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
    if not args.data_dir:
        base=Path(os.environ.get('LOCALAPPDATA',Path.home()/'AppData/Local')) if sys.platform=='win32' else Path.home()/'Library/Application Support'
        data=base/'Nuance-Research'
    else:data=Path(args.data_dir)
    data.mkdir(parents=True,exist_ok=True)
    os.environ['HF_HOME']=str(data/'model-cache')
    if sys.stdout is None or args.managed_log:
        from logging.handlers import RotatingFileHandler
        from logging import LogRecord,INFO
        handler=RotatingFileHandler(data/'desktop-server.log',maxBytes=2*1024*1024,backupCount=2,encoding='utf-8')
        class LogStream:
            encoding='utf-8'
            def isatty(self):return False
            def writable(self):return True
            def write(self,text):
                if text.strip():handler.emit(LogRecord('desktop',INFO,'',0,text.rstrip(),(),None))
                return len(text)
            def flush(self):handler.flush()
        sys.stdout=LogStream()
    if sys.stderr is None or args.managed_log:sys.stderr=sys.stdout
    import portalocker
    lock=portalocker.Lock(str(data/'engine.lock'),timeout=0)
    try:lock.acquire()
    except portalocker.exceptions.LockException:raise SystemExit('Nuance-Research is already running for this library.')
    credentials=data/'access.json'
    if not credentials.exists():
        with os.fdopen(os.open(credentials,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'w') as f:json.dump({secrets.token_urlsafe(32):{'tenant':'local','user':'owner','role':'admin'}},f)
    keys=json.loads(credentials.read_text());model=bundle/'model'
    from nuance.main import create_app
    from nuance.config import Settings
    import uvicorn
    app=create_app(Settings(data_dir=str(data),database_url='sqlite:///'+str(data/'nuance.sqlite'),model_path=str(model),keys=keys,isolate_extraction=True))
    from fastapi import Request
    from fastapi.responses import JSONResponse
    server=None
    @app.post('/desktop/quit')
    def quit_engine(request:Request):
        token=request.headers.get('authorization','').removeprefix('Bearer ')
        if token not in keys:return JSONResponse({'error':'Unauthorized'},status_code=403)
        def stop():
            if server:server.should_exit=True
        threading.Timer(.2,stop).start();return {'stopping':True}
    listener=socket.socket()
    if os.name!='nt':listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    elif hasattr(socket,'SO_EXCLUSIVEADDRUSE'):listener.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
    port_file=data/'local-port.json'
    try:
        preferred=int(json.loads(port_file.read_text())['port']) if port_file.exists() else 0
        if preferred and not 1024<=preferred<=65535:preferred=0
        listener.bind(('127.0.0.1',preferred))
    except (ValueError,KeyError,OSError):listener.bind(('127.0.0.1',0))
    port=listener.getsockname()[1]
    temporary=data/'local-port.tmp';temporary.write_text(json.dumps({'port':port}));temporary.replace(port_file)
    runtime=Path(args.runtime_file) if args.runtime_file else data/'runtime.json'
    capability=secrets.token_urlsafe(32)
    if args.open_browser:
        from fastapi.responses import JSONResponse
        @app.get('/desktop/session')
        def session(ticket:str):
            nonlocal capability
            if not capability or not secrets.compare_digest(ticket,capability):return JSONResponse({'error':'Expired session'},status_code=403)
            capability='';return JSONResponse({'key':next(iter(keys))},headers={'Cache-Control':'no-store'})
        def launch():
            import urllib.request
            for _ in range(120):
                try:
                    urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=1).close()
                    webbrowser.open(f'http://127.0.0.1:{port}/workspace#desktop-session='+capability);return
                except Exception:time.sleep(.5)
        threading.Thread(target=launch,daemon=True).start()
    with os.fdopen(os.open(runtime,os.O_CREAT|os.O_TRUNC|os.O_WRONLY,0o600),'w') as f:json.dump({'port':port,'pid':os.getpid()},f)
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,access_log=False,log_level='warning',loop='asyncio',http='h11',ws='none'))
    try:server.run(sockets=[listener])
    finally:runtime.unlink(missing_ok=True);listener.close();lock.release()

if __name__=='__main__':main()
