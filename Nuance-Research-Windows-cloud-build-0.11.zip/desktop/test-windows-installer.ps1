param([Parameter(Mandatory=$true)][string]$InstallerPath)
$ErrorActionPreference = 'Stop'
$nuanceInstaller = (Resolve-Path $InstallerPath).Path
$nuanceTestRoot = Join-Path $env:TEMP ('nuance-install-test-' + [guid]::NewGuid())
$nuanceInstallDir = Join-Path $nuanceTestRoot 'app'
New-Item -ItemType Directory -Path $nuanceTestRoot | Out-Null
try {
    $nuanceInstall = Start-Process -FilePath $nuanceInstaller -Wait -PassThru -ArgumentList @('/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/CURRENTUSER', '/NOICONS', "/DIR=`"$nuanceInstallDir`"", "/LOG=`"$nuanceTestRoot/install.log`"")
    if ($nuanceInstall.ExitCode -ne 0) { throw "Installer failed: $($nuanceInstall.ExitCode)" }
    $nuanceEngine = Join-Path $nuanceInstallDir 'engine/NuanceEngine.exe'
    if (!(Test-Path $nuanceEngine) -or !(Test-Path (Join-Path $nuanceInstallDir 'Nuance-Research.exe'))) { throw 'Installed application is incomplete' }
    python (Join-Path $PSScriptRoot 'smoke.py') $nuanceEngine
    if ($LASTEXITCODE -ne 0) { throw 'Installed engine test failed' }
    $nuanceUninstall = Start-Process -FilePath (Join-Path $nuanceInstallDir 'unins000.exe') -Wait -PassThru -ArgumentList @('/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', "/LOG=`"$nuanceTestRoot/uninstall.log`"")
    if ($nuanceUninstall.ExitCode -ne 0) { throw "Uninstaller failed: $($nuanceUninstall.ExitCode)" }
    if (Test-Path $nuanceEngine) { throw 'Uninstaller left the engine installed' }
    Write-Output 'Silent installation, installed engine and uninstallation passed. Interactive GUI testing remains necessary.'
} finally {
    # Only disposable files created by this test are removed. User libraries are untouched.
    if (Test-Path $nuanceTestRoot) { Remove-Item -Recurse -Force $nuanceTestRoot }
}
