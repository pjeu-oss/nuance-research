param([Parameter(Mandatory=$true)][string]$ModelPath,[string]$BuildDir)
$ErrorActionPreference='Stop'
$nuanceProject=Split-Path $PSScriptRoot -Parent
if (!$BuildDir) {$BuildDir=Join-Path $nuanceProject 'build'}
$BuildDir=[IO.Path]::GetFullPath($BuildDir)
New-Item -ItemType Directory -Force $BuildDir | Out-Null
$nuanceModelStage=Join-Path $BuildDir 'bundled-model'
python (Join-Path $PSScriptRoot 'prepare-model.py') ([IO.Path]::GetFullPath($ModelPath)) $nuanceModelStage
if ($LASTEXITCODE -ne 0) {throw 'Model staging failed'}
$env:NUANCE_BUNDLE_MODEL=$nuanceModelStage
python -c "import torch; assert torch.version.cuda is None, 'Use a CPU-only PyTorch build for this desktop package'"
if ($LASTEXITCODE -ne 0) {throw 'CPU-only runtime required'}
$env:PYINSTALLER_CONFIG_DIR=Join-Path $BuildDir 'pyinstaller-cache'
python -m PyInstaller --noconfirm --distpath (Join-Path $BuildDir 'dist') --workpath (Join-Path $BuildDir 'freeze') (Join-Path $PSScriptRoot 'engine.spec')
if ($LASTEXITCODE -ne 0) {throw 'Engine build failed'}
python (Join-Path $PSScriptRoot 'smoke.py') (Join-Path $BuildDir 'dist/NuanceEngine/NuanceEngine.exe')
if ($LASTEXITCODE -ne 0) {throw 'Portable smoke test failed'}
$nuanceStage=Join-Path $BuildDir 'windows-app'
New-Item -ItemType Directory -Force $nuanceStage | Out-Null
New-Item -ItemType Directory -Force (Join-Path $nuanceStage 'engine') | Out-Null
Copy-Item -Recurse -Force (Join-Path $BuildDir 'dist/NuanceEngine/*') (Join-Path $nuanceStage 'engine')
python (Join-Path $PSScriptRoot 'copy-notices.py') (Join-Path $nuanceStage 'Notices')
if ($LASTEXITCODE -ne 0) {throw 'License collection failed'}
$nuanceCompiler=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
& $nuanceCompiler /nologo /target:winexe /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll "/out:$nuanceStage/Nuance-Research.exe" (Join-Path $PSScriptRoot 'Launcher.cs')
if ($LASTEXITCODE -ne 0) {throw 'Launcher build failed'}
$nuanceIscc=Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe'
if (!(Test-Path $nuanceIscc)) {throw 'Install Inno Setup 6 from its official vendor before building the installer'}
& $nuanceIscc "/DStageDir=$nuanceStage" "/DReleaseDir=$BuildDir/releases" (Join-Path $PSScriptRoot 'windows.iss')
if ($LASTEXITCODE -ne 0) {throw 'Installer build failed'}

$nuanceInstaller=Join-Path $BuildDir 'releases/Nuance-Research-Windows-x64-Setup.exe'
$nuanceHash=(Get-FileHash -Algorithm SHA256 $nuanceInstaller).Hash.ToLowerInvariant()
Set-Content -Encoding ascii -Path ($nuanceInstaller+'.sha256') -Value ($nuanceHash+'  '+(Split-Path $nuanceInstaller -Leaf))
Write-Output "Built unsigned Windows beta: $nuanceInstaller"
