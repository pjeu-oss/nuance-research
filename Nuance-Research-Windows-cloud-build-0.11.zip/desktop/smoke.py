"""Exercise a frozen engine in a clean library: upload, vector workers, search."""
import subprocess,tempfile,json,time,sys
from pathlib import Path
import httpx
with tempfile.TemporaryDirectory(prefix='nuance-portable-') as tmp:
 data=Path(tmp);p=subprocess.Popen([sys.argv[1],'--data-dir',tmp,'--runtime-file',str(data/'runtime.json'),'--managed-log'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  for _ in range(120):
   if p.poll() is not None:raise RuntimeError((data/'desktop-server.log').read_text() if (data/'desktop-server.log').exists() else p.stdout.read())
   if (data/'runtime.json').exists():break
   time.sleep(.5)
  runtime=json.loads((data/'runtime.json').read_text());keys=json.loads((data/'access.json').read_text());headers={'Authorization':'Bearer '+next(iter(keys))}
  base='http://127.0.0.1:'+str(runtime['port'])
  with httpx.Client(base_url=base,headers=headers,timeout=120) as c:
   for _ in range(30):
    try:
     if c.get('/api/health').is_success:break
    except httpx.ConnectError:time.sleep(.2)
   assert c.get('/api/research/references').json()==[]
   collection=c.post('/api/collections',json={'name':'Portable smoke test'});collection.raise_for_status()
   cid=collection.json()['id']
   r=c.post('/api/documents',data={'collection_id':cid,'metadata':json.dumps({'title':'Synthetic neurotechnology law'})},files={'file':('synthetic.txt',b'Neurotechnology governance protects mental privacy. Legal rights require careful regulation of brain computer interfaces.','text/plain')});r.raise_for_status()
   r=c.post('/api/search',json={'query':'legal regulation of neurotechnology','collection_ids':[cid]});r.raise_for_status();assert r.json()['results'],r.text
   assert c.get('/static/preferences.js').is_success
   assert c.get('/static/preferences.css').is_success
   assert c.get('/static/translations.js').is_success
   active=c.get('/api/runtime').json()
   time.sleep(32)
   idle=c.get('/api/runtime').json()
   print(json.dumps({'platform':sys.platform,'scope':'empty portable library + one synthetic text document','active':active,'idle':idle}))
   assert not idle.get('embedding_worker',{}).get('active') and not idle.get('vector_worker',{}).get('active'),'Idle workers were not released'
   print('Synthetic upload and hybrid search passed with frozen workers.')
   print('Clean portable engine started with an independent library.')
   (data/'smoke-base.json').write_text(json.dumps({'base':base,'headers':headers}))
   r=c.post('/desktop/quit');assert r.is_success,r.text
  p.wait(timeout=15);assert p.returncode==0
  # A reusable loopback origin keeps browser preferences across ordinary relaunches.
  original_port=runtime['port']
  p=subprocess.Popen([sys.argv[1],'--data-dir',tmp,'--runtime-file',str(data/'runtime.json'),'--managed-log'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  for _ in range(120):
   if p.poll() is not None:raise RuntimeError((data/'desktop-server.log').read_text())
   if (data/'runtime.json').exists():break
   time.sleep(.5)
  restarted=json.loads((data/'runtime.json').read_text())
  if sys.platform!='win32':assert restarted['port']==original_port
  base='http://127.0.0.1:'+str(restarted['port'])
  with httpx.Client(base_url=base,headers=headers,timeout=10) as c:
   for _ in range(30):
    try:
     if c.get('/api/health').is_success:break
    except httpx.ConnectError:time.sleep(.2)
   assert c.get('/api/health').is_success
   assert c.post('/desktop/quit').is_success
  p.wait(timeout=15);assert p.returncode==0
  print('Relaunch retained the independent library; local port reused: '+str(restarted['port']==original_port))
 finally:
  if p.poll() is None:p.terminate();p.wait(timeout=15)
