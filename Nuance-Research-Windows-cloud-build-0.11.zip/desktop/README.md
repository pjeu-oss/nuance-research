# Distribution autonome — bêta 0.11

La distribution actuelle liée au dossier de développement du créateur ne doit pas être utilisée comme installateur universel. Le nouveau moteur embarque Python, les dépendances locales, les modèles et les ressources web. Il crée une bibliothèque vide par utilisateur, indépendamment du Mac du créateur. Il n’embarque pas ses documents, son historique ni ses credentials.

Mac (Apple Silicon, macOS 14 minimum pour la préversion construite ici) : application Cocoa/WebKit, moteur local lié à 127.0.0.1 avec port libre, accès personnel créé au premier lancement. Données dans `~/Library/Application Support/Nuance-Research`. Le moteur est arrêté avec l’application. Un fichier `.pkg` installe l’application dans Applications. Construction propre à l’architecture du Mac utilisé ; ne pas annoncer une version universelle Intel/Apple Silicon sans les deux builds et tests.

Windows : moteur local autonome, lanceur avec icône dans la zone de notification et accès dans le navigateur. L’installateur Inno Setup est un seul `.exe`, sans Docker ni Python à installer. Données dans `%LOCALAPPDATA%/Nuance-Research`. Quitter via l’icône de notification arrête le moteur proprement. Cette version nécessite une construction et des tests réels sur Windows x64 ; aucun exécutable Windows ne peut être fabriqué par PyInstaller sur macOS.

## Construire

Installer les dépendances du projet avec `.[ml]`, PyInstaller, puis télécharger la révision du modèle avec `scripts/prefetch_model.py`. Régler `NUANCE_BUNDLE_MODEL` vers ce dossier, puis exécuter PyInstaller avec `desktop/engine.spec`. `desktop/engine.py` doit être inclus tel quel ; ses modes worker évitent de dépendre d’un Python système dans le paquet figé.

Sur Mac, compiler `desktop/Nuance.swift` avec Cocoa/WebKit, embarquer la sortie `NuanceEngine/` dans les Resources du bundle `.app`, puis générer le `.pkg` avec pkgbuild. Sur Windows, compiler `Launcher.cs` avec csc (Windows Forms, System.Web.Extensions), placer `NuanceEngine/` sous `engine/` à côté du lanceur, puis compiler `windows.iss` avec Inno Setup.

Avant distribution publique : signature Developer ID et notarisation Apple, signature du Windows Setup, essais sur une machine propre de chaque architecture, import PDF et recherche sémantique, mises à jour et sauvegardes. Les signatures exigent les comptes/certificats du propriétaire du logiciel. Ne pas contourner Gatekeeper ou SmartScreen. Les artefacts non signés sont des préversions de test, pas des installateurs prêts pour le grand public.

## Sous-domaine indépendant

Prévoir un sous-domaine dédié de nuance-app.eu, un déploiement distinct, des comptes et une base distincts. Ne pas modifier les enregistrements DNS du domaine principal, les API ou le stockage utilisés par les applications iOS/Android. Le site propose les téléchargements correspondant à chaque système et un lien pour ouvrir la version web. Le moteur web garde les documents sur le serveur choisi ; le moteur installé les garde sur le laptop. La synchronisation des deux bibliothèques n’est pas implémentée.

Aucun DNS ni serveur public n’a été modifié. Avant publication : identifier le fournisseur DNS, le serveur cible, les conflits de proxy/ports et l’authentification des utilisateurs. Ne jamais publier le moteur de développement du créateur ou sa clé personnelle.
