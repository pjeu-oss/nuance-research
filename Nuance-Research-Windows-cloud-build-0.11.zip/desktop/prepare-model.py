"""Stage a verified model once, omitting duplicate PyTorch weights if safetensors exists."""
import argparse,json,shutil,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from nuance.config import tree_digest
p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('destination');args=p.parse_args()
source=Path(args.source).resolve();destination=Path(args.destination).resolve()
if source==destination or source in destination.parents:raise SystemExit('Use a separate build staging directory')
manifest=json.loads((source/'nuance-model.json').read_text())
if manifest.get('artifact_sha256')!=tree_digest(source):raise SystemExit('Model snapshot verification failed')
# Destination is exclusively a disposable build artifact, never a user library.
if destination.exists():
    if not (destination/'nuance-model.json').exists():raise SystemExit('Refusing to replace a non-model directory')
    shutil.rmtree(destination)
shutil.copytree(source,destination)
if (destination/'model.safetensors').exists():(destination/'pytorch_model.bin').unlink(missing_ok=True)
manifest['artifact_sha256']=tree_digest(destination)
(destination/'nuance-model.json').write_text(json.dumps(manifest,indent=2)+'\n')
