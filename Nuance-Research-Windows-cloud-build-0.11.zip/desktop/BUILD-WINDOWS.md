# Windows beta: build and test

No Windows executable has been built or tested on this Mac. This kit creates one `Nuance-Research-Windows-x64-Setup.exe` **on a Windows x64 build computer**. Testers installing that resulting file do not need Python, Docker or a GPU. This is a local engine opened in their default browser, with a tray icon to quit it.

## Cloud build from a Mac

The project includes `.github/workflows/windows-build.yml`, a manually launched GitHub Actions workflow on a Windows Server 2022 x64 runner. No physical Windows PC is needed. This workflow has been structurally checked on macOS; it has **not run yet** because no authenticated build account/repository is available in this session.

1. Put this curated source package in a **private** GitHub repository, with `pyproject.toml` and `.github` at the repository root. Do not upload local databases, your documents, credentials, `work`, `AppData` or build directories.
2. Check the account's included Actions quota, artifact-storage quota and spending settings before dispatch. The workflow does not buy a plan or provision a paid larger runner. A zero spending limit is recommended for this beta build.
3. In GitHub, choose **Actions → Windows beta installer → Run workflow**. The workflow runs only on manual dispatch, has a 60-minute timeout and cancels an older concurrent build on the same branch.
4. After success, download **Nuance-Research-Windows-x64-Beta** from the run's Artifacts section. Unzip it to get the single installer `.exe`, its SHA-256 and a build manifest. Artifacts expire after three days; save your copy promptly.
5. Send only the installer and checksum to testers. Test interactive tray/browser behavior on an ordinary Windows laptop before broader distribution. The beta installer is unsigned and can trigger Windows reputation warnings.

The cloud build checks unit tests, the frozen CPU engine, synthetic upload/search, worker release at idle and authenticated shutdown/relaunch. It also silently installs the finished package into a disposable directory, tests its installed engine, then uninstalls it. Failed tests prevent delivery of an installer artifact. No personal bibliography is used.

Official references: [GitHub-hosted Windows runners](https://docs.github.com/en/actions/concepts/runners/github-hosted-runners), [Windows 2022 tools including Inno Setup](https://github.com/actions/runner-images/blob/main/images/windows/Windows2022-Readme.md), [Actions billing](https://docs.github.com/en/billing/concepts/product-billing/github-actions).

## Build computer

Use Windows x64, Python 3.12 x64 and Inno Setup 6 from their official vendors. Open PowerShell in the unzipped project directory. These commands install build dependencies and download a pinned multilingual model; they do not upload documents.

```powershell
python -m venv .build-venv
.\.build-venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\.build-venv\Scripts\python.exe -m pip install -e ".[ml,dev]" "PyInstaller==6.22.3" "portalocker==2.10.1"
# Temporarily use this virtual environment for the build script.
$env:PATH = "$PWD\.build-venv\Scripts;" + $env:PATH
python scripts/prefetch_model.py --output build/model
python -m pytest tests -q
powershell -NoProfile -File desktop/build-windows.ps1 -ModelPath build/model -BuildDir build/package
```

The model output must be empty for the initial download. For later builds, reuse the verified model directory. The build first tests the frozen engine with an empty temporary library, a synthetic import, hybrid search, language/theme assets, idle resource release and authenticated shutdown. It stops if these tests fail. Keep at least **10 GB free for the build**; build dependencies and intermediate copies are much larger than the installer. If local PowerShell policy blocks the script, ask your administrator to permit this reviewed script under your organization's policy.

The output is `build/package/releases/Nuance-Research-Windows-x64-Setup.exe`. Upload only the installer, its SHA-256 file and the relevant release notes. Never distribute `AppData`, access keys, sources, user databases or a development library. Sign the installer with the publisher's certificate before public distribution. No signing certificate is included.

## Recipient test checklist

1. Install into the current user's local Programs directory. Confirm the installer checks space and creates no system service, startup task or firewall rule.
2. Open the app twice: the second launch must not create a second engine. A browser window opens on a loopback port; the tray icon remains visible.
3. Choose English / French, then Light / Dark / System. Reload and reopen the app to confirm persistence. Source text, saved quotes and drafts must remain unchanged.
4. Import a synthetic PDF, DOCX and text file; verify physical PDF pages, read/highlight, search, projects, draft editing and BibTeX export.
5. With the machine under load, monitor Nuance's own CPU and memory in Task Manager. Default CPU threads: 2. Embedding/vector workers release after 30 seconds of inactivity. Cold searches can therefore take longer.
6. Test low-disk rejection, invalid files and long operations in a disposable test library. Stop any stress test before the operating system becomes unresponsive. Guard tests run with disposable workers; do not fill a real disk or exhaust all physical memory to test them.
7. Quit using the tray menu. Confirm the engine and its children exit, then reopen. Uninstall preserves the bibliography in `%LOCALAPPDATA%\Nuance-Research`; no user-library deletion is defined in the installer.
8. Record Windows version, hardware, observed memory/storage, startup/search times and errors. Validate upgrades and backups before using an irreplaceable bibliography.

## Limits

The watchdog samples once per second: it reduces risk but is not a hard OS memory reservation and cannot guarantee a computer never runs out of memory. Disk checks can race with other applications writing. Large libraries consume storage proportional to sources and indexes. Windows resource figures and installation/upgrade behavior still require real-machine validation. Rendering thousands of map nodes, very large local Qdrant indexes and cold model startup are not optimized by this release.
