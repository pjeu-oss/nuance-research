from pathlib import Path
import os
from PyInstaller.utils.hooks import collect_submodules,collect_data_files,copy_metadata
root=Path(SPECPATH).parent
model=Path(os.environ['NUANCE_BUNDLE_MODEL'])
datas=[(str(root/'nuance/static'),'nuance/static'),(str(root/'nuance/styles'),'nuance/styles'),(str(model),'model')]
for p in ('sentence_transformers','transformers','tokenizers','huggingface_hub','qdrant_client','citeproc'):
 datas+=collect_data_files(p)
for p in ('sentence-transformers','transformers','torch','huggingface-hub','scikit-learn','numpy','scipy','qdrant-client','tqdm','regex','packaging','PyYAML','tokenizers','safetensors'):
 datas+=copy_metadata(p)
hidden=['nuance.extraction_worker','nuance.embedding_worker','nuance.vector_worker','sentence_transformers','uvicorn.logging','uvicorn.loops.asyncio','uvicorn.protocols.http.h11_impl','uvicorn.lifespan.on','sqlalchemy.dialects.sqlite','portalocker']
a=Analysis([str(root/'desktop/engine.py')],pathex=[str(root)],datas=datas,hiddenimports=hidden,excludes=['bertopic','umap','numba','matplotlib','IPython','jupyter','tkinter','tensorflow','torchvision','torchaudio','pytest'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='NuanceEngine',debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=(os.name!='nt'))
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='NuanceEngine')
