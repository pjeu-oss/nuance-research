"""Preserve dependency notices from the build environment in the distribution."""
import sys,shutil,sysconfig
from pathlib import Path
root=Path(__file__).resolve().parent.parent;target=Path(sys.argv[1]);target.mkdir(parents=True,exist_ok=True)
for name in ['LICENSE','LICENSES.md']:shutil.copy(root/name,target/name)
for metadata in Path(sysconfig.get_path('purelib')).glob('*.dist-info'):
    for p in metadata.rglob('*'):
        if p.is_file() and ('license' in p.name.lower() or 'notice' in p.name.lower()):
            destination=target/metadata.name/p.relative_to(metadata);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy(p,destination)
