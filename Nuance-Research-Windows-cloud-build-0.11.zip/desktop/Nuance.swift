import Cocoa
import WebKit

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, WKScriptMessageHandler {
    var window: NSWindow!
    var web: WKWebView!
    var server: Process?
    var downloads: [WKDownload] = []
    var root = ""
    var localPort = 0
    var runtimePath = ""
    var key = ""
    var attempts = 0
    var poll: Timer?
    var language = UserDefaults.standard.string(forKey:"NuanceLanguage") ?? "fr"
    func label(_ french:String,_ english:String)->String{return language == "en" ? english : french}
    func updateMenu(){
        let menu=NSMenu();let item=NSMenuItem();menu.addItem(item)
        let appMenu=NSMenu();appMenu.addItem(withTitle:label("Quitter Nuance-Research","Quit Nuance-Research"),action:#selector(NSApplication.terminate(_:)),keyEquivalent:"q");item.submenu=appMenu
        let edit=NSMenuItem();menu.addItem(edit);let editMenu=NSMenu(title:label("Édition","Edit"));edit.submenu=editMenu
        for (fr,en,action,key) in [("Annuler","Undo","undo:","z"),("Couper","Cut","cut:","x"),("Copier","Copy","copy:","c"),("Coller","Paste","paste:","v"),("Tout sélectionner","Select all","selectAll:","a")]{editMenu.addItem(withTitle:label(fr,en),action:Selector(action),keyEquivalent:key)}
        NSApp.mainMenu=menu
    }
    func configurePreferenceScript(){
        let values=["language":language,"theme":UserDefaults.standard.string(forKey:"NuanceAppearance") ?? "light"]
        guard let data=try? JSONSerialization.data(withJSONObject:values),let json=String(data:data,encoding:.utf8) else{return}
        let script="try{const prefs="+json+";localStorage.setItem('nuance.language',prefs.language);localStorage.setItem('nuance.theme',prefs.theme);}catch{}"
        web.configuration.userContentController.removeAllUserScripts()
        web.configuration.userContentController.addUserScript(WKUserScript(source:script,injectionTime:.atDocumentStart,forMainFrameOnly:true))
    }
    func userContentController(_ controller:WKUserContentController,didReceive message:WKScriptMessage){
        guard message.name == "nuancePreferences",let value=message.body as? [String:String],let lang=value["language"],["fr","en"].contains(lang) else{return}
        language=lang;UserDefaults.standard.set(lang,forKey:"NuanceLanguage")
        if let preference=value["preference"],["light","dark","system"].contains(preference){UserDefaults.standard.set(preference,forKey:"NuanceAppearance")}
        updateMenu();configurePreferenceScript()
        window.appearance=NSAppearance(named:value["theme"] == "dark" ? .darkAqua : .aqua)
    }
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        updateMenu()
        window=NSWindow(contentRect:NSRect(x:0,y:0,width:1250,height:860),styleMask:[.titled,.closable,.miniaturizable,.resizable],backing:.buffered,defer:false)
        window.title="Nuance-Research";window.center()
        let configuration=WKWebViewConfiguration();configuration.userContentController.add(self,name:"nuancePreferences")
        web=WKWebView(frame:window.contentView!.bounds,configuration:configuration);web.autoresizingMask=[.width,.height];web.navigationDelegate=self;web.uiDelegate=self
        configurePreferenceScript()
        window.contentView=web;window.makeKeyAndOrderFront(nil);NSApp.activate(ignoringOtherApps:true)
        guard let resource=Bundle.main.resourceURL else {showError(label("Moteur embarqué introuvable.","Bundled engine was not found."));return}
        root=resource.path
        let support=FileManager.default.urls(for:.applicationSupportDirectory,in:.userDomainMask)[0].appendingPathComponent("Nuance-Research")
        do {try FileManager.default.createDirectory(at:support,withIntermediateDirectories:true)} catch {showError(error.localizedDescription);return}
        runtimePath=support.appendingPathComponent("runtime-"+UUID().uuidString+".json").path
        web.loadHTMLString("<html><body style='font-family:system-ui;padding:60px;background:#edf4ef;color:#456352'><h1>Nuance-Research</h1><p>\(label("Ouverture de votre bibliothèque locale…","Opening your local library…"))</p></body></html>",baseURL:nil)
        let process=Process();process.executableURL=resource.appendingPathComponent("NuanceEngine/NuanceEngine")
        process.arguments=["--data-dir",support.path,"--runtime-file",runtimePath,"--managed-log"]
        let logPath=support.appendingPathComponent("desktop-server.log").path
        process.standardOutput=FileHandle.nullDevice;process.standardError=FileHandle.nullDevice
        do {try process.run();server=process} catch {showError(label("Démarrage impossible : ","Unable to start: ")+error.localizedDescription);return}
        poll=Timer.scheduledTimer(withTimeInterval:1,repeats:true){_ in
            self.attempts+=1
            if let data=try? Data(contentsOf:URL(fileURLWithPath:self.runtimePath)),let runtime=try? JSONSerialization.jsonObject(with:data) as? [String:Any],let port=runtime["port"] as? Int,
               let access=try? Data(contentsOf:support.appendingPathComponent("access.json")),let keys=try? JSONSerialization.jsonObject(with:access) as? [String:Any],let credential=keys.keys.first {
                self.localPort=port;self.key=credential
                let task=URLSession.shared.dataTask(with:URL(string:"http://127.0.0.1:\(port)/api/health")!){_,response,_ in
                    DispatchQueue.main.async {if let http=response as? HTTPURLResponse,http.statusCode==200 {self.poll?.invalidate();self.web.load(URLRequest(url:URL(string:"http://127.0.0.1:\(port)/workspace")!))}}
                };task.resume()
            }
            if self.attempts>=120 || !process.isRunning {self.poll?.invalidate();self.showError(self.label("Le moteur n’a pas démarré. S’il est déjà ouvert, utilisez sa fenêtre existante. Journal : ","The engine did not start. If already open, use its existing window. Log: ")+logPath)}
        }
    }
    func webView(_ webView: WKWebView,didFinish navigation: WKNavigation!) {
        guard let url=web.url,url.host=="127.0.0.1",url.port==localPort else {return}
        let encoded=(try? JSONSerialization.data(withJSONObject:[key])).flatMap{String(data:$0,encoding:.utf8)} ?? "[]"
        let script="(()=>{const key="+encoded+"[0]; const field=document.getElementById('key')||document.getElementById('token'); const button=document.getElementById('connect'); if(field && button && !field.value){field.value=key;button.click();}})()"
        web.evaluateJavaScript(script,completionHandler:nil)
    }
    func webView(_ webView: WKWebView,decidePolicyFor navigationAction: WKNavigationAction,decisionHandler: @escaping (WKNavigationActionPolicy)->Void) {
        guard let url=navigationAction.request.url else {decisionHandler(.cancel);return}
        if navigationAction.shouldPerformDownload {decisionHandler(.download);return}
        if url.scheme=="about" || (url.scheme=="http" && url.host=="127.0.0.1" && url.port==localPort) || url.scheme=="blob" {decisionHandler(.allow)}
        else {if ["https","http"].contains(url.scheme ?? ""){NSWorkspace.shared.open(url)};decisionHandler(.cancel)}
    }
    func webView(_ webView: WKWebView,runOpenPanelWith parameters: WKOpenPanelParameters,initiatedByFrame frame: WKFrameInfo,completionHandler: @escaping ([URL]?)->Void) {
        let panel=NSOpenPanel();panel.canChooseDirectories=false;panel.canChooseFiles=true;panel.allowsMultipleSelection=parameters.allowsMultipleSelection
        panel.beginSheetModal(for:window){response in completionHandler(response == .OK ? panel.urls : nil)}
    }
    func webView(_ webView: WKWebView,runJavaScriptAlertPanelWithMessage message:String,initiatedByFrame frame:WKFrameInfo,completionHandler:@escaping ()->Void){let alert=NSAlert();alert.messageText=message;alert.beginSheetModal(for:window){_ in completionHandler()}}
    func webView(_ webView: WKWebView,runJavaScriptConfirmPanelWithMessage message:String,initiatedByFrame frame:WKFrameInfo,completionHandler:@escaping (Bool)->Void){let alert=NSAlert();alert.messageText=message;alert.addButton(withTitle:label("Continuer","Continue"));alert.addButton(withTitle:label("Annuler","Cancel"));alert.beginSheetModal(for:window){response in completionHandler(response == .alertFirstButtonReturn)}}
    func webView(_ webView: WKWebView,runJavaScriptTextInputPanelWithPrompt prompt:String,defaultText:String?,initiatedByFrame frame:WKFrameInfo,completionHandler:@escaping (String?)->Void){let alert=NSAlert();alert.messageText=prompt;let field=NSTextField(frame:NSRect(x:0,y:0,width:380,height:24));field.stringValue=defaultText ?? "";alert.accessoryView=field;alert.addButton(withTitle:label("Créer","Create"));alert.addButton(withTitle:label("Annuler","Cancel"));alert.beginSheetModal(for:window){response in completionHandler(response == .alertFirstButtonReturn ? field.stringValue : nil)}}
    func webView(_ webView: WKWebView,decidePolicyFor navigationResponse:WKNavigationResponse,decisionHandler:@escaping (WKNavigationResponsePolicy)->Void){decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)}
    func webView(_ webView:WKWebView,navigationAction:WKNavigationAction,didBecome download:WKDownload){downloads.append(download);download.delegate=self}
    func webView(_ webView:WKWebView,navigationResponse:WKNavigationResponse,didBecome download:WKDownload){downloads.append(download);download.delegate=self}
    func download(_ download:WKDownload,decideDestinationUsing response:URLResponse,suggestedFilename:String,completionHandler:@escaping (URL?)->Void){let panel=NSSavePanel();panel.nameFieldStringValue=suggestedFilename;panel.beginSheetModal(for:window){result in completionHandler(result == .OK ? panel.url : nil)}}
    func showError(_ text:String){let alert=NSAlert();alert.messageText="Nuance-Research";alert.informativeText=text;alert.runModal()}
    func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication)->Bool{return true}
    func applicationWillTerminate(_ notification:Notification){poll?.invalidate();if let server=server,server.isRunning{server.terminate()}}
}
let app=NSApplication.shared
let delegate=AppDelegate()
app.delegate=delegate
app.run()
