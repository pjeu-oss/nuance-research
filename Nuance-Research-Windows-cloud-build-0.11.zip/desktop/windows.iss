#define AppVersion "0.11.0"
#ifndef StageDir
#define StageDir "..\build\windows-app"
#endif
#ifndef ReleaseDir
#define ReleaseDir "..\build\releases"
#endif
[Setup]
AppId={{F46408CE-A719-4575-9429-F723B14F21F4}
AppName=Nuance-Research
AppVersion={#AppVersion}
DefaultDirName={localappdata}\Programs\Nuance-Research
DefaultGroupName=Nuance-Research
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputBaseFilename=Nuance-Research-Windows-x64-Setup
OutputDir={#ReleaseDir}
Compression=lzma2
SolidCompression=yes
DiskSpanning=no
ExtraDiskSpaceRequired=1073741824
CloseApplications=yes
RestartApplications=no
UninstallDisplayIcon={app}\Nuance-Research.exe
[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "french"; MessagesFile: "compiler:Languages\French.isl"
[Files]
Source: "{#StageDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\Nuance-Research"; Filename: "{app}\Nuance-Research.exe"
Name: "{autodesktop}\Nuance-Research"; Filename: "{app}\Nuance-Research.exe"; Tasks: desktopicon
[Tasks]
Name: desktopicon; Description: "Create a desktop shortcut"; Flags: unchecked
[Run]
Filename: "{app}\Nuance-Research.exe"; Description: "Open Nuance-Research"; Flags: nowait postinstall skipifsilent