using System;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Drawing;
using System.Net;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Collections.Generic;
class Launcher {
 [STAThread] static void Main() {
  bool first;
  var singleton=new Mutex(true,"Local\\NuanceResearchDesktop",out first);
  if(!first){MessageBox.Show("Nuance-Research is already running. Use its tray icon to quit.","Nuance-Research");singleton.Dispose();return;}
  Application.EnableVisualStyles();
  var home=AppDomain.CurrentDomain.BaseDirectory;
  var engine=new Process();engine.StartInfo=new ProcessStartInfo(Path.Combine(home,"engine","NuanceEngine.exe"),"--open-browser"){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=home};
  try {engine.Start();}catch(Exception e){MessageBox.Show(e.Message,"Nuance-Research");return;}
  var tray=new NotifyIcon(){Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath),Text="Nuance-Research — local engine",Visible=true};
  var menu=new ContextMenuStrip();menu.Items.Add("Nuance-Research is running locally");
  menu.Items.Add("Quit Nuance-Research",null,(s,e)=>{
   try {
    var data=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Nuance-Research");
    var json=new JavaScriptSerializer();var runtime=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(data,"runtime.json")));
    if(Convert.ToInt32(runtime["pid"])==engine.Id){var keys=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(data,"access.json")));string key=null;foreach(var k in keys.Keys){key=k;break;}
     var request=(HttpWebRequest)WebRequest.Create("http://127.0.0.1:"+runtime["port"]+"/desktop/quit");request.Method="POST";request.Headers["Authorization"]="Bearer "+key;request.Timeout=5000;request.GetResponse().Close();if(!engine.WaitForExit(15000)){MessageBox.Show("Shutdown is taking longer than expected. The engine is finishing its work; check Task Manager before reopening.","Nuance-Research");return;}}
   }catch(Exception){MessageBox.Show("The engine may still be running. Check Task Manager before reopening.","Nuance-Research");}
   tray.Visible=false;Application.Exit();
  });tray.ContextMenuStrip=menu;
  var timer=new System.Windows.Forms.Timer(){Interval=1000};timer.Tick+=(s,e)=>{if(engine.HasExited){timer.Stop();tray.Visible=false;if(engine.ExitCode!=0)MessageBox.Show("The engine did not start. It may already be open; check the log in AppData/Local/Nuance-Research.","Nuance-Research");Application.Exit();}};timer.Start();Application.Run();tray.Dispose();singleton.ReleaseMutex();singleton.Dispose();engine.Dispose();
 }
}
