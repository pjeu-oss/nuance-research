"""Build one .pkg for the active Mac architecture, from a verified model snapshot."""
import argparse,os,subprocess,sys,shutil,plistlib,platform
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--build-dir',required=True);p.add_argument('--release-dir',required=True);args=p.parse_args()
root=Path(__file__).resolve().parent.parent;work=Path(args.build_dir).resolve();release=Path(args.release_dir).resolve();work.mkdir(parents=True,exist_ok=True);release.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(root/'desktop/prepare-model.py'),str(Path(args.model).resolve()),str(work/'bundled-model')],check=True)
env={**os.environ,'NUANCE_BUNDLE_MODEL':str(work/'bundled-model'),'PYINSTALLER_CONFIG_DIR':str(work/'cache')}
def run(cmd):subprocess.run([str(c) for c in cmd],check=True,env=env)
run([sys.executable,'-m','PyInstaller','--noconfirm','--distpath',work/'dist','--workpath',work/'freeze',root/'desktop/engine.spec'])
run([sys.executable,root/'desktop/smoke.py',work/'dist/NuanceEngine/NuanceEngine'])
app=work/'app/Nuance-Research.app';contents=app/'Contents';(contents/'MacOS').mkdir(parents=True,exist_ok=True);(contents/'Resources').mkdir(parents=True,exist_ok=True)
run(['xcrun','swiftc','-target',platform.machine()+'-apple-macos14.0','-module-cache-path',work/'swift-cache',root/'desktop/Nuance.swift','-o',contents/'MacOS/Nuance-Research','-framework','Cocoa','-framework','WebKit'])
shutil.copytree(work/'dist/NuanceEngine',contents/'Resources/NuanceEngine',dirs_exist_ok=True);shutil.copy(root/'desktop/Nuance.icns',contents/'Resources/Nuance.icns')
info={'CFBundleName':'Nuance-Research','CFBundleDisplayName':'Nuance-Research','CFBundleExecutable':'Nuance-Research','CFBundleIdentifier':'eu.nuance.research.desktop','CFBundlePackageType':'APPL','CFBundleIconFile':'Nuance.icns','CFBundleShortVersionString':'0.11.0','CFBundleVersion':'0.11.0','LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True,'NSAppTransportSecurity':{'NSAllowsLocalNetworking':True}}
(contents/'Info.plist').write_bytes(plistlib.dumps(info))
run([sys.executable,root/'desktop/copy-notices.py',contents/'Resources/Notices'])
run(['codesign','--force','--deep','--sign','-',app])
run(['pkgbuild','--root',app.parent,'--install-location','/Applications','--identifier','eu.nuance.research.desktop','--version','0.11.0',release/('Nuance-Research-Mac-'+platform.machine()+'-Preview.pkg')])
print('Unsigned preview built; Developer ID signing, notarization and clean-machine validation still required.')
