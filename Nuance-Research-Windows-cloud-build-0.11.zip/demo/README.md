# Corpus synthétique — CC0-1.0
Textes inventés pour tester la provenance, les langues, les contre-arguments et les thèmes.
Ils ne constituent pas des études scientifiques et n’établissent aucun fait empirique.
Le PDF est généré depuis le même corpus par `scripts/make_demo.py` (ReportLab, extra dev).
Auteurs : Nuance synthetic demo. Réutilisation sans restriction sous CC0-1.0.
