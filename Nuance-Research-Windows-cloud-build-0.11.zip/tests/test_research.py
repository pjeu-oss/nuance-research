import math
import pytest
from conftest import headers,collection,upload
from nuance.research import parse_references,meta_analysis,MetaRequest
from fastapi import HTTPException

def test_ris_and_csl():
    r=parse_references('ris','TY  - JOUR\nTI  - Example\nAU  - Doe, Jane\nPY  - 2024/01/01\nDO  - https://doi.org/10.123/example\nKW  - Ethics\nER  - \n')[0]
    assert r['year']==2024 and r['doi']=='10.123/example' and r['tags']==['Ethics']
    assert parse_references('csl-json','[{"title":"A","author":[{"family":"Doe","given":"Jane"}],"issued":{"date-parts":[[2022]]}}]')[0]['authors']==['Doe Jane']
    with pytest.raises(ValueError):parse_references('ris','TY  - JOUR\nTI  - Incomplete')

def test_import_dedup_isolation_and_export(client):
    payload={'format':'csl-json','text':'[{"title":"Private","DOI":"10.123/a","year":2024}]'}
    assert client.post('/api/research/import',json=payload,headers=headers()).json()['created']==1
    assert client.post('/api/research/import',json=payload,headers=headers()).json()['duplicates']==1
    for key in ['b','c','e']:
        assert client.get('/api/research/references',headers=headers(key)).json()==[]
    assert client.get('/api/research/export',headers=headers()).json()[0]['DOI']=='10.123/a'
    assert client.post('/api/research/import',json=payload,headers=headers('b')).status_code==403

def test_sync_link_and_acl_revocation(client):
    cid=collection(client,['eve']);did=upload(client,cid,name='Library.txt')
    client.put('/api/documents/'+did+'/acl',json={'readers':['eve']},headers=headers())
    assert client.post('/api/research/sync-documents',json={},headers=headers('e')).json()['linked_or_created']==1
    ref=client.get('/api/research/references',headers=headers('e')).json()[0]
    assert ref['document_id']==did
    assert client.put('/api/collections/'+cid+'/acl',json={'readers':[]},headers=headers()).status_code==200
    assert client.get('/api/research/references',headers=headers('e')).json()==[]
    assert client.get('/api/research/statistics',headers=headers('e')).json()['references']==0

def test_record_versions_and_owner_isolation(client):
    path='/api/research/records/draft/draft-one'
    first=client.put(path,json={'revision':0,'payload':{'title':'Article','body':'Text'}},headers=headers())
    assert first.status_code==200 and first.json()['revision']==1
    assert client.put(path,json={'revision':0,'payload':{'body':'stale'}},headers=headers()).status_code==409
    assert client.put(path,json={'revision':1,'payload':{}},headers=headers('e')).status_code==404
    assert client.get('/api/research/records/draft',headers=headers('e')).json()==[]

def test_suggestions_are_exact_sources(client):
    cid=collection(client);upload(client,cid)
    client.post('/api/research/sync-documents',json={},headers=headers())
    r=client.post('/api/research/suggest',json={'query':'autonomie'},headers=headers()).json()['results'][0]
    page=client.get('/api/documents/'+r['document_id']+'/pages/'+str(r['page']),headers=headers()).json()
    assert r['quote']==page['text'][r['span']['start']:r['span']['end']]
    assert r['reference']['document_id']==r['document_id']

def request(rows=None,**kw):
    return MetaRequest(measure='SMD',outcome='Attention score',timepoint='3 months',comparability_confirmed=True,
      rows=rows or [{'study_id':'a','source':'A p2','effect':.2,'se':.1,'validated':True},{'study_id':'b','source':'B p4','effect':.4,'se':.1,'validated':True}],**kw)

def test_meta_known_result():
    r=meta_analysis(request())
    assert r['pooled']==pytest.approx(.3)
    assert r['Q']==pytest.approx(2)
    assert r['tau2']==pytest.approx(.01)
    assert r['I2_percent']==pytest.approx(50)
    assert r['se']==pytest.approx(.1)
    assert r['ci95']==pytest.approx([.104003601546,.495996398454])

def test_meta_no_heterogeneity():
    r=meta_analysis(request([{'study_id':str(i),'source':'Source p1','effect':.2,'se':.1,'validated':True} for i in range(3)]))
    assert r['tau2']==0 and r['I2_percent']==0 and r['se']==pytest.approx(.1/math.sqrt(3))

@pytest.mark.parametrize('mutation',[{'validated':False},{'se':0},{'se':float('nan')},{'effect':float('inf')},{'study_id':'b'},{'source':''}])
def test_meta_rejects_invalid_and_unvalidated(mutation):
    req=request();req.rows[0].update(mutation)
    with pytest.raises(HTTPException):meta_analysis(req)

def test_meta_requires_comparability_and_audits(client):
    req=request().model_dump();req['comparability_confirmed']=False
    assert client.post('/api/research/meta-analysis',json=req,headers=headers()).status_code==422
    req['comparability_confirmed']=True
    r=client.post('/api/research/meta-analysis',json=req,headers=headers())
    assert r.status_code==200
    assert len(client.get('/api/research/records/analysis',headers=headers()).json())==1
    assert client.get('/api/research/records/analysis',headers=headers('e')).json()==[]

def test_saved_citations_require_real_text_and_page(client):
    cid=collection(client);upload(client,cid)
    client.post('/api/research/sync-documents',json={},headers=headers())
    item=client.post('/api/research/suggest',json={'query':'autonomie'},headers=headers()).json()['results'][0]
    path='/api/research/records/draft/quoted'
    assert client.put(path,json={'revision':0,'payload':{'body':item['quote'],'citations':[item]}},headers=headers()).status_code==200
    wrong={**item,'page':999}
    assert client.put(path,json={'revision':1,'payload':{'citations':[wrong]}},headers=headers()).status_code==422
    wrong={**item,'quote':'Fabricated quotation'}
    assert client.put(path,json={'revision':1,'payload':{'citations':[wrong]}},headers=headers()).status_code==422
