import os,sys,subprocess
from types import SimpleNamespace
from pathlib import Path
import pytest
from nuance import resource_guard as guard
from nuance.config import Settings
from nuance.extract import extract,ExtractionError

def test_low_disk_refuses_without_touching_document(tmp_path,monkeypatch):
    source=tmp_path/'source.txt';source.write_text('Keep this source')
    monkeypatch.setattr(guard.shutil,'disk_usage',lambda p:SimpleNamespace(free=100))
    with pytest.raises(RuntimeError,match='disk'):guard.ensure_disk(tmp_path,1024)
    assert source.read_text()=='Keep this source'

def test_memory_admission_does_not_launch(monkeypatch):
    monkeypatch.setattr(guard,'available_memory',lambda:SimpleNamespace(total=8*1024**3,available=64*guard.MiB))
    monkeypatch.setattr(guard.subprocess,'Popen',lambda *a,**k:pytest.fail('Must refuse before spawning'))
    with pytest.raises(RuntimeError,match='memory'):guard.spawn_worker(['unused'],os.environ,Settings(),'embedding')

def test_hung_worker_stopped_and_reaped():
    process=subprocess.Popen([sys.executable,'-u','-c','import time;time.sleep(30)'],stdout=subprocess.PIPE,text=True)
    try:
        with pytest.raises(RuntimeError,match='timed out'):guard.read_reply(process,timeout=.05)
        assert process.poll() is not None
    finally:guard.stop_worker(process);process.stdout.close()

def test_oversized_response_stopped():
    process=subprocess.Popen([sys.executable,'-u','-c',"import time;print('x'*1000,flush=True);time.sleep(30)"],stdout=subprocess.PIPE,text=True)
    try:
        with pytest.raises(RuntimeError,match='memory limit'):guard.read_reply(process,timeout=5,max_chars=100)
        assert process.poll() is not None
    finally:guard.stop_worker(process);process.stdout.close()

def test_isolated_extraction_preserves_pages_and_source(tmp_path):
    path=tmp_path/'source.txt';data=b'The first page provides evidence.\fThe second page discusses limitations.';path.write_bytes(data)
    settings=Settings(isolate_extraction=True)
    pages,metadata=extract(data,path.name,settings,path)
    assert [tuple(p) for p in pages]==[(1,'The first page provides evidence.','1'),(2,'The second page discusses limitations.','2')]
    assert path.read_bytes()==data
    assert metadata['bibliography']

def test_invalid_parser_input_does_not_crash_parent(tmp_path):
    path=tmp_path/'broken.pdf';path.write_bytes(b'Invalid')
    with pytest.raises(ExtractionError):extract(path.read_bytes(),path.name,Settings(isolate_extraction=True),path)
    assert path.read_bytes()==b'Invalid'

def test_watchdog_stops_only_its_own_worker(monkeypatch):
    import psutil
    observed=[]
    monkeypatch.setattr(guard,'available_memory',lambda:SimpleNamespace(total=8*1024**3,available=2*1024**3))
    class Own:
        def __init__(self,pid):observed.append(pid)
        def nice(self,value):pass
        def memory_info(self):return SimpleNamespace(rss=4*1024**3)
    monkeypatch.setattr(psutil,'Process',Own)
    process=guard.spawn_worker([sys.executable,'-c','import time;time.sleep(30)'],os.environ.copy(),Settings(),'vector')
    try:
        process.wait(timeout=5)
        assert observed==[process.pid]
        assert process._nuance_failure.startswith('Operation stopped')
    finally:guard.stop_worker(process);process.stdin.close();process.stdout.close()
