from io import BytesIO
import zipfile
from reportlab.pdfgen.canvas import Canvas
from sqlalchemy import select
from nuance.db import Document,Chunk,Page
from nuance.extract import chunks
from nuance.retrieval import bm25
from conftest import headers,collection,upload,search

def test_auth_roles_and_header_spoof(client):
    assert client.get('/api/documents').status_code==401
    assert client.post('/api/collections',json={'name':'x'},headers=headers('b')).status_code==403
    cid=collection(client);upload(client,cid)
    r=client.get('/api/documents',headers={**headers('c'),'X-Tenant-ID':'alpha'})
    assert r.json()==[]
    assert client.get('/api/audit',headers=headers('b')).status_code==403

def test_tenant_isolation_all_source_paths(client):
    cid=collection(client,['*']);did=upload(client,cid)
    for route in ['/api/documents/'+did+'/source','/api/documents/'+did+'/pages/1']:
        assert client.get(route,headers=headers('c')).status_code==404
    assert not search(client,key='c').json()['results']
    assert client.put('/api/documents/'+did+'/acl',json={'readers':['*']},headers=headers('c')).status_code==404
    assert client.delete('/api/documents/'+did,headers=headers('c')).status_code==404

def test_collection_and_document_acl_intersection_and_revocation(client):
    cid=collection(client,['bob']);did=upload(client,cid)
    assert search(client,key='b').json()['results']==[]
    assert client.put(f'/api/documents/{did}/acl',json={'readers':['bob']},headers=headers()).status_code==200
    assert len(search(client,key='b').json()['results'])==1
    assert client.get(f'/api/documents/{did}/pages/1',headers=headers('b')).status_code==200
    assert client.put(f'/api/collections/{cid}/acl',json={'readers':[]},headers=headers()).status_code==200
    assert search(client,key='b').json()['results']==[]
    assert client.get(f'/api/documents/{did}/source',headers=headers('b')).status_code==404

def test_quotes_exact_offsets_pdf_pages_and_hash(client):
    out=BytesIO();pdf=Canvas(out);pdf.setTitle('Bibliography demo');pdf.setAuthor('Synthetic Author')
    pdf.drawString(72,720,'Page one: consent is necessary.');pdf.showPage();pdf.drawString(72,720,'Page two: autonomy needs safeguards.');pdf.save()
    cid=collection(client);did=upload(client,cid,out.getvalue(),'paper.pdf')
    result=search(client,'autonomy',mode='Quotes').json()['results'][0]
    assert result['page']==2 and result['document_id']==did
    page=client.get(result['citation_url'],headers=headers()).json()
    assert page['text'][result['span']['start']:result['span']['end']]==result['quote']
    assert len(result['source_sha256'])==64
    docs=client.get('/api/documents',headers=headers()).json()
    assert docs[0]['metadata']['authors']=='Synthetic Author'
    assert client.get(f'/api/documents/{did}/source',headers=headers()).content==out.getvalue()
    assert search(client,'nonexistent exact phrase',mode='Quotes').json()['results']==[]

def test_modes_and_explanations(client):
    cid=collection(client);upload(client,cid,'Autonomie améliore le contrôle.\fAutonomie ne suffit pas sans consentement.')
    for mode in ['Search','Quotes','Explore','Topics','Ask']:
        r=search(client,mode=mode);assert r.status_code==200
        assert r.json()['results']
    for mode in ['Standard','Exhaustive','Contradict','Explore','Strict Sources','Low Compute']:
        r=search(client,scientific_mode=mode);assert r.status_code==200
        if mode=='Low Compute':assert all(v['signals']['dense_cosine']['score'] is None for v in r.json()['results'])
        if mode=='Exhaustive':assert r.json()['coverage']['full_vector_traversal']
        if mode=='Contradict':assert r.json()['results'][0]['counterargument_marker']
    result=search(client,rerank=True).json()
    assert 'no local model' in result['warnings'][-1]
    assert 'probabilities of truth' in result['explanation']
    assert result['results'][0]['signals']['lexical_bm25']['score']>0
    assert search(client,mode='invalid').status_code==422
    assert search(client,limit=501).status_code==422
    assert client.post('/api/ask/generate',json={'query':'autonomy'},headers=headers()).status_code==503

def test_concept_taxonomy_and_cross_tenant_parent(client):
    cid=collection(client);did=upload(client,cid)
    c=client.post('/api/concepts',json={'name':'Agency','aliases':['autonomie']},headers=headers()).json()['id']
    assert client.put(f'/api/documents/{did}/concepts/{c}',headers=headers()).status_code==200
    result=search(client,concept_id=c).json()['results'][0]
    assert result['concepts']==['Agency']
    assert result['signals']['concept_manual']['score']==1
    assert client.post('/api/concepts',json={'name':'x','parent_id':c},headers=headers('c')).status_code==404
    assert search(client,concept_id=c,key='c').status_code==404

def test_delete_invalidates_cache_and_vectors(client):
    cid=collection(client);did=upload(client,cid)
    assert search(client).json()['results']
    assert client.delete(f'/api/documents/{did}',headers=headers()).status_code==200
    assert search(client).json()['results']==[]
    assert client.get(f'/api/documents/{did}/pages/1',headers=headers()).status_code==404
    assert client.app.state.vectors.client.count(client.app.state.vectors.name,exact=True).count==0

def test_failed_vector_ingestion_rolls_back(client,monkeypatch):
    cid=collection(client)
    def fail(*a,**kw):raise RuntimeError('simulated index outage')
    monkeypatch.setattr(client.app.state.vectors,'upsert',fail)
    r=client.post('/api/documents',data={'collection_id':cid},files={'file':('a.txt',b'Source text')},headers=headers())
    assert r.status_code==503
    assert client.get('/api/documents',headers=headers()).json()==[]
    with client.app.state.session() as s:
        assert list(s.scalars(select(Chunk)))==[]
        assert list(s.scalars(select(Page)))==[]

def test_bad_inputs_empty_pdf_docx_and_xss(client):
    cid=collection(client)
    for filename,data in [('x.pdf',b'fake'),('x.exe',b'bad'),('x.txt',b'')]:
        r=client.post('/api/documents',data={'collection_id':cid},files={'file':(filename,data)},headers=headers())
        assert r.status_code==422
    out=BytesIO();pdf=Canvas(out);pdf.showPage();pdf.save()
    r=client.post('/api/documents',data={'collection_id':cid},files={'file':('scan.pdf',out.getvalue())},headers=headers());assert r.status_code==422
    out=BytesIO()
    with zipfile.ZipFile(out,'w') as z:z.writestr('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Autonomie en DOCX.</w:t></w:r></w:p></w:body></w:document>')
    upload(client,cid,out.getvalue(),'paper.docx')
    assert search(client).json()['results'][0]['page_label']=='logical-1'
    upload(client,cid,'<script>alert(1)</script> autonomy','x.txt')
    assert client.get('/').headers['content-security-policy'].startswith("default-src 'self'")
    assert 'quote.textContent=result.quote' in client.get('/static/app.js').text

def test_no_scope_leak_exhaustive_and_legacy_cap_ignored(client):
    cid=collection(client);upload(client,cid)
    assert search(client,key='b',scientific_mode='Exhaustive').json()['coverage']['indexed_passages']==0
    client.app.state.settings.max_scope=0
    assert search(client).status_code==200

def test_chunk_and_bm25_contract():
    text='  A long sentence. '+('Une phrase. '*200)
    parts=list(chunks(text,90))
    assert ''.join(p[2] for p in parts)==text
    assert all(text[start:end]==chunk and len(chunk)<=90 for start,end,chunk in parts)
    scores=bm25('consent',['consent consent control','unrelated research'])
    assert scores[0]>scores[1]==0

def test_audit_has_no_query_or_source_text(client):
    cid=collection(client);upload(client,cid);search(client,'private sensitive request')
    r=client.get('/api/audit',headers=headers());assert r.status_code==200
    assert 'private sensitive request' not in r.text
    assert any(x['action']=='document.ingest' for x in r.json())
    assert client.get('/api/audit',headers=headers('c')).json()==[]
