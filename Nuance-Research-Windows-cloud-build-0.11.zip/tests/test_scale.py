"""Regression for libraries larger than the former 100k passage cap."""
import time
from sqlalchemy import insert, delete
from nuance.db import Document, Page, Chunk
from nuance.lexical import lexical_search, install_index
from conftest import collection, search

def test_2500_documents_125000_passages_indexed_search(client):
    cid=collection(client)
    sf=client.app.state.session
    fingerprint=client.app.state.searcher.embedder.fingerprint
    source='scaleprobe evidence and consent'
    with sf() as s:
        s.execute(insert(Document),[dict(id=f'd{i}',tenant='alpha',collection_id=cid,owner='alice',readers=[],filename=f'{i}.txt',title=f'Study {i}',metadata_json={},sha256=str(i),status='ready',provenance={'embedding_fingerprint':fingerprint}) for i in range(2500)])
        s.execute(insert(Page),[dict(id=f'p{i}',document_id=f'd{i}',number=1,text=source,label='1') for i in range(2500)])
        for batch in range(25):
            s.execute(insert(Chunk),[dict(id=f'c{i}-{j}',document_id=f'd{i}',page_id=f'p{i}',start=0,end=len(source),text=source,vector=[]) for i in range(batch*100,(batch+1)*100) for j in range(50)])
        s.commit()
    started=time.monotonic()
    r=search(client,query='scaleprobe',scientific_mode='Low Compute')
    elapsed=time.monotonic()-started
    assert r.status_code==200,r.text
    payload=r.json()
    assert payload['coverage']['authorized_documents']==2500
    assert payload['coverage']['indexed_passages']==125000
    assert payload['coverage']['loaded_passages']<=200
    assert payload['results'] and payload['results'][0]['quote']==source
    assert search(client,query='scaleprobe',key='b',scientific_mode='Low Compute').json()['results']==[]
    print(f'\n125000 passages / 2500 documents, cold lexical search: {elapsed:.3f}s')

def test_index_update_delete_and_restart_migration(client):
    from conftest import upload
    cid=collection(client);did=upload(client,cid,'rarelexicalmarker')
    sf=client.app.state.session
    with sf() as s:
        assert lexical_search(s,'rarelexicalmarker',[did],20)[0]
        s.execute(Chunk.__table__.update().where(Chunk.document_id==did).values(text='replacementmarker'));s.commit()
        assert not lexical_search(s,'rarelexicalmarker',[did],20)[0]
        assert lexical_search(s,'replacementmarker',[did],20)[0]
        engine=s.get_bind()
    with engine.begin() as c:
        c.exec_driver_sql('DELETE FROM chunk_fts')
    install_index(engine)
    with sf() as s:
        assert lexical_search(s,'replacementmarker',[did],20)[0]
        s.execute(delete(Chunk).where(Chunk.document_id==did));s.commit()
        assert not lexical_search(s,'replacementmarker',[did],20)[0]
