import json
import pytest
from conftest import headers,collection,upload
from nuance.metadata import infer_bibliography,names,parse_tei,normalize_doi

def test_header_excludes_abstract_and_references():
    result=infer_bibliography([(1,'Title: Autonomy and trust\nAuthors: Jane Doe and Jean de la Fontaine\nPublished: 12 mars 2024\nAbstract: We cite DOI 10.1234/other\nReferences\n10.1234/reference','1')])
    assert result['fields']['title']=='Autonomy and trust'
    assert result['fields']['date']=='2024-03-12'
    assert result['fields']['author'][1]['family']=='de la Fontaine'
    assert 'doi' not in result['fields']

def test_ambiguous_doi_and_received_date():
    result=infer_bibliography([(1,'Title: Evidence and uncertainty\nDOI: 10.1234/a\nDOI: 10.1234/b\nReceived 2021\nPublished: 2024\nAbstract\nbody','1')])
    assert 'doi' not in result['fields'] and len(result['alternatives']['doi'])==2
    assert result['fields']['year']==2024
    assert normalize_doi('https://doi.org/10.1234/x(y)).')=='10.1234/x(y)'

def test_font_title_overrides_filename():
    from pypdf import PdfWriter
    from reportlab.pdfgen.canvas import Canvas
    import io
    buffer=io.BytesIO();c=Canvas(buffer);c.setTitle('Microsoft Word - file.pdf');c.setAuthor('PDF Creator')
    c.setFont('Helvetica',22);c.drawString(40,740,'Autonomy and accountable systems')
    c.setFont('Helvetica',10);c.drawString(40,710,'Jane Doe and John Smith');c.drawString(40,690,'Published: 2024');c.drawString(40,670,'DOI: 10.1234/test');c.drawString(40,650,'Abstract');c.drawString(40,630,'This research studies accountable systems in detail.');c.save()
    from nuance.metadata import pdf_front
    pages,raw,fonts=pdf_front(buffer.getvalue());result=infer_bibliography(pages,'file.pdf',raw,fonts)
    assert result['fields']['title']=='Autonomy and accountable systems'
    assert result['fields']['author'][0]['family']=='Doe'
    assert result['fields']['doi']=='10.1234/test'

def test_tei_security_and_fields():
    data=b'<TEI xmlns="http://www.tei-c.org/ns/1.0"><teiHeader><fileDesc><sourceDesc><biblStruct><analytic><title>Trusted systems</title><author><persName><forename>Jane</forename><surname>Doe</surname></persName></author></analytic><monogr><title level="j">Research Journal</title><imprint><publisher>Example Press</publisher><date when="2024"/></imprint></monogr><idno type="DOI">10.1234/test</idno></biblStruct></sourceDesc></fileDesc></teiHeader></TEI>'
    result=parse_tei(data);assert result['title']=='Trusted systems' and result['author'][0]['family']=='Doe'
    with pytest.raises(ValueError):parse_tei(b'<!DOCTYPE TEI>'+data)

def import_ref(client,title='Example',doi='10.1234/test'):
    assert client.post('/api/research/import',json={'format':'csl-json','text':json.dumps([{'title':title,'DOI':doi}])},headers=headers()).status_code==200
    return client.get('/api/research/references',headers=headers()).json()[-1]

def test_crossref_explicit_safe_apply_and_undo(client,monkeypatch):
    ref=import_ref(client)
    monkeypatch.setattr('nuance.metadata.crossref_metadata',lambda doi:{'title':'Better title','doi':doi,'journal':'Research Journal','year':2024,'author':[{'family':'Doe','given':'Jane'}]})
    req={'reference_ids':[ref['id']],'mode':'crossref'}
    assert client.post('/api/research/metadata/analyze',json=req,headers=headers()).status_code==422
    req['online_consent']=True
    assert client.post('/api/research/metadata/analyze',json=req,headers=headers()).status_code==200
    path='/api/research/metadata/'+ref['id']
    applied=client.post(path+'/apply',json={'revision':ref['revision']},headers=headers()).json()
    assert 'title' not in applied['applied_fields'] and applied['reference']['title']=='Example'
    assert applied['reference']['journal']=='Research Journal'
    proposal=client.get(path,headers=headers()).json()
    assert proposal['base_revision']==applied['reference']['revision'] and proposal['result']['fields']['title']=='Better title'
    assert client.get(path,headers=headers('e')).status_code==404
    restored=client.post(path+'/undo',json={'revision':applied['reference']['revision']},headers=headers()).json()
    assert not restored.get('journal') and restored['title']=='Example'
    assert client.post(path+'/apply',json={'revision':ref['revision']},headers=headers()).status_code==409

def test_projects_union_empty_scope_and_owner_isolation(client,monkeypatch):
    cid=collection(client);upload(client,cid);client.post('/api/research/sync-documents',json={},headers=headers())
    first=client.get('/api/research/references',headers=headers()).json()[0];second=import_ref(client,'Other','10.1234/other')
    def project(name,ids):
        r=client.post('/api/research/projects',json={'name':name,'reference_ids':ids},headers=headers());assert r.status_code==200,r.text;return r.json()
    a=project('A',[first['id']]);b=project('B',[second['id']])
    assert len(client.get('/api/research/references',params={'project_ids':[a['id']]},headers=headers()).json())==1
    assert len(client.get('/api/research/export',params={'project_ids':[a['id'],b['id']]},headers=headers()).json())==2
    assert client.get('/api/research/projects',headers=headers('e')).json()==[]
    assert client.get('/api/research/references',params={'project_ids':[a['id']]},headers=headers('e')).status_code==404
    assert client.post('/api/research/suggest',json={'query':'autonomie','project_ids':[]},headers=headers()).json()['results']==[]
    assert client.post('/api/research/suggest',json={'query':'autonomie','project_ids':[b['id']]},headers=headers()).json()['results']==[]
    assert client.post('/api/research/suggest',json={'query':'autonomie','project_ids':[a['id']]},headers=headers()).json()['results']
    draft=client.put('/api/research/records/draft/project-draft',json={'revision':0,'payload':{'title':'Test','body':'Text','project_ids':[a['id'],b['id']]}},headers=headers())
    assert draft.status_code==200 and draft.json()['project_ids']==[a['id'],b['id']]
    assert client.put('/api/research/records/draft/invalid',json={'revision':0,'payload':{'body':'text','project_ids':['missing']}},headers=headers()).status_code==404
    assert client.put('/api/research/projects/'+a['id'],json={'name':'A','reference_ids':[],'revision':99},headers=headers()).status_code==409

def test_project_revoked_sources_disappear(client):
    cid=collection(client,['eve']);did=upload(client,cid);client.put('/api/documents/'+did+'/acl',json={'readers':['eve']},headers=headers())
    client.post('/api/research/sync-documents',json={},headers=headers('e'));ref=client.get('/api/research/references',headers=headers('e')).json()[0]
    p=client.post('/api/research/projects',json={'name':'Private','reference_ids':[ref['id']]},headers=headers('e')).json()
    client.put('/api/collections/'+cid+'/acl',json={'readers':[]},headers=headers())
    assert client.get('/api/research/references',params={'project_ids':[p['id']]},headers=headers('e')).json()==[]
    assert client.get('/api/research/projects',headers=headers('e')).json()[0]['visible_references']==0

def test_repeated_title_uses_largest_font_and_subtitle():
    text='PSYCHOLOGICAL PERSPECTIVES ON LEGITIMACY\nAND LEGITIMATION\nTom Tyler\nAbstract: body\n'
    r=infer_bibliography([(1,text,'1')],'article.pdf',{'title':'layout.xml'},[('PSYCHOLOGICAL PERSPECTIVES ON LEGITIMACY',20),('AND LEGITIMATION',14),('Tom Tyler',10),('PSYCHOLOGICAL PERSPECTIVES ON LEGITIMACY',8),('ordinary body text for median',10)])
    assert r['fields']['title']=='PSYCHOLOGICAL PERSPECTIVES ON LEGITIMACY AND LEGITIMATION'
    assert r['fields']['author'][0]['family']=='Tyler'
    assert r['evidence']['title']['level']=='heuristic'

def test_map_receives_project_union_only(client,monkeypatch):
    a=import_ref(client,'One','10.1234/one');b=import_ref(client,'Two','10.1234/two')
    p=client.post('/api/research/projects',json={'name':'One','reference_ids':[a['id']]},headers=headers()).json()
    def fake_map(*args,**kw):
        refs=next(arg for arg in args if isinstance(arg,list) and arg and isinstance(arg[0],dict) and 'title' in arg[0])
        return {'ids':[r['id'] for r in refs]}
    monkeypatch.setattr('nuance.research.topic_map',fake_map)
    r=client.post('/api/research/map',json={'project_ids':[p['id']]},headers=headers())
    assert r.status_code==200,r.text
    assert r.json()['ids']==[a['id']]

def test_crossref_wrong_document_does_not_autofill_doi(client,monkeypatch):
    cid=collection(client);upload(client,cid,text='Title: Trust and accountability\nDOI: 10.1234/wrong\nAbstract: Trust matters.')
    client.post('/api/research/sync-documents',json={},headers=headers());ref=client.get('/api/research/references',headers=headers()).json()[0]
    monkeypatch.setattr('nuance.metadata.crossref_metadata',lambda doi:{'title':'Unrelated biological mechanisms','doi':doi,'journal':'Wrong Journal'})
    r=client.post('/api/research/metadata/analyze',json={'reference_ids':[ref['id']],'mode':'crossref','online_consent':True},headers=headers())
    assert r.status_code==200
    assert r.json()['proposals'][0]['result']['evidence']['doi']['level']=='conflict'
    applied=client.post('/api/research/metadata/'+ref['id']+'/apply',json={'revision':ref['revision']},headers=headers()).json()
    assert 'doi' not in applied['applied_fields'] and 'journal' not in applied['applied_fields']

def test_batched_local_safe_completion_keeps_review(client):
    cid=collection(client)
    for n in range(2):upload(client,cid,text=f'Title: Explicit research title {n}\nPublished: 2024\nJournal: Research Journal\nAbstract: Discussion.',name=f'source{n}.txt')
    client.post('/api/research/sync-documents',json={},headers=headers())
    refs=client.get('/api/research/references',headers=headers()).json()
    response=client.post('/api/research/metadata/analyze',json={'reference_ids':[r['id'] for r in refs],'apply_safe':True},headers=headers())
    assert response.status_code==200,response.text
    assert len(response.json()['proposals'])==2
    assert all(p['applied_fields']==[] for p in response.json()['proposals'])
    assert all(p['reference']['year']==2024 for p in response.json()['proposals'])
