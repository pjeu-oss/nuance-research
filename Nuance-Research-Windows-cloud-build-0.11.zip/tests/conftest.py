import pytest
from fastapi.testclient import TestClient
from nuance.config import Settings
from nuance.main import create_app

KEYS={
 "a"*32:{"tenant":"alpha","user":"alice","role":"admin"},
 "b"*32:{"tenant":"alpha","user":"bob","role":"reader"},
 "c"*32:{"tenant":"beta","user":"alice","role":"admin"},
 "e"*32:{"tenant":"alpha","user":"eve","role":"editor"}}
@pytest.fixture
def client(tmp_path):
    settings=Settings(database_url="sqlite:///"+str(tmp_path/"db.sqlite"),data_dir=str(tmp_path),embedder="demo-hash",keys=KEYS)
    with TestClient(create_app(settings)) as c: yield c

def headers(key="a"): return {"Authorization":"Bearer "+key*32}
def collection(c,readers=None):
    r=c.post("/api/collections",json={"name":"Library","readers":readers or []},headers=headers());assert r.status_code==201,r.text
    return r.json()["id"]
def upload(c,cid,text="Autonomie et consentement. Les données restent locales.",name="test.txt",key="a"):
    r=c.post("/api/documents",data={"collection_id":cid},files={"file":(name,text.encode() if isinstance(text,str) else text)},headers=headers(key));assert r.status_code==201,r.text
    return r.json()["id"]
def search(c,query="autonomie",key="a",**kw):
    return c.post("/api/search",json={"query":query,**kw},headers=headers(key))
