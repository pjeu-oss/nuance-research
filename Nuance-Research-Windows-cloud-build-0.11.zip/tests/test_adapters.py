"""Contract tests for optional adapters; not neural quality benchmarks."""
from types import SimpleNamespace
from conftest import headers,collection,upload,search
from nuance.db import Document
from sqlalchemy import select
from qdrant_client import models as qm

def test_sparse_qdrant_real_local_filter(client):
    v=client.app.state.vectors
    v.client.create_collection('sparse_test',vectors_config={'dense':qm.VectorParams(size=2,distance=qm.Distance.COSINE)},sparse_vectors_config={'sparse':qm.SparseVectorParams()})
    from nuance.vector import VectorStore
    proxy=object.__new__(VectorStore);proxy.client=v.client;proxy.name='sparse_test';proxy.sparse=True
    for tenant,did,value in [('alpha','one',1.),('beta','two',10.)]:
        import uuid
        c=SimpleNamespace(id=str(uuid.uuid4()),vector=[1.,0.])
        proxy.upsert([c],tenant,did,[{7:value}])
    dense,sparse=proxy.search('alpha',['one'],[1.,0.],{7:2.},10)
    assert len(dense)==len(sparse)==1
    assert list(sparse.values())==[2.]

def test_configured_reranker_changes_order(client,monkeypatch):
    cid=collection(client);upload(client,cid,'autonomie autonomie');upload(client,cid,'autonomie rare')
    reranker=client.app.state.searcher.reranker
    reranker.model=object();reranker.manifest={'id':'test-only'}
    monkeypatch.setattr(reranker,'score',lambda q,texts:[0.,10.])
    r=search(client,rerank=True).json()['results']
    assert r[0]['reranker_score']==10. and r[1]['reranker_score']==0.

def test_stale_model_fingerprint_rejected(client):
    cid=collection(client);did=upload(client,cid)
    with client.app.state.session.begin() as s:
        d=s.get(Document,did);d.provenance={**d.provenance,'embedding_fingerprint':'old-model'}
    assert search(client).status_code==409

def test_invalid_llm_citations_rejected(client,monkeypatch):
    cid=collection(client);upload(client,cid)
    client.app.state.settings.llm_url='http://localhost:8080/v1'
    client.app.state.settings.llm_model='fake-local'
    class Response:
        def raise_for_status(self):pass
        def json(self):return {'choices':[{'message':{'content':'{"summary":"test", "citation_ids":["invented"]}'}}]}
    monkeypatch.setattr('httpx.post',lambda *a,**kw:Response())
    r=client.post('/api/ask/generate',json={'query':'autonomie'},headers=headers())
    assert r.status_code==502
