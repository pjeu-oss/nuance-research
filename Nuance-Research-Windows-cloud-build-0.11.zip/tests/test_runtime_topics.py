import json,time
from pathlib import Path
from nuance.config import Settings
from nuance.lazy_embedding import IdleEmbedder
from nuance.research import clean_topic_text,TOPIC_STOP_WORDS,topic_keywords
from conftest import headers

def test_topic_labels_filter_file_and_reader_noise():
    from sklearn.feature_extraction.text import TfidfVectorizer
    texts=[clean_topic_text('brain computer interfaces mental privacy https://example.org/x file.pdf viewer.js NIH downloaded'),clean_topic_text('brain computer interfaces mental privacy and neuroscience PDF JS viewer')]
    vectorizer=TfidfVectorizer(stop_words=TOPIC_STOP_WORDS,ngram_range=(1,2),token_pattern=r'(?u)\b[^\W\d_]{3,}\b').fit(texts)
    terms=vectorizer.get_feature_names_out()
    assert not any(term in {'pdf','js','viewer','nih','downloaded'} for term in terms)
    labels=topic_keywords(terms,vectorizer.transform(texts).mean(axis=0).A.ravel())
    assert any(' ' in label for label in labels)

def test_runtime_is_admin_only(client):
    assert client.get('/api/runtime').status_code==401
    assert client.get('/api/runtime',headers=headers('b')).status_code==403
    result=client.get('/api/runtime',headers=headers()).json()
    assert result['cpu_threads']==2 and result['cpu_seconds']>=0

def test_idle_worker_keeps_fingerprint_and_cached_query(tmp_path):
    settings=Settings(embedder='demo-hash',model_path=str(tmp_path));settings.model_idle_seconds=.15
    pooling=tmp_path/'1_Pooling';pooling.mkdir();(pooling/'config.json').write_text(json.dumps({'word_embedding_dimension':256}))
    model=IdleEmbedder(settings)
    try:
        vector,sparse=model.query('consent autonomy')
        assert len(vector)==256 and not sparse and model.status()['active']
        deadline=time.monotonic()+3
        while model.status()['active'] and time.monotonic()<deadline:time.sleep(.05)
        assert not model.status()['active']
        assert model.query('consent autonomy')[0]==vector
        assert not model.status()['active'] # Cached queries do not restart the model.
        assert len(model.encode(['another source'])[0][0])==256
        assert model.status()['active']
    finally:model.close()

def test_idle_qdrant_worker_upsert_filters_restart_delete(tmp_path):
    from types import SimpleNamespace
    from nuance.models import Embedder
    from nuance.lazy_vector import IdleVectorStore
    from nuance.db import uid
    settings=Settings(embedder='demo-hash',data_dir=str(tmp_path));settings.model_idle_seconds=.15
    embedder=Embedder(settings);store=IdleVectorStore(settings,embedder)
    vector,sparse=embedder.query('consent autonomy');cid=uid()
    try:
        assert store.search('alpha',[],vector,sparse,10)==({}, {}) and not store.status()['active']
        store.upsert([SimpleNamespace(id=cid,vector=vector)],'alpha','doc-a',[sparse])
        assert cid in store.search('alpha',['doc-a'],vector,sparse,10)[0]
        assert store.search('beta',['doc-a'],vector,sparse,10)[0]=={}
        assert store.search('alpha',['private-other'],vector,sparse,10)[0]=={}
        deadline=time.monotonic()+3
        while store.status()['active'] and time.monotonic()<deadline:time.sleep(.05)
        assert not store.status()['active']
        assert cid in store.search('alpha',['doc-a'],vector,sparse,10)[0]
        store.delete('alpha','doc-a')
        assert store.search('alpha',['doc-a'],vector,sparse,10)[0]=={}
    finally:store.close()

def test_library_search_excludes_archived_and_intersects_acl(client):
    from conftest import collection,upload
    cid=collection(client);did=upload(client,cid,'private bibliography consent')
    client.post('/api/research/sync-documents',json={},headers=headers())
    query={'query':'consent','scientific_mode':'Low Compute'}
    assert client.post('/api/research/search',json=query,headers=headers()).json()['results']
    assert not client.post('/api/search',json={**query,'document_ids':[did]},headers=headers('b')).json()['results']
    ref=client.get('/api/research/references',headers=headers()).json()[0]
    client.post('/api/research/references/'+ref['id']+'/archive',json={'revision':ref['revision'],'payload':{}},headers=headers())
    assert not client.post('/api/research/search',json=query,headers=headers()).json()['results']
    assert client.post('/api/search',json=query,headers=headers()).json()['results'] # Historical sources remain accessible.
