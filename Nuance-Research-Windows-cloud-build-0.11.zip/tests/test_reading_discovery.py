import io,json,zipfile
import pytest
from sqlalchemy import select
from conftest import headers,collection,upload
from nuance.reading import locate_quote
from nuance.discovery import public_url,Vault
from nuance.db import ResearchRecord

def reference(c,text='Autonomie et consentement. Les données restent locales.'):
    cid=collection(c);did=upload(c,cid,text=text);c.post('/api/research/sync-documents',json={},headers=headers())
    ref=next(r for r in c.get('/api/research/references',headers=headers()).json() if r['document_id']==did)
    return ref,c.get('/api/documents/'+did+'/pages/1',headers=headers()).json()
def highlight(c,ref,page,**kw):
    return c.post('/api/research/citations',json={'reference_id':ref['id'],'page':1,'source_sha256':page['sha256'],'quote':page['text'][:25],**kw},headers=headers())
def test_highlight_exact_version_and_dedup(client):
    ref,page=reference(client);r=highlight(client,ref,page);assert r.status_code==200,r.text
    citation=r.json();assert citation['quote']==page['text'][citation['start']:citation['end']] and citation['folder']=='citations'
    assert highlight(client,ref,page).json()['id']==citation['id']
    assert highlight(client,ref,page,quote='Fabricated text').status_code==422
    assert highlight(client,ref,page,source_sha256='0'*64).status_code==409
    assert highlight(client,ref,page,quote=page['text'][:25],start=1,end=26).status_code==422
    reader=client.get('/api/research/reader/'+ref['id'],headers=headers()).json()
    assert reader['highlights'][0]['id']==citation['id'] and reader['pages']==[1]

def test_normalization_ambiguity_and_unicode():
    assert locate_quote('The ﬁnal re-\nsearch question.','The final research question.')[0:2]==(0,29)
    with pytest.raises(Exception):locate_quote('same same','same')
    assert locate_quote('😀 same same','same',2,6)==(2,6,'exact-text')

def test_annotations_private_revocable_restorable(client):
    ref,page=reference(client);q=highlight(client,ref,page).json();path='/api/research/citations/'+q['id']
    assert client.get('/api/research/citations',headers=headers('e')).json()==[]
    assert client.get('/api/research/reader/'+ref['id'],headers=headers('e')).status_code==404
    assert client.put(path,json={'revision':q['revision'],'note':'private'},headers=headers('e')).status_code==404
    updated=client.put(path,json={'revision':q['revision'],'note':'My note','color':'blue'},headers=headers()).json()
    assert updated['note']=='My note'
    assert client.put(path,json={'revision':q['revision'],'note':'stale'},headers=headers()).status_code==409
    archived=client.post(path+'/archive',json={'revision':updated['revision']},headers=headers()).json()
    assert client.get('/api/research/citations',headers=headers()).json()==[]
    restored=client.post(path+'/restore',json={'revision':archived['revision']},headers=headers());assert restored.status_code==200
    client.post('/api/research/references/'+ref['id']+'/archive',json={'revision':ref['revision'],'payload':{}},headers=headers())
    assert client.get('/api/research/citations',headers=headers()).json()[0]['quote']==q['quote']

def test_quote_zip_and_project_scope(client):
    ref,page=reference(client);q=highlight(client,ref,page).json()
    p=client.post('/api/research/projects',json={'name':'Reading','reference_ids':[ref['id']]},headers=headers()).json()
    r=client.get('/api/research/citations-export.zip',params={'project_ids':[p['id']]},headers=headers());assert r.status_code==200
    z=zipfile.ZipFile(io.BytesIO(r.content));assert 'citations/'+q['id']+'.json' in z.namelist()
    assert json.loads(z.read('citations/'+q['id']+'.json'))['source_sha256']==page['sha256']
    assert client.get('/api/research/citations',params={'project_ids':['foreign']},headers=headers()).status_code==404

def watch_payload(**kw):return {'name':'Trust','query':'trusted systems','online_consent':True,**kw}
def fake_crossref(config):return ([{'external_id':'10.1234/trust','provider':'crossref','reference':{'title':'Trusted systems','doi':'10.1234/trust','year':2024,'type':'article-journal','journal':'Research Journal'},'source_url':'https://doi.org/10.1234/trust'}],{'more_available':False})
def test_discovery_consent_dedup_project_add(client,monkeypatch):
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    assert client.post('/api/research/watches',json=watch_payload(online_consent=False),headers=headers()).status_code==422
    p=client.post('/api/research/projects',json={'name':'New readings','reference_ids':[]},headers=headers()).json()
    w=client.post('/api/research/watches',json=watch_payload(project_ids=[p['id']]),headers=headers()).json()
    assert client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers()).json()['new']==1
    assert client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers()).json()['new']==0
    item=client.get('/api/research/discovery',headers=headers()).json()[0]
    added=client.post('/api/research/discovery/'+item['id']+'/add',json={'project_ids':[p['id']]},headers=headers()).json()
    assert added['full_text_imported'] is False
    refs=client.get('/api/research/references',params={'project_ids':[p['id']]},headers=headers()).json();assert len(refs)==1 and refs[0]['doi']=='10.1234/trust'
    client.post('/api/research/discovery/'+item['id']+'/add',json={'project_ids':[p['id']]},headers=headers())
    assert len(client.get('/api/research/references',headers=headers()).json())==1
    assert client.get('/api/research/watches',headers=headers('e')).json()==[]
    assert client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers('e')).status_code==404
    assert client.post('/api/research/discovery/'+item['id']+'/add',json={},headers=headers('e')).status_code==404

def test_auto_add_is_opt_in_and_unknown_project_rejected(client,monkeypatch):
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    assert client.post('/api/research/watches',json=watch_payload(project_ids=['unknown']),headers=headers()).status_code==404
    w=client.post('/api/research/watches',json=watch_payload(auto_add_metadata=True),headers=headers()).json()
    assert client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers()).json()['added']==1
    assert client.get('/api/research/references',headers=headers()).json()[0]['read_status']=='to-read'
    assert client.post('/api/research/watches',json=watch_payload(interval_hours=1),headers=headers()).status_code==422

def test_zotero_key_encrypted_not_returned_and_private(client,monkeypatch):
    key='test-read-only-api-key-123456789';calls=[]
    def fake(url,params=None,headers=None):
        calls.append((url,params,headers));return ([{'key':'ABCDEFGH','data':{'title':'Trust and science','itemType':'journalArticle','DOI':'10.1234/a','creators':[{'creatorType':'author','lastName':'Doe','firstName':'Jane'}]}}],{'last-modified-version':'42'})
    monkeypatch.setattr('nuance.discovery.fetch_json',fake)
    connection=client.post('/api/research/connections',json={'provider':'zotero','name':'My library','library_id':'12345','api_key':key},headers=headers());assert connection.status_code==200,connection.text
    c=connection.json();assert c['key_saved'] and key not in connection.text
    with client.app.state.session() as s:
        record=s.get(ResearchRecord,c['id']);assert key not in json.dumps(record.payload) and record.payload.get('encrypted_key')
    assert client.get('/api/research/connections',headers=headers('e')).json()==[]
    w=client.post('/api/research/watches',json=watch_payload(provider='zotero',connection_id=c['id']),headers=headers()).json()
    r=client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers());assert r.status_code==200,r.text
    assert calls[-1][2]['Zotero-API-Key']==key and key not in calls[-1][0]
    assert client.get('/api/research/watches',headers=headers()).json()[0]['sync_since']==42
    assert client.post('/api/research/connections/'+c['id']+'/disconnect',json={},headers=headers('e')).status_code==404
    assert client.post('/api/research/connections/'+c['id']+'/disconnect',json={},headers=headers()).status_code==200
    assert client.get('/api/research/connections',headers=headers()).json()==[]

def test_institutional_portal_and_outbound_safety(client):
    assert public_url('https://localhost/a')=='' and public_url('https://127.0.0.1/a')==''
    assert public_url('javascript:alert(1)')=='' and public_url('https://user:pass@example.org')==''
    assert client.post('/api/research/connections',json={'provider':'institution','name':'Uni','portal_url':'https://library.example.org'},headers=headers()).status_code==200
    assert client.post('/api/research/connections',json={'provider':'institution','name':'Uni','portal_url':'http://localhost'},headers=headers()).status_code==422

def test_vault_authenticated_owner_bound(tmp_path):
    vault=Vault(tmp_path);cipher=vault.seal('private key','alice')
    assert vault.open(cipher,'alice')=='private key'
    with pytest.raises(Exception):vault.open(cipher,'eve')
    changed=cipher[:-4]+'AAAA'
    with pytest.raises(Exception):vault.open(changed,'alice')

def test_library_search_never_widens_empty_project_scope(client):
    reference(client)
    r=client.post('/api/research/search',json={'query':'autonomie','project_ids':[]},headers=headers())
    assert r.status_code==200 and r.json()['results']==[]


def test_citation_access_revoked_with_source_acl(client):
    cid=collection(client,['eve']);did=upload(client,cid)
    client.put('/api/documents/'+did+'/acl',json={'readers':['eve']},headers=headers())
    client.post('/api/research/sync-documents',json={},headers=headers('e'))
    ref=next(r for r in client.get('/api/research/references',headers=headers('e')).json() if r['document_id']==did)
    page=client.get('/api/documents/'+did+'/pages/1',headers=headers('e')).json()
    quote=client.post('/api/research/citations',json={'reference_id':ref['id'],'page':1,'source_sha256':page['sha256'],'quote':page['text'][:25]},headers=headers('e'))
    assert quote.status_code==200,quote.text
    client.put('/api/collections/'+cid+'/acl',json={'readers':[]},headers=headers())
    assert client.get('/api/research/reader/'+ref['id'],headers=headers('e')).status_code==404
    assert client.get('/api/research/citations',headers=headers('e')).json()==[]
    exported=client.get('/api/research/citations-export.zip',headers=headers('e'))
    assert zipfile.ZipFile(io.BytesIO(exported.content)).namelist()==[]


def test_scheduler_only_runs_explicit_opt_in(client):
    from nuance.discovery import Scheduler
    active=client.post('/api/research/watches',json=watch_payload(automatic=True),headers=headers()).json()
    client.post('/api/research/watches',json=watch_payload(name='Manual',automatic=False),headers=headers())
    called=[]
    scheduler=Scheduler(client.app.state.settings,client.app.state.session,lambda wid,identity:called.append(wid))
    class OneTick:
        ticks=0
        def wait(self,seconds):self.ticks+=1;return self.ticks>1
        def is_set(self):return False
    scheduler.stop_event=OneTick();scheduler.loop()
    assert called==[active['id']]

def test_auto_add_existing_proposal_after_opt_in(client,monkeypatch):
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    watch=client.post('/api/research/watches',json=watch_payload(),headers=headers()).json()
    client.post('/api/research/watches/'+watch['id']+'/check',json={},headers=headers())
    assert client.get('/api/research/references',headers=headers()).json()==[]
    updated=client.put('/api/research/watches/'+watch['id'],json=watch_payload(auto_add_metadata=True,revision=watch['revision']),headers=headers())
    assert updated.status_code==200
    assert client.post('/api/research/watches/'+watch['id']+'/check',json={},headers=headers()).json()['added']==1
