import pytest
from conftest import headers
from nuance.watch_relevance import rank,plans
from test_reading_discovery import watch_payload,fake_crossref

def candidate(title,abstract='',doi='10.1234/topic'):
    return {'external_id':doi,'provider':'crossref','source_url':'https://doi.org/'+doi,'reference':{'title':title,'abstract':abstract,'doi':doi,'type':'article-journal'}}
def test_neurotechnology_law_bilingual_and_topic_gate():
    items=[candidate('Neurotechnology and legal rights'),candidate('Tax law and trade'),candidate('Neurotechnology signal processing'),candidate('Droit des neurotechnologies'),candidate('Corporate marketing','',doi='10.1234/other')]
    ranked,info=rank(items,watch_payload(query='Droit des neurotechnologies',semantic_rerank=False))
    assert [i['reference']['title'] for i in ranked]==['Neurotechnology and legal rights','Droit des neurotechnologies']
    assert info['excluded']==3 and info['queries']==['neurotechnology law']
    assert len(ranked[0]['relevance']['topics'][0]['matches'])==2

def test_topic_union_intersection_and_irrelevant_author_journal():
    items=[candidate('Brain-computer interfaces for communication'),candidate('Personal data protection and privacy'),candidate('Brain-computer interfaces and personal data protection and privacy'),candidate('Commerce marketing')]
    config=watch_payload(topics=['brain computer · computer interfaces · bci','vie privée · protection données'],semantic_rerank=False)
    assert len(rank(items,config)[0])==3
    assert [i['reference']['title'] for i in rank(items,{**config,'topic_mode':'all'})[0]]==['Brain-computer interfaces and personal data protection and privacy']
    assert not rank([{'reference':{'title':'Unrelated research','journal':'Neurotechnology law','author':[{'family':'Neurotechnology'}]}}],watch_payload(query='neurotechnology law'))[0]

def test_local_semantic_reranking_cannot_admit_off_topic():
    class Semantic:
        manifest={'semantic':True,'model':'test-model'}
        def encode(self,texts,query=False):return [[1,0] for t in texts],[]
    rows,_=rank([candidate('Neurotechnology and law'),candidate('Fashion marketing')],watch_payload(query='neurotechnology law'),Semantic())
    assert len(rows)==1 and rows[0]['relevance']['semantic_score']==1

def test_crossref_sorts_relevance_and_topics_separately(monkeypatch):
    from nuance.discovery import crossref_search
    calls=[]
    def fetch(url,params=None,headers=None):
        calls.append(params);return {'message':{'items':[]}},{}
    monkeypatch.setattr('nuance.discovery.fetch_json',fetch)
    crossref_search(watch_payload(topics=['neurotechnology law','political legitimacy'],since='2025-01-01'))
    assert len(calls)==2 and all(c['sort']=='score' and c['rows']==80 for c in calls)
    assert all('until-pub-date:' in c['filter'] for c in calls)
    assert calls[0]['query.bibliographic']!=calls[1]['query.bibliographic']

def test_reset_is_reversible_private_and_preserves_bibliography(client,monkeypatch):
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    w=client.post('/api/research/watches',json=watch_payload(),headers=headers()).json();wid=w['id']
    client.post('/api/research/watches/'+wid+'/check',json={},headers=headers())
    item=client.get('/api/research/discovery',params={'watch_id':wid},headers=headers()).json()[0]
    client.post('/api/research/discovery/'+item['id']+'/add',json={},headers=headers())
    assert client.post('/api/research/watches/'+wid+'/reset',json={'revision':w['revision']},headers=headers('e')).status_code==404
    reset=client.post('/api/research/watches/'+wid+'/reset',json={'revision':w['revision']},headers=headers());assert reset.status_code==200,reset.text
    data=reset.json();assert data['cleared']==1
    assert client.get('/api/research/discovery',params={'watch_id':wid},headers=headers()).json()==[]
    assert len(client.get('/api/research/references',headers=headers()).json())==1
    assert client.post('/api/research/watches/'+wid+'/reset',json={'revision':w['revision']},headers=headers()).status_code==409
    restore=client.post('/api/research/watch-resets/'+data['reset_id']+'/restore',json={'revision':data['watch']['revision']},headers=headers());assert restore.status_code==200,restore.text
    assert len(client.get('/api/research/discovery',params={'watch_id':wid},headers=headers()).json())==1

def test_reset_one_watch_does_not_clear_other_and_recheck_repopulates(client,monkeypatch):
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    watches=[client.post('/api/research/watches',json=watch_payload(name=name),headers=headers()).json() for name in ['A','B']]
    for w in watches:client.post('/api/research/watches/'+w['id']+'/check',json={},headers=headers())
    a,b=watches
    client.post('/api/research/watches/'+a['id']+'/reset',json={'revision':a['revision']},headers=headers())
    assert len(client.get('/api/research/discovery',params={'watch_id':b['id']},headers=headers()).json())==1
    client.post('/api/research/watches/'+a['id']+'/check',json={},headers=headers())
    assert len(client.get('/api/research/discovery',params={'watch_id':a['id']},headers=headers()).json())==1

def test_legacy_inbox_filters_noise_before_reset(client,monkeypatch):
    from nuance.db import ResearchRecord
    monkeypatch.setattr('nuance.discovery.crossref_search',fake_crossref)
    w=client.post('/api/research/watches',json=watch_payload(),headers=headers()).json()
    with client.app.state.session.begin() as s:
        s.add(ResearchRecord(tenant='alpha',owner='alice',kind='discovery-item',payload={**candidate('Totally unrelated marketing'),'query':'old','watch_ids':[w['id']],'status':'new','discovered_at':'2026-01-01T00:00:00+00:00'}))
    assert client.get('/api/research/discovery',params={'watch_id':w['id']},headers=headers()).json()==[]


def test_specialist_venue_context_needs_two_text_concepts_and_excludes_book_reviews():
    eligible=candidate('Vietnam’s pursuit of political legitimacy');eligible['reference']['journal']='International Relations of the Asia-Pacific'
    unrelated=candidate('Crisis communication and political legitimacy');unrelated['reference']['journal']='Natural Sciences'
    review=candidate('Book Review: International Relations and Political Legitimacy')
    rows,_=rank([eligible,unrelated,review],watch_payload(query='international relations political legitimacy',semantic_rerank=False))
    assert len(rows)==1 and rows[0]['relevance']['topics'][0]['matches'][-1]['field']=='journal'
