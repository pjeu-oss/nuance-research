import json,io,zipfile
from conftest import headers,collection,upload
from nuance.research import find_duplicates,export_bibtex,topic_map

def import_refs(c):
    r=c.post('/api/research/import',json={'format':'csl-json','text':json.dumps([{'title':'Ethics of neuroscience research','DOI':'10.1/test','year':2024},{'title':'Data protection in research','year':2023}])},headers=headers())
    assert r.status_code==200
    return c.get('/api/research/references',headers=headers()).json()

def test_archive_restore_private_and_sync_does_not_resurrect(client):
    cid=collection(client);upload(client,cid)
    client.post('/api/research/sync-documents',json={},headers=headers())
    r=client.get('/api/research/references',headers=headers()).json()[0];path='/api/research/references/'+r['id']
    assert client.post(path+'/archive',json={'revision':r['revision'],'payload':{}},headers=headers('e')).status_code==404
    assert client.post(path+'/archive',json={'revision':r['revision'],'payload':{}},headers=headers()).status_code==200
    assert client.get('/api/research/references',headers=headers()).json()==[]
    assert client.post('/api/research/sync-documents',json={},headers=headers()).json()['linked_or_created']==0
    assert client.get('/api/research/trash',headers=headers('e')).json()==[]
    trash=client.get('/api/research/trash',headers=headers()).json()[0]
    assert client.post(path+'/restore',json={'revision':trash['revision'],'payload':{}},headers=headers()).status_code==200
    assert len(client.get('/api/research/references',headers=headers()).json())==1

def test_bibtex_export_excludes_archived_and_other_users(client):
    refs=import_refs(client)
    r=client.get('/api/research/export.bib',headers=headers())
    assert r.status_code==200 and '@misc{' in r.text and '10.1/test' in r.text
    assert 'Ethics' not in client.get('/api/research/export.bib',headers=headers('e')).text
    client.post('/api/research/references/'+refs[0]['id']+'/archive',json={'revision':refs[0]['revision'],'payload':{}},headers=headers())
    assert 'Ethics' not in client.get('/api/research/export.bib',headers=headers()).text

def test_bibtex_tex_escaping_and_unique_keys():
    values=[{'id':str(i),'title':'A {B} & 50% _ # $ \\','authors':['Doe, Jane','Smith, John'],'year':2024,'journal':'Review'} for i in range(2)]
    text=export_bibtex(values)
    assert '@article{ref0,' in text and '@article{ref1,' in text
    assert r'\&' in text and r'\%' in text and r'\textbackslash{}' in text
    assert 'Doe, Jane and Smith, John' in text

def test_duplicate_signals_no_merge():
    refs=[{'id':'a','title':'Ethical principles for brain research','year':2024,'doi':'10.1/x','document_id':'d1'},
          {'id':'b','title':'Ethical principles for brain research','year':2024,'doi':'10.1/x','document_id':'d2'},
          {'id':'c','title':'Ethical principle for brain research','year':2024,'doi':'','document_id':None}]
    result=find_duplicates(refs,{'d1':'sha','d2':'sha'})
    assert any(set(g['ids'])=={'a','b'} for g in result['groups'])
    assert any(g['reason']=='similar_title' for g in result['groups'])
    assert len(refs)==3

def test_public_distribution_excludes_secrets_and_db(client):
    for path in ['/install','/manifest.webmanifest','/service-worker.js']:
        assert client.get(path).status_code==200
    result=client.get('/distribution/source.zip');assert result.status_code==200
    with zipfile.ZipFile(io.BytesIO(result.content)) as z:
        names=z.namelist();assert any(n.endswith('research.py') for n in names)
        assert not any(n.endswith(('.db','.sqlite','.env')) or 'user-data' in n or 'credentials' in n for n in names)

def test_private_map_and_no_hash_semantics(client):
    assert client.post('/api/research/map',json={}).status_code==401
    assert client.post('/api/research/map',json={},headers=headers()).status_code==409

def test_map_whole_metadata_library_coverage_and_article():
    class Embedder:
        manifest={'semantic':True,'id':'explicit-test-stub'};fingerprint='test'
        def encode(self,texts):
            return ([[1,0,0] if 'brain' in t else [0,1,0] for t in texts],[{} for _ in texts])
    refs=[{'id':str(i),'title':'brain ethics' if i<3 else 'climate policy','abstract':'','document_id':None,'year':2024} for i in range(5)]
    result=topic_map(refs,[],None,Embedder(),'brain research',2)
    assert result['coverage']['represented']==5
    assert sum(n['count'] for n in result['nodes'])==5
    assert any(n['article_similarity']==1 for n in result['nodes'])
    assert result['distances'][0]['cosine_distance']==1
    assert result['method']['projection'].startswith('PCA')
