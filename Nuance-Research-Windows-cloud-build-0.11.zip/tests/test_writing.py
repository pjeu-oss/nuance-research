import io,zipfile
import pytest
from docx import Document
from nuance.writing import validate_editor,validate_payload,import_document,export_docx,plain_document
from nuance.bibliography import format_reference,reference_to_csl
from nuance.research import clean_reference,parse_references
from conftest import headers,collection,upload

def test_rich_docx_roundtrip(tmp_path):
    rich={'type':'doc','content':[{'type':'heading','attrs':{'level':2},'content':[{'type':'text','text':'Methods'}]},{'type':'paragraph','attrs':{'textAlign':'justify'},'content':[{'type':'text','text':'An exact sentence.','marks':[{'type':'bold'},{'type':'textStyle','attrs':{'fontFamily':'Georgia','fontSize':'14pt','color':'#335544'}}]},{'type':'citationMarker','attrs':{'footnoteId':'note1','label':'1','status':'note'}}]},{'type':'table','content':[{'type':'tableRow','content':[{'type':'tableCell','content':[{'type':'paragraph','content':[{'type':'text','text':'Study'}]}]}]}]}]}
    payload=validate_payload({'title':'Article','editor_json':rich,'footnotes':[{'id':'note1','text':'Doe (2024).'}],'layout':{'orientation':'landscape','margins':'compact'},'bibliography':['Doe (2024). Test.']})
    data=export_docx(payload)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert b'footnoteReference' in z.read('word/document.xml')
        assert b'Doe (2024).' in z.read('word/footnotes.xml')
    from nuance.config import Settings
    result=import_document(data,'Article.docx',Settings())
    assert 'An exact sentence.' in result['body'] and 'Study' in result['body']
    assert result['footnotes'][0]['text'].strip()=='Doe (2024).'
    paragraph=next(n for n in result['editor_json']['content'] if n['type']=='paragraph' and n.get('content',[{}])[0].get('text')=='An exact sentence.')
    assert {'type':'bold'} in paragraph['content'][0]['marks']
    assert any(n['type']=='table' for n in result['editor_json']['content'])

def test_editor_rejects_unsafe_or_unbounded():
    with pytest.raises(ValueError):validate_editor({'type':'iframe'})
    with pytest.raises(ValueError):validate_editor(plain_document('x'*200001))
    node=validate_editor({'type':'text','text':'Link','marks':[{'type':'link','attrs':{'href':'javascript:alert(1)'}},{'type':'textStyle','attrs':{'fontFamily':'url(evil)','color':'red','fontSize':'10000px'}}]})
    assert all(m['type']!='link' for m in node.get('marks',[]))
    assert node['marks'][0]['attrs']=={}
    with pytest.raises(ValueError):validate_payload({'footnotes':[{'id':'n'},{'id':'n'}]})

def test_typed_metadata_and_csl_styles():
    ref=clean_reference({'title':'A study','type':'article-journal','author':[{'family':'Doe','given':'Jane'}],'issued':{'date-parts':[[2024,3,2]]},'container-title':'Science Journal','publisher':'Publisher','volume':'5','issue':'2','page':'11-21'})
    ref['id']='ref-one';csl=reference_to_csl(ref)
    assert csl['author']==[{'family':'Doe','given':'Jane'}] and csl['issued']['date-parts']==[[2024,3,2]]
    assert csl['page']=='11-21' and csl['container-title']=='Science Journal'
    apa=format_reference(ref,'apa','inline',7)
    assert 'Doe' in apa['citation'] and '2024' in apa['citation'] and '7' in apa['citation']
    assert 'Science Journal' in apa['bibliography'] and '11' in apa['bibliography']
    chicago=format_reference(ref,'chicago','footnote',7)
    assert 'a study' in chicago['citation'].lower() and '7' in chicago['citation']
    legislation=clean_reference({'title':'Law','type':'legislation','authority':'Parliament','jurisdiction':'France','number':'42','date':'2024-01-01'})
    assert reference_to_csl(legislation)['author']==[{'literal':'Parliament'}]
    ris=parse_references('ris','TY  - BOOK\nTI  - Book\nPB  - Press\nVL  - 2\nER  - \n')[0]
    assert ris['type']=='book' and ris['publisher']=='Press'

def test_writing_routes_private_import_and_source_acl(client):
    file=Document();file.add_paragraph('Imported text');buf=io.BytesIO();file.save(buf)
    r=client.post('/api/research/writing/import',files={'file':('test.docx',buf.getvalue())},headers=headers())
    assert r.status_code==200 and 'Imported text' in r.json()['body']
    assert client.get('/api/research/drafts',headers=headers()).json()==[]
    assert client.post('/api/research/writing/import',files={'file':('test.docx',buf.getvalue())},headers=headers('b')).status_code==403
    assert client.post('/api/research/writing/import',files={'file':('bad.docx',b'bad')},headers=headers()).status_code==422
    cid=collection(client);upload(client,cid);client.post('/api/research/sync-documents',headers=headers())
    source=client.post('/api/research/suggest',json={'query':'autonomie'},headers=headers()).json()['results'][0]
    data={'reference_id':source['reference']['id'],'chunk_id':source['chunk_id'],'style':'apa'}
    assert client.post('/api/research/citation/format',json=data,headers=headers()).status_code==200
    for key in ['b','c','e']:assert client.post('/api/research/citation/format',json=data,headers=headers(key)).status_code==404
    payload={'title':'Draft','editor_json':plain_document('A sentence'),'citations':[source]}
    assert client.put('/api/research/records/draft/new-draft',json={'revision':0,'payload':payload},headers=headers()).status_code==200
    assert client.get('/api/research/records/draft/new-draft',headers=headers('e')).status_code==404
    assert 'editor_json' not in client.get('/api/research/drafts',headers=headers()).json()[0]
    source['quote']='Fabricated'
    assert client.post('/api/research/writing/export.docx',json={'revision':0,'payload':payload},headers=headers()).status_code==422
