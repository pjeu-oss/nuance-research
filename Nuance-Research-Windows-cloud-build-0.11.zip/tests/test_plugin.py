from conftest import headers,collection,search

def sync(c,cid,external='a1',kind='article',text='Autonomie et consentement.',readers=None,parent=None,key='a',title='Autonomie'):
    data={'collection_id':cid,'external_id':external,'kind':kind,'title':title,'text':text}
    if readers is not None:data['readers']=readers
    if parent:data['parent_external_id']=parent
    return c.post('/api/content',json=data,headers=headers(key))

def test_sync_is_idempotent_and_preserves_one_active_version(client):
    cid=collection(client,['*'])
    first=sync(client,cid,readers=['bob']);assert first.status_code==200,first.text
    did=first.json()['document_id']
    again=sync(client,cid);assert again.json()=={'document_id':did,'external_id':'a1','kind':'article','changed':False}
    assert len(client.get('/api/documents',headers=headers()).json())==1
    updated=sync(client,cid,text='Autonomie révisée avec nouvelles preuves.')
    assert updated.status_code==200 and updated.json()['previous_document_id']==did
    current=updated.json()['document_id'];assert current!=did
    assert len(client.get('/api/documents',headers=headers()).json())==1
    assert search(client,key='b').json()['results'][0]['document_id']==current
    assert client.get('/api/documents/'+did+'/pages/1',headers=headers('b')).status_code==404

def test_reader_cannot_sync_and_tenant_cannot_manage(client):
    cid=collection(client,['*'])
    assert sync(client,cid,key='b').status_code==403
    assert sync(client,cid,key='c').status_code==404
    assert sync(client,cid,kind='comment').status_code==422
    assert sync(client,cid,kind='comment',parent='missing').status_code==404
    r=sync(client,cid,external='../evil');assert r.status_code==422

def test_comments_rank_one_result_per_comment_and_parent_scope(client):
    cid=collection(client,['*'])
    sync(client,cid,readers=['*'])
    sync(client,cid,external='a2',title='Climat',readers=['*'])
    c1=sync(client,cid,external='c1',kind='comment',text='Le consentement soutient l autonomie. '+('Une explication est utile. '*70),parent='a1',readers=['*']).json()['document_id']
    sync(client,cid,external='c2',kind='comment',text='Autonomie et consentement nécessitent un contrôle.',parent='a1',readers=['*'])
    sync(client,cid,external='private',kind='comment',text='Autonomie confidentielle.',parent='a1')
    sync(client,cid,external='other',kind='comment',text='Autonomie ailleurs.',parent='a2',readers=['*'])
    r=client.post('/api/comments/rank',json={'collection_id':cid,'article_external_id':'a1','query':'consentement autonomie','low_compute':True},headers=headers('b'))
    assert r.status_code==200,r.text
    ids=[row['external_id'] for row in r.json()['comments']]
    assert set(ids)=={'c1','c2'} and len(ids)==len(set(ids))
    for row in r.json()['comments']:
        e=row['evidence'];p=client.get(e['citation_url'],headers=headers('b')).json()
        assert p['text'][e['span']['start']:e['span']['end']]==row['relevant_excerpt']
    assert sync(client,cid,external='c1',kind='comment',parent='a2').status_code==409

def test_parent_acl_is_required_even_for_shared_comments(client):
    cid=collection(client,['*']);root=sync(client,cid,readers=['*']).json()['document_id']
    child=sync(client,cid,external='c1',kind='comment',text='Autonomie visible si parent lisible.',parent='a1',readers=['*']).json()['document_id']
    assert search(client,key='b',content_kind='comment').json()['results']
    client.put('/api/documents/'+root+'/acl',json={'readers':[]},headers=headers())
    assert search(client,key='b',content_kind='comment').json()['results']==[]
    assert client.get('/api/documents/'+child+'/pages/1',headers=headers('b')).status_code==404
    r=client.post('/api/comments/rank',json={'collection_id':cid,'article_external_id':'a1'},headers=headers('b'));assert r.status_code==404

def test_assistance_is_ephemeral_excludes_self_and_comments(client):
    cid=collection(client)
    sync(client,cid,external='source',text='Autonomie et consentement dans les sources.')
    sync(client,cid,external='draft',text='Autonomie dans mon brouillon.')
    sync(client,cid,external='c1',kind='comment',text='Autonomie dans un commentaire.',parent='source')
    client.post('/api/concepts',json={'name':'Autonomie','aliases':['consentement']},headers=headers())
    before=client.get('/api/documents',headers=headers()).json()
    r=client.post('/api/assist/article',json={'title':'Autonomie','body':'Mon texte sur le consentement.','external_id':'draft','collection_id':cid},headers=headers())
    assert r.status_code==200,r.text
    data=r.json();assert data['draft_stored'] is False
    assert data['sources'] and {x['external_id'] for x in data['sources']}=={'source'}
    assert data['concept_suggestions'][0]['name']=='Autonomie'
    assert client.get('/api/documents',headers=headers()).json()==before
    assert 'Mon texte sur le consentement.' not in client.get('/api/audit',headers=headers()).text

def test_article_updates_do_not_disconnect_comments_and_delete_purges_versions(client):
    cid=collection(client);sync(client,cid)
    sync(client,cid,external='c1',kind='comment',text='Autonomie et contrôle.',parent='a1')
    sync(client,cid,text='Autonomie modifiée.')
    r=client.post('/api/comments/rank',json={'collection_id':cid,'article_external_id':'a1'},headers=headers())
    assert r.status_code==200 and r.json()['comments'][0]['external_id']=='c1'
    deleted=client.post('/api/content/delete',json={'collection_id':cid,'kind':'article','external_id':'a1'},headers=headers())
    assert deleted.status_code==200 and deleted.json()['deleted_versions']==3
    assert client.get('/api/documents',headers=headers()).json()==[]
    repeat=client.post('/api/content/delete',json={'collection_id':cid,'kind':'article','external_id':'a1'},headers=headers())
    assert repeat.json()['deleted_versions']==0

def test_failed_sync_preserves_previous_active_article(client,monkeypatch):
    cid=collection(client);did=sync(client,cid).json()['document_id']
    def fail(*args,**kwargs):raise RuntimeError('simulated vector outage')
    monkeypatch.setattr(client.app.state.vectors,'upsert',fail)
    r=sync(client,cid,text='Changed article.');assert r.status_code==503
    assert client.get('/api/documents',headers=headers()).json()[0]['id']==did
    assert client.get('/api/documents/'+did+'/pages/1',headers=headers()).status_code==200

def test_assistance_excludes_only_article_namespace_not_same_id_document(client):
    cid=collection(client)
    sync(client,cid,external='same',kind='article',text='Autonomie en rédaction.')
    sync(client,cid,external='same',kind='document',text='Autonomie dans une source indépendante.')
    r=client.post('/api/assist/article',json={'title':'Autonomie','external_id':'same','collection_id':cid},headers=headers())
    assert r.status_code==200,r.text
    assert {x['kind'] for x in r.json()['sources']}=={'document'}
