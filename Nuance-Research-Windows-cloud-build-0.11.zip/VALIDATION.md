## Validation v0.5

53 tests Python passent. Contrôles supplémentaires : fermeture et rechargement des processus locaux, persistance/ACL des vecteurs, cache de requêtes sémantiques, nettoyage des topics, métriques réservées aux administrateurs. Parcours interface vérifié sur Mac ; Windows non testé. Mesures dans PERFORMANCE.md.

# Validation v0.4 — bibliothèque et recherche indexée

48 tests Python réussis : ACL, citations exactes, archivage/restauration, doublons, BibTeX, distribution sans données privées, carte et index lexical. Test de 2 500 documents / 125 000 passages réussi. Mesures et limites : SCALABILITY.md. PostgreSQL/Docker et Windows non exécutés dans cet environnement.

# Validation v0.2 — bloc d’intégration

- **24 tests Python réussis** : 16 tests du cœur récupéré + 8 tests des workflows applicatifs. SQLite et vrai Qdrant embarqué, pas de mock du stockage.
- **9 tests JavaScript/React réussis** : contrat de transport/payload, erreurs/abort, synchronisation, mapping d’identité du bridge, refus d’origine/non-JSON, limite de corps, debounce/annulation/réponses tardives du hook. React 19.3 et react-test-renderer 19.3 installés dans un environnement de test isolé ; ce renderer est déprécié, utilisé ici uniquement pour le test du hook.
- **TypeScript 7.0.2, compilation strict/noEmit réussie** du consommateur du package, y compris erreurs attendues sur modes inventés et périmètre de commentaires incomplet. Déclarations importées via les exports réels du package.
- **Parcours de bout en bout exécuté** : SDK JS → bridge authentifié → serveur FastAPI local → SQLite/Qdrant. Recherche, aide à la rédaction, commentaires, exactitude des spans, mise à jour conservant le lien aux commentaires, refus d’écriture d’un lecteur, suppression de versions/commentaires. Voir plugin-e2e-report.json.
- Tarball réellement installé dans un projet Node isolé : imports et appel du client réussis, sans dépendance runtime obligatoire. Wheel Python v0.2 construit.
- Ingestion idempotente, une version active par ID applicatif, namespace article/document distinct, brouillon non persisté, exclusion de l’article en cours et des commentaires des sources proposées, ACL du parent, confidentialité des commentaires, panne de vecteurs conservant l’article précédent, suppression rejouable : testés.

Le parcours SDK utilise demo-hash pour tester transport et ACL, pas la qualité sémantique. La validation antérieure du cœur a exécuté MiniLM et BERTopic hors ligne ; elle ne constitue pas une évaluation de pertinence des commentaires dans Nuance.

Non exécuté : montage des exemples dans le vrai projet Expo, Android/iOS, authentification réelle de nuance-app.eu, synchronisation de sa base, déploiement production. Les hooks de session/stockage/événements de l’application restent à raccorder. Aucun changement du site public.

Docker/Compose et PostgreSQL réel, gros modèles BGE/Qwen/reranker, OCR Docling, charge, audit sécurité complet et migrations restent à valider dans leur environnement cible. Une seule instance/worker, pas d’OIDC/outbox distribuée dans ce MVP. La v0.2 n’ajoute aucun appel LLM nécessaire.

## 0.6 writing upgrade

57 Python tests passed, including rich document schema safety, DOCX text styles/tables/real footnotes round-trip, APA/Chicago citation formatting, typed CSL/RIS metadata, private draft summaries/detail, and source ACL verification during citation formatting/export. The frontend sentence-plan test verified density counts (18/6/2) and exact text anchors. Browser tests on the actual local library verified editable DOCX import, Georgia/16pt formatting, preserved tables, style switching, footnote insertion without deleting a selected sentence, automatic marked parenthetical insertion, validation and Word export. The draft being edited appears in the draft list even before its first save. Test articles were not saved into the user's bibliography.

A short idle measurement after writing operations found the backend process at 164.5 MiB RSS, 0.33% of one CPU core over 3 seconds, with both model/vector workers released. This measures only the backend on this Mac, not browser/native-wrapper memory or Windows performance. See `writing-runtime-check.json` in the local outputs for the observation.

## 0.7 projects and metadata

68 Python tests pass, including synthetic PDF typography, explicit publication dates, ambiguous DOI/reference rejection, TEI safety, Crossref consent/mismatch (mocked service), reversible safe updates, partial-review revisions, batched idempotence, project union/empty scope/owner isolation/ACL revocation, scoped citations/maps/exports and draft scope persistence. Editor density/anchor Node checks pass (18/6/2 segments).

Local library: 432 notices reanalyzed, 267 distinct notices completed with reversible snapshots. No Crossref calls and no embeddings recomputed. Final bounded pass took 86.9 seconds on this Mac, including PDF parsing and notice updates. This is not a thousands-of-PDF throughput benchmark. Idle backend measured 192,610,304 resident bytes (~184 MiB), embedding/vector workers inactive; browser/native wrapper memory excluded. Live API `/api/health` reports 0.7.0. Browser verification covers project selection in library/writing/map and the explicit Crossref option. Screenshot supplied separately. Actual GROBID container, Crossref network availability and Windows remain unvalidated.

## 0.8 document reading, saved quotations and literature watch

81 Python tests pass, including exact/normalized quotation anchoring, version/hash checks, duplicate spans, private ownership, source ACL revocation, project exports, archive/restore and note revisions; explicit network consent, scheduler opt-in, interval limits, provider metadata deduplication, project assignment, encrypted Zotero credentials, bounded version cursors and connector ownership. Zotero/Crossref responses are mocked in the adapter tests. Node checks pass for writing density/anchors (18/6/2) and PDF ligature, line-hyphen and Unicode offset handling.

Browser checks on the running Mac library verify PDF rendering, text-layer selections, extracted-text selection, automatic saving, notes, persisted highlight overlays, reopening the source from Citations, leaving the reader, navigating a 25-page academic PDF, and transferring a map theme into a visible query without sending it. Map computation represented all 432 references. A meaningful example quotation remains in the user's private Citations folder; temporary larger/partial selections were archived and can be restored. PDF.js 6.4.299 requires destroying the loading task rather than the document proxy; leaving/reopening the reader is verified after this fix. Standard fonts were replaced by OFL Arimo instances, bundled with sources and provenance, to avoid redistributing upstream GPL font files. Screenshots supplied separately.

After backend restart, `/api/health` reports 0.8.0. Live local API checks verify that the saved quote is the exact source-page substring, the PDF hash is unchanged, and ZIP export contains JSON/Markdown under `citations/`. No private documents, citations, credentials or local database enter the sharing package. Backend observed at 160,268,288 resident bytes (~153 MiB), with embedding/vector workers inactive. This is one observation on this Mac, not browser/native-wrapper memory, a CPU-load benchmark or a Windows measurement.

The live Crossref query was blocked by automatic approval review because it could disclose a research interest; authorization was requested. No actual Zotero or university credential has been provided. No university sync, Google Scholar ingestion, Windows/Safari integration, periodic OS wake-up, exhaustive journal crawl or automatic full-text download is claimed. The implemented in-process periodic scheduler is tested with a controlled tick; long-running provider behavior remains to validate.

## 0.9 relevance, map topics and reader navigation

89 Python tests passed, including bilingual concept filtering, topic union/intersection, specialist-journal contextual evidence, semantic ranking that cannot rescue off-topic candidates, provider query sorting, reversible watch reset, cross-watch isolation and legacy cache filtering. The Node checks cover writing anchors, PDF normalization and horizontal gesture handling (vertical scroll, pinch, momentum, zoom pan).

Two explicitly authorized live Crossref queries were tested end-to-end: `neurotechnology law` retained 30 of 80 candidates; `international relations political legitimacy` retained 6 of 80. The user's original date filter and metadata-add preferences were preserved. No PDF, draft, quotation or account identifier was sent, and no notices were automatically added to the bibliography. Leading results concern neurodata regulation/neural rights and political legitimacy in international relations. These counts are retrieval outputs, not measured precision or recall; peripheral results remain and a researcher should validate relevance.

Browser verification on this Mac covers selecting two map topics with intersection mode and no external submission, isolating the chosen watch's results, the bottom-right next-page button, keyboard and horizontal scrolling advancing the document, and vertical scrolling retaining page 4. No console errors were observed. Reset/undo behavior was tested with isolated fixtures, not performed on the user's active watches. Physical trackpads, Safari and Windows remain to validate.

## 0.10 sage styling and portable Mac beta

89 Python tests passed after frozen-worker dispatch changes. Writing UI verified in the running local library and in the independent native Mac bundle: sage ribbon, panels, actions and white article page. The local install page no longer offers an email containing localhost.

A frozen Mac engine includes Python, dependencies and the multilingual MiniLM snapshot; an isolated smoke test created a fresh collection, ingested synthetic text and completed hybrid search through both frozen workers. Native Cocoa/WebKit opened the fresh library, authenticated automatically and displayed the writing page. It was closed after verification. The active original library was not migrated or copied. Mac package deployment target is macOS 14/arm64. No Developer ID signature/notarization, Windows execution, Intel build, public file hosting or infrastructure changes are claimed.

Writing palette refinement: warm off-white workspace, ivory side panels and very light sage ribbon. Browser computed styles verify white background with sage text/border for the writing navigation button, and unchanged saturated sage for Save/Analyze. This is a CSS-only change; no additional functional tests were required.

## 0.11 — 9 October 2026

- 96 Python tests passed, including low-disk/low-memory refusal, worker timeout and response size, watchdog targeting only its own process, and isolated extraction with exact page preservation.
- Editor sourcing density / anchors and PDF normalization / gesture checks passed; browser console contained no errors during the UI checks.
- Verified English/French switching, Light/Dark switching and preference persistence after reload across the main workspace screens. Source titles and project names retain their original language. No user draft was modified for these checks.
- Frozen Apple Silicon engine passed clean-library synthetic ingestion and hybrid search, serving preference assets and authenticated shutdown. After 32 seconds, both embedding and vector workers reported inactive.
- Synthetic engine-only RSS samples: main 149.3 MiB, embedding worker 1125.0 MiB, vector worker 99.2 MiB during work; main 148.9 MiB at rest. Total active samples about 1.34 GiB. These are process samples, not a measured hard peak; browser/WebKit is excluded, and a larger corpus changes the figures.
- Mac app compiled for macOS 14+, ad hoc code signature verified, beta `.pkg` rebuilt as 0.11.0. No Developer ID signature/notarization and no clean second-Mac installation test.
- Windows launcher/build/installer and CPU-only runtime checks prepared; native Windows build, installer behavior and performance not tested. The Windows build kit is source, not a ready-to-install `.exe`.
- No external service received source documents. No public server, DNS record or beta email was changed/sent.

The corrected managed-log configuration was also exercised in the frozen engine. Native Mac launch, automatic local login, English interface/native menu and closing the window with engine shutdown were verified in the independent empty desktop library. The current user library remains at 432 references after its graceful restart.
