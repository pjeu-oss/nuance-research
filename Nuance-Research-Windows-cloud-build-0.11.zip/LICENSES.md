# Registre initial des licences

| Composant | Licence déclarée | Source primaire |
|---|---|---|
| Nuance Core / SDK | MIT | LICENSE |
| Corpus synthétique | CC0-1.0 | demo/README.md ; https://creativecommons.org/publicdomain/zero/1.0/ |
| FastAPI / SQLAlchemy | MIT | https://github.com/fastapi/fastapi ; https://github.com/sqlalchemy/sqlalchemy |
| Starlette / Uvicorn / HTTPX | BSD-3-Clause | https://github.com/encode |
| PostgreSQL | PostgreSQL License | https://www.postgresql.org/about/licence/ |
| psycopg | LGPL-3.0 | https://www.psycopg.org/psycopg3/docs/basic/install.html#license |
| Qdrant code/client | Apache-2.0 | https://github.com/qdrant/qdrant ; https://github.com/qdrant/qdrant-client |
| pypdf | BSD-3-Clause | https://github.com/py-pdf/pypdf |
| python-multipart | Apache-2.0 | https://github.com/Kludex/python-multipart |
| MiniLM multilingue / Sentence Transformers | Apache-2.0 | https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2 ; https://github.com/huggingface/sentence-transformers |
| BGE-M3 / FlagEmbedding | MIT | https://huggingface.co/BAAI/bge-m3 ; https://github.com/FlagOpen/FlagEmbedding |
| Qwen3 Embedding / BGE reranker v2 m3 | Apache-2.0 | https://huggingface.co/Qwen/Qwen3-Embedding-0.6B ; https://huggingface.co/BAAI/bge-reranker-v2-m3 |
| BERTopic / Docling code | MIT | https://github.com/MaartenGr/BERTopic ; https://github.com/docling-project/docling |
| Docling/OCR poids | Variables ; audit séparé | https://docling-project.github.io/docling/usage/model_catalog/ |
| React facultatif | MIT | https://github.com/facebook/react |

Registre indicatif, pas un SBOM exhaustif. Torch, Transformers, NumPy, SciPy, UMAP, HDBSCAN, Pydantic, wheels natives, libpq, images et dépendances transitives ont leurs propres licences/notices. Le SDK principal n'a pas de dépendance runtime obligatoire ; React est optionnel. Les compilateurs/test runners ne sont pas livrés dans le tarball. Licence des poids n'égale pas droits des datasets ni droit d'importer des documents d'utilisateurs. Avant redistribution : collecter les notices des versions réellement installées, générer SBOM et scan actualisé, examiner obligations LGPL psycopg et composants liés, audit juridique des poids/documents/usages.

Runtime metrics: psutil 7.2.2, BSD-3-Clause. Memory reclamation calls the platform allocator API; no vendor source code is copied. Neural and vector workers use the same existing model and Qdrant licenses.

## Writing editor and citation formats (0.6)

Tiptap and ProseMirror are MIT licensed; exact bundled dependency notices are in `editor/THIRD-PARTY-NOTICES.txt`. The browser bundle is built locally and needs no CDN. citeproc-py 0.11.1 is BSD-2-Clause; python-docx 1.2.0 is MIT; lxml is BSD-3-Clause. Their Python package notices apply. Official APA and Chicago CSL style files are CC BY-SA 3.0, with contributor attribution inside each style; `nuance/styles/NOTICE.txt`, `PROVENANCE.json` and the bundled license contain the source and fingerprints. This license applies to the style files and adaptations, not to generated bibliographies. No proprietary Microsoft Word components or fonts are redistributed. Fonts use the user's installed system fonts.

0.7 additions: fontTools 4.66.1 (MIT); optional GROBID container/header service (Apache 2.0, audit transitive packages separately). Crossref is an optional external metadata service, not a bundled model. Sources: https://github.com/fonttools/fonttools/blob/main/LICENSE and https://github.com/grobidOrg/grobid/blob/master/LICENSE.

## Lecture et connexions (0.8)

PDF.js / pdfjs-dist 6.4.299 est Apache 2.0 ; la licence et les notices sont conservées dans `nuance/static/PDFJS-LICENSE.txt` et le bundle associé. Les décodeurs embarqués conservent leurs licences dans `pdf-wasm/` (OpenJPEG BSD, qcms MIT, JBIG2 PDFium BSD-3-Clause, wrappers PDF.js Apache 2.0). Les polices standard Foxit/PDFium sont BSD-3-Clause. Les polices de remplacement **Nuance Arimo** sont des instances statiques de Google Fonts Arimo, sous SIL OFL 1.1, renommées et fournies avec leurs sources variables, licence et empreintes dans `editor/reader-fonts/`. Leurs noms de fichiers de compatibilité répondent aux requêtes de polices standard de PDF.js. Les anciens fichiers Liberation GPL livrés en amont ne sont pas redistribués par Nuance. Sources : https://github.com/mozilla/pdf.js et https://github.com/google/fonts/tree/main/ofl/arimo.


cryptography 46.0.7 est distribuée sous Apache-2.0 ou BSD-3-Clause au choix ; ses composants natifs et dépendances ont leurs propres notices. Source : https://github.com/pyca/cryptography/blob/main/LICENSE. La connexion Zotero utilise un service externe optionnel ; aucun code propriétaire de portail ni de Google Scholar n’est embarqué.
