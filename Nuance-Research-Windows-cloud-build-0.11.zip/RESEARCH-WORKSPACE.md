# Nuance-Research — atelier de recherche 0.3, préversion locale

## Installation effectuée sur ce Mac

L’application native `Nuance-Research.app` est installée dans le dossier Applications du compte utilisateur. Elle ouvre une fenêtre Cocoa/WebKit, se connecte au moteur local et utilise la clé existante sans la stocker dans le navigateur. Si le moteur est arrêté, elle tente de le démarrer. Le moteur écoute uniquement sur 127.0.0.1:8000. Le LLM reste désactivé.

**Limite importante : cette application utilise les dépendances et le modèle déjà installés dans le dossier de travail de ce projet. Ce n’est pas un installateur autonome destiné à d’autres Mac.** Ne déplacez/supprimez pas le dossier de travail. Le paquet Mac ne contient ni Python, ni les poids du modèle, ni les documents ou clés privées. Le fichier Resources/local-config.json indique le dossier de travail. Le binaire est compilé pour le Mac actuel (Apple Silicon), signé ad hoc localement, sans notarisation Apple. Pour un autre Mac, préparer les dépendances et recompiler la source Swift. Aucune protection macOS n’a été désactivée.

Les données sont dans `work/user-data` : SQLite, sources originales et Qdrant embarqué. Les travaux de recherche sont dans la table `research_records`. Une sauvegarde SQLite avant ajout de ces tables est disponible dans `work/backups`. Cette sauvegarde ne remplace pas une sauvegarde cohérente de toutes les sources et de Qdrant ; sauvegarder l’ensemble moteur arrêté. La clé locale est dans `work/user-engine-credentials.json` (permissions 0600), jamais dans le ZIP livrable. La fermeture de l’app arrête uniquement un serveur démarré par cette instance, pas un serveur qui fonctionnait déjà.

## Bibliothèque

- Exporter les références depuis Zotero/Mendeley au format RIS (notices TY…ER) ou CSL JSON, puis importer ce fichier. Les PDF doivent être ajoutés séparément ; aucune lecture directe des bases de ces logiciels.
- Import CSL JSON : titre, auteurs, date, DOI, revue, résumé, tags et notes. Import RIS : TI/T1, AU/A1, PY/Y1/DA, DO, JO/JF/T2, AB/N2, KW, N1. Pas de parseur BibTeX dans cette version.
- Maximum 10 000 notices par import. Le contenu RIS/CSL est limité à 8 millions de caractères et à la limite HTTP existante.
- Déduplication d’import par DOI normalisé, sinon titre normalisé et année. Les doublons sont ignorés, pas fusionnés. Les fichiers PDF importés séparément peuvent encore produire des doublons de notices : contrôler le corpus avant d’interpréter ses statistiques.
- Import par lot PDF/TXT/MD/DOCX, séquentiel et local. Un échec est signalé sans arrêter les autres fichiers. Limites inchangées par fichier : 20 Mo, 500 pages, 2 millions de caractères. PDF contenant du texte ; OCR non activé.
- L’association automatique entre notice et document exige exactement le même titre et une seule notice candidate. Une association manuelle est disponible dans l’éditeur de référence.
- Les métadonnées extraites des PDF sont provisoires : corriger année, auteurs, revue et DOI. Aucune résolution DOI distante obligatoire.
- Le bouton BERTopic propose des mots/thèmes et leur association aux documents. L’utilisateur nomme et valide le thème avant ajout aux notices. Minimum 10, maximum 2 000 passages. Les thèmes personnels des notices sont distincts de la taxonomie de recherche du moteur historique.

## Rédaction

L’article est rédigé en texte Markdown. Un appel de recherche local intervient 1,2 seconde après une modification, sur le paragraphe autour du curseur, limité à 2 000 caractères. La case dédiée peut le désactiver. Un bouton permet le même appel à la demande. Douze passages au plus sont proposés. Le moteur ne rédige pas votre article et ne garantit pas qu’un passage prouve une affirmation.

L’insertion est volontaire : extrait inchangé, note de source, page et empreinte du document. Au moment d’enregistrer les citations, l’API vérifie l’accès au document, le titre, la page, l’empreinte et l’égalité exacte avec le passage enregistré. Le texte peut ensuite être édité : une citation modifiée dans le corps n’est pas relue automatiquement par le moteur. Contrôler les citations avant publication.

Sauvegarde **manuelle**, versions avec détection des écritures concurrentes. Ne pas changer d’article avec des modifications non enregistrées. Export Markdown avec notes de sources. Pas encore de bibliothèque CSL de styles, d’export DOCX, d’extension Word/LibreOffice, de coédition ou d’éditeur riche avec annotations PDF. Les suggestions peuvent afficher des passages voisins ou peu utiles : validation humaine nécessaire.

## Revue de littérature

Question et critères sont enregistrables. La recherche Exhaustive propose un ordre de lecture à partir du texte intégral disponible. Le classement utilise le meilleur passage retourné par document, sans évaluer la qualité méthodologique de l’étude. Le périmètre est la bibliothèque accessible, sans plafond de passages ; la sélection reste bornée à 2 000 candidats par signal en mode Exhaustive ; les 500 passages affichés peuvent omettre des documents. Les notices sans texte intégral ne bénéficient pas d’un classement sémantique sur leur résumé dans cette version.

L’utilisateur décide Inclure / Exclure / À examiner et indique un motif. Export CSV des décisions. Les statistiques portent sur **toute la bibliographie visible**, et non uniquement les études incluses : années, auteurs, revues, thèmes, années manquantes, disponibilité du texte intégral. Les noms d’auteurs ne sont pas désambiguïsés. Les champs absents ne sont pas inventés. Les décisions/critères ne sont pas interprétés automatiquement ; le moteur ne réalise pas un screening autonome.

Pas de recherche automatique PubMed/Crossref/OpenAlex, de protocole PRISMA complet, de double screening, de risque de biais/ROB2/ROBINS-I/GRADE ou de synthèse scientifique générée.

## Méta-analyse

CSV : `study_id,source,effect,se`. Un effet indépendant par étude, même résultat, même unité, même échéance, même population compatible. Les données importées sont **toutes non validées initialement**. Après correction, vérifier chaque ligne, préciser mesure/résultat/échéance et confirmer explicitement la comparabilité avant calcul.

Mesures supportées : SMD, MD, logOR, logRR, déjà calculées par l’utilisateur. Pour OR/RR, entrer leur logarithme et l’erreur standard sur cette échelle ; les résultats restent sur l’échelle logarithmique. Il n’y a pas d’extraction automatique des résultats numériques des PDF, de conversion SD→SE ou de calcul automatique de Hedges g.

Calcul exploratoire : variance inverse, effets aléatoires, tau² DerSimonian–Laird, intervalle de confiance **normal** à 95 %, Q et I². Forest plot interactif d’affichage et export JSON des entrées/méthode/résultats via l’historique d’analyses. L’export de l’interface porte sur le dernier résultat complet et inclut les études validées ; les inputs outcome/measure/timepoint et valeurs y sont conservés. Les analyses antérieures sont conservées par l’API, sans interface de reprise pour l’instant.

Pas de REML, HKSJ, correction de dépendance, intervalle de prédiction, sous-groupes, biais de publication, transformation des bornes sur l’échelle OR/RR ou graphique prêt pour publication. DL et l’IC normal peuvent sous-estimer l’incertitude, notamment avec peu d’études. Cette version n’est pas une chaîne statistique validée pour publier sans vérification indépendante.

Méthodologie de référence : [Cochrane Handbook, chapitre 10](https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10). Le choix de méthodes plus avancées fait partie des étapes de production.

## Sécurité et provenance

Travaux privés par utilisateur et tenant, y compris pour les administrateurs : aucun partage implicite. Notices liées à un document masquées si son accès est révoqué. Notes et brouillons précédemment enregistrés peuvent conserver des informations déjà consultées par leur auteur ; pas de révocation rétroactive de toutes les notes personnelles. Les analyses ont un identifiant et un audit. Les sources statistiques sont déclarées par l’utilisateur ; une coche confirme sa validation, pas une vérification automatique du contenu de la source.

Texte rendu via textContent, sans HTML venant des documents ; politique CSP locale. CSV de sélection protège contre l’interprétation des champs comme formules. La connexion native est limitée à l’origine locale et les liens externes sont ouverts dans le navigateur système. Le poste Mac et son compte doivent être de confiance ; pas de chiffrement applicatif au repos, utiliser les protections du disque et une sauvegarde.

Les nouveaux modules n’ajoutent aucune dépendance Python. Wrapper Swift/Cocoa/WebKit natif, composants système macOS. Modèle local MiniLM Apache 2.0 ; cœur MIT. Les autres licences restent décrites dans LICENSES.md. Les notices/papiers importés conservent leurs propres droits.

## Prochaines étapes prioritaires

1. Installateur autonome avec runtime intégré, modèle provisionné, stockage dans Application Support, signature Developer ID et notarisation ; tests sur plusieurs Mac.
2. Import enrichi BibTeX, normalisation des auteurs, association DOI/PDF robuste, dédoublonnage réversible et PDF annotables.
3. Sauvegarde automatique, styles CSL, export DOCX, gestion des sources révisées ou révoquées dans les travaux sauvegardés.
4. Protocoles/revues dédiés, double screening, sources externes optionnelles, PRISMA et biais méthodologiques.
5. Extraction structurée des résultats chiffrés avec page/table/source, validation à deux personnes ; REML/HKSJ et comparaison à un logiciel statistique de référence.

## Identité graphique

Logo fourni par l’utilisateur, repris sans modification. Palette observée sur https://nuance-app.eu/login le 8 octobre 2026 : crème #FFF9EC, sable #F5EEDF, brun #69411F, texte #35261B et secondaire #6F5A47. Police système, titres épais, cartes et boutons arrondis. La charte commune est dans static/brand.css. Le logo est inclus dans l’interface et dans l’icône ICNS Mac.
