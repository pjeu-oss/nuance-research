# Nuance-Research 0.4 — sharing and website installation

## What is ready

- `/install`: a public installation page with an email-share link and source-package download.
- A web app manifest, local icons and a service worker. On supported browsers, the website can be installed in an app window on macOS and Windows. Browser/device policies may restrict installation.
- API, model inference and private documents stay on the chosen server. The installed web app needs that server online. Only the public interface shell is cached; authenticated API responses and documents are not cached by the service worker.
- Local source deployment using Docker, with helper scripts for Mac and Windows. Docker Desktop and an Internet connection for the initial image/model download are prerequisites. The helper scripts have not been run on a Windows machine or tested with Docker in this environment; treat them as deployment helpers, not certified native installers.
- A small email attachment containing source code, demo corpus and setup instructions. No personal library, credentials, model weights or existing Mac paths are included.

**Not ready:** a publicly deployed installation URL, a signed/notarized self-contained Mac installer, or a tested Windows executable. The existing native Mac wrapper still uses its local setup and must not be emailed as a universal installer.

## Share by email

Use the provided source ZIP or open the `.eml` draft with its source attachment. Recipients who self-host need Docker and must generate their own credentials and obtain the model. No email has been sent automatically.

After web deployment, the easiest end-user route is to send `https://YOUR-HOST/install`. The app provides a “Share installation link by email” action that opens a draft. For a shared server, issue an individual credential and tenant/user identity to every person. Do not distribute your administrator key. Account onboarding and Google/Apple sign-in are not implemented in this research workspace.

## Local setup from the source package

1. Install and start Docker Desktop, following the vendor’s instructions.
2. Unzip the source package into a user-writable directory.
3. On Mac, run `scripts/bootstrap-macos.command`. On Windows, review and run `scripts/bootstrap-windows.ps1` in PowerShell under your organization’s execution policy; the helper does not weaken that policy.
4. The script creates `.env` once, builds the image and downloads the pinned MiniLM snapshot if absent. The access key is printed on first initialization. Preserve it privately.
5. Open `http://127.0.0.1:8000/install`, then enter your access key in the research workspace. First startup can take time for images, packages and model weights. Documents/models live on this installation, not in the downloaded source ZIP.

A server operator can also follow the existing README and configure a preseeded model without contacting an external inference API.

## Website deployment

A domain and server are required. The code has not been published to the existing Nuance website, and its repository/hosting account have not been supplied.

1. Prepare the source and model as above on a server you control. Set `NUANCE_DOMAIN` to your hostname in `.env`.
2. Configure DNS to that server and allow inbound TCP 80/443 for HTTPS issuance/access.
3. Run from the project root:

```
docker compose -f compose.yaml -f deployment/compose.https.yaml up -d --build
```

4. Open `https://YOUR-HOST/install`. Caddy proxies to the API and obtains the TLS certificate. Production infrastructure still needs backups, account provisioning, monitoring and appropriate limits. PostgreSQL and Qdrant are internal services; the base API port remains bound to localhost.
5. Installation: Safari “Add to Dock” on supported macOS; install-app option in Edge/Chrome on Windows or macOS. See [Apple](https://support.apple.com/en-ie/104996), [Microsoft](https://learn.microsoft.com/en-us/microsoft-edge/progressive-web-apps/ux), [Google](https://support.google.com/chrome/answer/9658361).

Cloud deployment determines where documents and queries go. Choose the host/region deliberately. No mandatory external model inference service has been added.

## New library tools

- Compact bibliography rows; import controls are collapsed by default. Title, authors/year, attachment status and duplicate signal remain visible.
- “Retirer” archives the personal bibliography entry. The original document is preserved for saved citations and the original document-search interface. Archived references are excluded from bibliography export, statistics, reflexive map and new bibliography citation suggestions. “Corbeille” restores them. Saved drafts/reviews keep their existing text and references.
- Import/sync will not silently bring back an archived attached document. Explicit reimport of bibliographic metadata may create a new entry, which the detector can flag.
- Duplicate detection runs on opening/refreshing the library. Exact signals: DOI, attached-file SHA-256 and normalized title. Similar-title candidates use a 0.92 similarity threshold, compatible known years/DOIs and bounded word buckets (80 references per word, at most 50,000 comparisons). No references are merged or deleted automatically. This does not guarantee all duplicates are found.
- BibTeX export is UTF-8, with unique stable keys and TeX escaping. Fields: title, authors, year, journal and DOI where present. Check author parsing and missing metadata; existing PDFs may have uncertain bibliographic information. Notes/private annotations are not exported in BibTeX.

## Reflexive map

The whole visible bibliography is considered (up to 10,000 references), not the top 200 search results. For attached documents, every stored passage embedding contributes to a mean document vector. Title/abstract embeddings are used when no text vector is available. Same-document duplicate attachments are represented once; separate duplicate files may still inflate counts until reviewed. Archived/inaccessible references are excluded.

KMeans groups normalized document vectors with a fixed seed. Topic labels are suggested from titles/abstracts using TF-IDF. They are not validated disciplines. PCA projects normalized topic centroids into 2D. Axes use the same scale to preserve the projection’s geometry; projected distances can still differ substantially from the underlying high-dimensional distances.

- Bubble **area** is proportional to represented reference count: prominence within this corpus, not scholarly importance or quality.
- Opacity shows within-topic cohesion, not truth or evidence strength.
- Links connect centroid cosine similarity >= 0.35; thicker links mean stronger similarity.
- An optional article comparison averages embeddings over 900-character windows, up to 200,000 characters. Bubble outlines become thicker for greater article/topic similarity. This is not an assessment of which topic the article ought to cover.
- Select a bubble to inspect its member sources and similarity/cohesion values. Pairwise cosine distances are provided separately, and map data/method/model/coverage can be exported as JSON.
- Empty areas or distant bubbles do **not** demonstrate a gap in the scientific literature. They depend on this library, model, clustering, document lengths, language and projection. Use them to ask reflexive questions, then inspect the sources.

Search now uses persistent SQLite FTS5 or PostgreSQL GIN full-text indexes instead of per-request corpus tokenization. There is no passage scope cap. See SCALABILITY.md for measured performance and the remaining limitations of embedded Qdrant.

## Bêta autonome 0.10

Le moteur figé et le lanceur Mac suppriment la dépendance au dossier du créateur. Un paquet Mac Apple Silicon/macOS 14 a été construit et testé avec une bibliothèque indépendante. Il reste non signé et non notarialisé ; un Mac propre reste à valider. Le lanceur et l’installateur Windows sont préparés sous desktop/, mais aucun binaire Windows vérifié n’est livré. La page /install masque le partage par e-mail d’une adresse locale ; un fichier réellement hébergé est nécessaire pour le lien public. Aucun domaine ni serveur existant n’a été modifié.
