# Lecture, citations et veille littéraire — 0.9

## Lire et conserver un passage

Dans Bibliothèque, cliquez **Lire** ou le titre d’une source dont le texte intégral est attaché. Le lecteur affiche le PDF original, une page à la fois, avec zoom et navigation. Les autres formats sont lisibles dans **Texte extrait** ; leur pagination est logique. Les documents protégés, scans sans OCR ou PDF inhabituels peuvent nécessiter le texte extrait ou le téléchargement de l’original.

Avec **Surligner et enregistrer les sélections** activé, sélectionner un passage le conserve automatiquement dans **Bibliothèque / Citations**, avec texte exact, référence, document, numéro de page, empreinte SHA-256 du fichier, offsets, provenance d’extraction et copie des métadonnées bibliographiques. Ajoutez une note et choisissez une couleur. Les PDF ne sont pas modifiés. La page physique PDF peut différer du numéro imprimé : le vérifier avant publication.

Le serveur refuse une citation absente de la page, ambiguë ou liée à une autre version du fichier. Les ligatures, espaces et césures sont rapprochés pour retrouver le passage original ; le texte enregistré reste celui réellement extrait. Un extrait OCR n’est pas une transcription certifiée du document : contrôle humain indispensable. Si la sélection PDF échoue, utilisez Texte extrait. Des occurrences identiques sont sélectionnables précisément dans cette vue ; leur overlay PDF peut être omis lorsqu’il est ambigu.

**Citations** est un dossier logique privé, persistant dans la base. **Exporter le dossier Citations** produit un ZIP contenant un véritable sous-dossier `citations/`, avec un fichier JSON et Markdown par citation. Les vues se paginent par 30 citations et peuvent se filtrer par projet. Les annotations peuvent être retirées et restaurées. Archiver une référence conserve ses citations tant que l’accès au document demeure autorisé. La révocation des ACL du document ou de la collection masque également les citations et leurs exports. Les métadonnées archivées dans une citation sont un instantané : elles ne sont pas automatiquement corrigées si la notice change.

## Veille littéraire

La page est située à côté de **Carte réflexive**. Cliquez **Charger / actualiser les thèmes** pour calculer les thèmes du périmètre bibliographique choisi sur la carte, puis cochez jusqu’à quatre thèmes. **Au moins un thème choisi** retient leur union ; **Tous les thèmes choisis** impose leur intersection. Chaque thème génère une recherche séparée. Sans sélection, saisissez une recherche libre. **Explorer ce thème dans la veille** prépare également une sélection. Toute modification des thèmes désactive le consentement en ligne jusqu’à votre nouvelle activation. La carte utilise votre bibliothèque ; elle ne détermine pas à elle seule les lacunes de toute la littérature.

Choisissez les projets de destination et le fournisseur. L’envoi en ligne demande une activation explicite ; aucune requête de veille n’est envoyée à l’ouverture de la page. Les vérifications périodiques sont désactivées par défaut, avec un intervalle minimum de six heures. Elles fonctionnent pendant que le moteur est lancé ; aucun service de réveil du Mac ni tâche Windows indépendante n’a été installé. Le planificateur vérifie les autorisations actuelles et utilise un seul fil léger. Les requêtes échouées ont un état consultable et ne relancent pas immédiatement une boucle de tentatives.

**Revues — Crossref** recherche les notices de publications déposées par les éditeurs, avec date de début et filtre strict ISSN. Le nom de revue est une préférence de recherche, pas un filtre exact. Chaque vérification examine jusqu’à 80 candidats par thème, triés par pertinence Crossref (maximum quatre thèmes), dédupliqués par DOI. Un filtre local vérifie les concepts dans le titre ou le résumé ; pour une requête à plusieurs concepts, une revue spécialisée peut compléter le contexte uniquement si au moins deux concepts sont déjà présents dans le texte. Les comptes rendus explicitement désignés comme tels dans le titre sont écartés. Un classement sémantique local facultatif affine ensuite les candidats retenus, sans réintroduire les candidats hors thème. Au maximum 40 propositions sont retenues par vérification. Les résumés et auteurs dépendent de ce que les éditeurs ont déposé. Ce n’est ni un parcours exhaustif de toutes les revues ni une revue systématique. Les résultats affichés appartiennent à la veille choisie ; les anciens résultats sans correspondance thématique sont filtrés localement.

Les propositions indiquent titre, auteurs, date, revue, DOI, origine et requête. Les termes retrouvés expliquent une correspondance ; aucun score ne représente une probabilité de vérité. Les DOI permettent de signaler les sources déjà présentes. **Ajouter la notice** classe une référence dans la bibliographie et les projets choisis. L’ajout automatique est une option distincte, désactivée par défaut. Il importe uniquement les métadonnées, jamais les PDF : importez vous-même les documents auxquels vous avez accès pour les lire, les indexer et les surligner.

**Google Scholar** ouvre la recherche correspondant à votre requête et offre un lien vers ses alertes. La création d’alertes et la consultation restent dans votre navigateur. Aucun scraping, récupération d’alertes par e-mail ni ingestion automatique de résultats Scholar n’est implémenté. Scholar ne propose pas d’accès en masse à ses notices : [aide officielle](https://scholar.google.com/intl/en/scholar/help.html).

## Connexions aux bibliothèques

**Zotero** : saisissez votre identifiant numérique et une clé API dédiée, en lecture seule, créée dans les paramètres de votre compte. La connexion vérifie l’accès à votre bibliothèque personnelle. Les vérifications suivantes demandent au plus 100 notices modifiées correspondant à la requête ; le curseur de version et la pagination sont conservés. Zotero effectue une recherche de phrase sur titre/auteur/année : ajustez les expressions proposées par la carte. Les bibliothèques de groupes, pièces jointes, suppressions et synchronisation bidirectionnelle ne sont pas prises en charge. Une bibliothèque modifiée pendant une pagination peut nécessiter une nouvelle veille pour rescanner les résultats ; une synchronisation de production doit verrouiller les versions. [API officielle Zotero](https://www.zotero.org/support/dev/web_api/v3/basics).

La clé Zotero est transmise uniquement dans l’en-tête HTTPS de l’API officielle, jamais dans une URL. Elle est stockée chiffrée AES-GCM avec séparation tenant/utilisateur/connexion ; aucune API de Nuance ne la retourne. La clé maîtresse locale `connection-vault.key` est créée avec droits 0600 sur Mac/Linux, à sauvegarder et protéger avec le répertoire de données. Le chiffrement ne protège pas d’un compte local compromis ni d’un vol simultané de la base et de cette clé. Vérifiez les ACL Windows. Déconnecter supprime la clé de la connexion et arrête les veilles associées ; révoquez également la clé chez Zotero si nécessaire. Aucun identifiant de compte n’est demandé dans la conversation.

**Portail universitaire** : enregistrer l’adresse HTTPS prépare un accès au portail dans votre navigateur, où vous effectuez le SSO/MFA. Les mots de passe et cookies ne sont pas récupérés par Nuance. Ce raccourci ne constitue pas une synchronisation automatique. Le connecteur institutionnel dépend du fournisseur, de son API, des droits de l’abonnement et de votre établissement ; le nom du portail est nécessaire pour développer cette étape. Il n’y a pas de connecteur générique EBSCO/Scopus/Web of Science ni de contournement des accès payants.

## Confidentialité, performances et limites

Lecture et annotations fonctionnent hors ligne. Les PDF et brouillons ne sont pas transmis aux fournisseurs de veille ; seule la requête et ses filtres sont envoyés au service choisi (ainsi que la clé requise pour votre bibliothèque Zotero). Une requête peut révéler un intérêt de recherche : ne transmettez pas d’information confidentielle dans ce champ. Les notices, citations et connexions restent isolées par utilisateur et tenant. Les liens externes sont HTTP(S), sans credentials, et les appels serveur visent des origines d’API fixes sans redirection.

PDF.js est chargé uniquement à l’ouverture du lecteur. Un seul canevas est rendu, limité à six millions de pixels, avec polices, décodeurs et worker locaux ; quitter la lecture détruit sa tâche et son worker. Avec **Affiner le classement avec le modèle local (CPU)**, la veille utilise le petit modèle déjà configuré dans le moteur. Il est chargé à la demande et libéré après son délai d’inactivité (30 secondes par défaut). Décochez cette option pour un classement par concepts uniquement ; aucun GPU n’est requis avec le modèle par défaut. Cela réduit les coûts au repos sans garantir une consommation maximale sur tous les PDF et OS : leur taille, complexité et extraction comptent. Le téléchargement complet du PDF demeure nécessaire ; streaming/range requests restent une amélioration future. La politique CSP autorise le WebAssembly uniquement pour les décodeurs locaux du workspace, sans autoriser l’évaluation JavaScript arbitraire.

Avant production : TLS et sessions solides, coffre de secrets système/serveur, OS keychain, sauvegardes chiffrées, politiques de rétention et quotas, reprise durable des vérifications, file de tâches et leader unique multiworker, backoff fournisseurs, tests réels Zotero avec vos credentials, validation Safari/Windows et PDF complexes, export PDF annoté, connecteur institutionnel approuvé et couverture élargie des fournisseurs.

## API intégrable

Toutes les routes ci-dessous utilisent l’authentification et les ACL du moteur.

- `GET /api/research/reader/{reference_id}` : pages, provenance et annotations accessibles.
- `POST /api/research/citations` : référence, page, empreinte source, texte et offsets facultatifs.
- `GET /api/research/citations` : `project_ids`, `reference_id`, `limit`, `offset`.
- `PUT /api/research/citations/{id}` : note/couleur et révision attendue.
- `POST /api/research/citations/{id}/archive` ou `/restore` : révision attendue.
- `GET /api/research/citations-export.zip` : sous-dossier de citations et provenance.
- `GET/POST /api/research/connections`, `POST /connections/{id}/disconnect`.
- `GET/POST /api/research/watches`, `PUT /watches/{id}`, `POST /watches/{id}/check`.
- `GET /api/research/discovery`, `POST /discovery/{id}/add` ou `/dismiss`.

La documentation interactive complète est accessible dans `/docs`. Les tests utilisent des fournisseurs simulés pour l’isolation, chiffrement et dédoublonnage ; le statut du test journal réel est documenté dans VALIDATION.md. Aucun credential institutionnel réel n’a été utilisé.

## Réinitialisation et navigation — 0.9

**Réinitialiser les propositions** remet à zéro les propositions et curseurs de la veille sélectionnée, tout en conservant sa configuration, la bibliographie, les PDF et les citations. Cliquez ensuite **Chercher maintenant** pour obtenir de nouvelles propositions ; une veille périodique conserve sa programmation. **Annuler la réinitialisation** restaure l’instantané précédent tant que la configuration n’a pas changé. Les autres veilles ne sont pas réinitialisées.

Le lecteur place **Page suivante →** sous la page, à droite, et **Page précédente** à gauche. Un balayage horizontal à deux doigts sur le document tourne une seule page par geste, avec protection contre l’inertie. Le défilement vertical, le pincement et le déplacement dans une page zoomée conservent leur usage. Les flèches gauche/droite fonctionnent lorsque le document a le focus. Les gestes ont été vérifiés avec des événements de défilement dans le navigateur sur ce Mac et des tests unitaires ; tous les trackpads physiques et OS restent à valider.

Les variantes FR/EN sont un dictionnaire contrôlé dans `nuance/watch_relevance.py`, pas un traducteur universel. Les thèmes trop longs, les synonymes inconnus, les résumés absents ou les concepts seulement implicites peuvent écarter des articles utiles ; des mentions secondaires peuvent retenir des articles périphériques. Réduisez les thèmes ou utilisez une recherche libre et examinez **Pourquoi cet article ?**. Les indices lexical et sémantique décrivent une correspondance documentaire, jamais une probabilité de vérité ni une validation scientifique.

API : `POST /api/research/watches/{id}/reset` avec la révision attendue ; `POST /api/research/watch-resets/{id}/restore` avec la révision courante. Les champs de veille `topics`, `topic_mode` (`any`/`all`) et `semantic_rerank` sont persistés. Les contrôles d’utilisateur, tenant et révision s’appliquent à ces opérations.
