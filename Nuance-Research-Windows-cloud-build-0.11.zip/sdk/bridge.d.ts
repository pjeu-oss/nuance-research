export interface Identity {tenant:string;user:string;role:'reader'|'editor'|'admin'}
export interface BridgeOptions {
 coreURL:string; authenticate:(request:Request)=>Identity|null|Promise<Identity|null>;
 resolveCoreToken:(identity:Identity)=>string|null|Promise<string|null>;
 fetch?:typeof globalThis.fetch; prefix?:string; maxBodyBytes?:number; allowedOrigins?:string[];
}
export function createNuanceBridge(options:BridgeOptions):(request:Request)=>Promise<Response>;
