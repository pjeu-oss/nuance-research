import type {NuanceClient,SearchInput,SearchResult} from './index.js';
export interface SearchHookOptions extends Omit<SearchInput,'query'> {enabled?:boolean;debounceMs?:number}
export function useNuanceSearch(client:NuanceClient,query:string,options?:SearchHookOptions):{status:'idle'|'loading'|'success'|'error';data:SearchResult|null;error:Error|null};
