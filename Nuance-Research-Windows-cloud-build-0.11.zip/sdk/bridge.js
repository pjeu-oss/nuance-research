/** Standard Fetch Request/Response handler. Mount in your EXISTING backend. */
export function createNuanceBridge({coreURL, authenticate, resolveCoreToken, fetch: fetchImpl = globalThis.fetch, prefix = '/api/nuance', maxBodyBytes = 1024*1024, allowedOrigins = []}) {
  if (!coreURL || !authenticate || !resolveCoreToken) throw new TypeError('coreURL, authenticate and resolveCoreToken are required');
  const base=coreURL.replace(/\/+$/, '');
  const error=(status,detail)=>Response.json({detail},{status,headers:{'Cache-Control':'no-store'}});
  return async function handle(request) {
    const pathname=new URL(request.url).pathname;
    if (!pathname.startsWith(prefix+'/')) return error(404,'Route unavailable');
    const route=pathname.slice(prefix.length);
    const allowed = request.method==='POST' && ['/search','/assist/article','/comments/rank','/content','/content/delete','/collections'].includes(route)
      || request.method==='GET' && (route==='/collections' || /^\/documents\/[a-f0-9-]+\/pages\/[1-9][0-9]*$/.test(route));
    if (!allowed) return error(404,'Route unavailable');
    const origin=request.headers.get('origin');
    if(origin && origin!==new URL(request.url).origin && !allowedOrigins.includes(origin))return error(403,'Origin denied');
    if(request.method==='POST' && !request.headers.get('content-type')?.toLowerCase().startsWith('application/json'))return error(415,'JSON required');
    let who,token;
    try { who=await authenticate(request); } catch { return error(401,'Authentication required'); }
    if (!who?.tenant || !who?.user || !['reader','editor','admin'].includes(who.role)) return error(401,'Authentication required');
    try { token=await resolveCoreToken(who); } catch { return error(503,'Nuance identity not provisioned'); }
    if (!token) return error(503,'Nuance identity not provisioned');
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),30000);
    const abort=()=>controller.abort();request.signal?.addEventListener('abort',abort,{once:true});
    try {
      if(request.signal?.aborted)controller.abort();
      // Never accept a common admin token as a substitute for the caller's identity.
      const identityResponse=await fetchImpl(base+'/me',{headers:{Authorization:'Bearer '+token},signal:controller.signal,redirect:'error'});
      if(!identityResponse.ok)return error(503,'Nuance identity not provisioned');
      const actual=await identityResponse.json();
      if(['tenant','user','role'].some(k=>actual[k]!==who[k]))return error(503,'Nuance credential mapping mismatch');
      let body;
      if(request.body){
        const reader=request.body.getReader();const parts=[];let size=0;
        while(true){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>maxBodyBytes){await reader.cancel();return error(413,'Body limit exceeded');}parts.push(part.value);}
        const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.byteLength;}
        body=new TextDecoder().decode(bytes);
      }
      const upstream=await fetchImpl(base+route,{method:request.method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body,signal:controller.signal,redirect:'error'});
      // Buffer bounded core JSON so timeout remains active through reading the response.
      const text=await upstream.text();
      return new Response(text,{status:upstream.status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
    } catch { return error(502,'Nuance service unavailable'); }
    finally {clearTimeout(timeout);request.signal?.removeEventListener('abort',abort);}
  };
}
