import {useEffect,useState} from 'react';
/** Optional debounced search hook with cancellation and stale-response protection. */
export function useNuanceSearch(client,query,{enabled=true,debounceMs=250,...options}={}) {
  const [state,setState]=useState({status:'idle',data:null,error:null});
  const optionKey=JSON.stringify(options);
  useEffect(()=>{
    const controller=new AbortController();let current=true;
    if(!enabled || !query.trim()){setState({status:'idle',data:null,error:null});return ()=>controller.abort();}
    setState({status:'loading',data:null,error:null});
    const timer=setTimeout(async()=>{
      try {const data=await client.search({query,...JSON.parse(optionKey)},{signal:controller.signal});if(current)setState({status:'success',data,error:null});}
      catch(error){if(current && !controller.signal.aborted)setState({status:'error',data:null,error});}
    },debounceMs);
    return ()=>{current=false;clearTimeout(timer);controller.abort();};
  },[client,query,enabled,debounceMs,optionKey]);
  return state;
}
