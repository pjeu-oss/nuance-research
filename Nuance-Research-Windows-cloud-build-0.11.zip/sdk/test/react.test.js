import test from 'node:test';
import assert from 'node:assert/strict';
let React,renderer,useNuanceSearch;
try {
  React=await import('react');renderer=await import('react-test-renderer');
  ({useNuanceSearch}=await import('../react.js'));
} catch(error) { if(error.code!=='ERR_MODULE_NOT_FOUND')throw error; }

test('React hook debounces, cancels, ignores stale results and resets empty query',{skip:!useNuanceSearch},async()=>{
  globalThis.IS_REACT_ACT_ENVIRONMENT=true;
  const calls=[];let observed,root;
  const client={search:(input,options)=>new Promise(resolve=>calls.push({input,signal:options.signal,resolve}))};
  function Probe({query}) { observed=useNuanceSearch(client,query,{debounceMs:5});return React.createElement('span',null,observed.status); }
  const wait=()=>new Promise(resolve=>setTimeout(resolve,20));
  await renderer.act(async()=>{root=renderer.create(React.createElement(Probe,{query:'first'}));});
  await renderer.act(wait);assert.equal(calls.length,1);
  await renderer.act(async()=>root.update(React.createElement(Probe,{query:'second'})));
  assert.equal(calls[0].signal.aborted,true);
  await renderer.act(wait);assert.equal(calls.length,2);
  await renderer.act(async()=>calls[1].resolve({results:[{quote:'latest'}]}));
  await renderer.act(async()=>calls[0].resolve({results:[{quote:'stale'}]}));
  assert.equal(observed.data.results[0].quote,'latest');
  await renderer.act(async()=>root.update(React.createElement(Probe,{query:' '})));
  assert.equal(observed.status,'idle');assert.equal(observed.data,null);
  await renderer.act(async()=>root.unmount());
});
