import test from 'node:test';
import assert from 'node:assert/strict';
import {createNuanceClient,NuanceError} from '../index.js';
import {createNuanceBridge} from '../bridge.js';

function mockClient() {
 const calls=[];
 const client=createNuanceClient({baseURL:'https://app.test/api/nuance/',getAccessToken:async()=>'app-session',fetch:async(url,init)=>{calls.push({url,...init,parsed:init.body?JSON.parse(init.body):null});return Response.json({ok:true});}});
 return {client,calls};
}
test('one client handles search, article assistance and comment ranking',async()=>{
 const {client,calls}=mockClient();
 await client.search({query:'autonomie',collectionId:'library',scientificMode:'Low Compute'});
 await client.assistArticle({title:'Titre',body:'Texte',externalId:'article-1'});
 await client.rankComments({collectionId:'comments',articleExternalId:'article-1'});
 assert.equal(calls[0].url,'https://app.test/api/nuance/search');
 assert.equal(calls[0].parsed.scientific_mode,'Low Compute');
 assert.equal(calls[1].parsed.external_id,'article-1');
 assert.equal(calls[2].parsed.article_external_id,'article-1');
 assert.equal(calls[0].headers.Authorization,'Bearer app-session');
});
test('content synchronization keeps app identifiers and ACLs',async()=>{
 const {client,calls}=mockClient();
 await client.upsertContent({collectionId:'lib',externalId:'c1',kind:'comment',title:'Comment',text:'Original',parentExternalId:'a1',readers:['*']});
 assert.deepEqual(calls[0].parsed.readers,['*']);assert.equal(calls[0].parsed.parent_external_id,'a1');
 await client.deleteContent({collectionId:'lib',externalId:'a1',kind:'article'});
 assert.equal(calls[1].url,'https://app.test/api/nuance/content/delete');
});
test('errors retain status and missing JSON is rejected',async()=>{
 const c=createNuanceClient({baseURL:'/api/nuance',fetch:async()=>Response.json({detail:'Forbidden'},{status:403})});
 await assert.rejects(c.search({query:'x'}),e=>e instanceof NuanceError && e.status===403 && e.message==='Forbidden');
 const bad=createNuanceClient({baseURL:'/api/nuance',fetch:async()=>new Response('not json')});
 await assert.rejects(bad.search({query:'x'}),e=>e instanceof NuanceError);
});
test('pre-aborted requests are not transmitted',async()=>{
 const controller=new AbortController();controller.abort();let calls=0;
 const c=createNuanceClient({baseURL:'/api/nuance',fetch:async()=>{calls++;return Response.json({});}});
 await assert.rejects(c.search({query:'x'},{signal:controller.signal}),e=>e.name==='AbortError');assert.equal(calls,0);
});
test('bridge authenticates existing session and ignores caller tenant headers',async()=>{
 const calls=[];const identity={tenant:'real',user:'bob',role:'reader'};
 const handler=createNuanceBridge({coreURL:'http://core/api',authenticate:async()=>identity,resolveCoreToken:async who=>{assert.deepEqual(who,identity);return 'private-key';},fetch:async(url,init)=>{calls.push({url,...init});return Response.json(url.endsWith('/me')?identity:{results:[]});}});
 const r=await handler(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{'Content-Type':'application/json','X-Tenant-ID':'attacker','Authorization':'Bearer forged'},body:'{"query":"autonomie"}'}));
 assert.equal(r.status,200);assert.equal(calls[1].headers.Authorization,'Bearer private-key');assert.equal(calls[1].headers['X-Tenant-ID'],undefined);
});
test('bridge refuses unauthenticated requests, arbitrary paths and admin mapping mismatch',async()=>{
 const identity={tenant:'a',user:'reader',role:'reader'};
 const noop=createNuanceBridge({coreURL:'http://core/api',authenticate:async()=>null,resolveCoreToken:async()=>null});
 assert.equal((await noop(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}))).status,401);
 assert.equal((await noop(new Request('https://app.test/api/nuance/audit'))).status,404);
 let count=0;
 const bad=createNuanceBridge({coreURL:'http://core/api',authenticate:async()=>identity,resolveCoreToken:async()=> 'common-admin',fetch:async()=>{count++;return Response.json({...identity,role:'admin'});}});
 assert.equal((await bad(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}))).status,503);assert.equal(count,1);
});
test('bridge enforces actual request-body limit',async()=>{
 const identity={tenant:'a',user:'b',role:'reader'};
 const handler=createNuanceBridge({coreURL:'http://core/api',maxBodyBytes:3,authenticate:async()=>identity,resolveCoreToken:async()=> 'key',fetch:async()=>Response.json(identity)});
 assert.equal((await handler(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{'Content-Type':'application/json'},body:'too large'}))).status,413);
});
test('bridge rejects non-JSON posts and untrusted browser origins',async()=>{
 const identity={tenant:'a',user:'b',role:'reader'};
 const handler=createNuanceBridge({coreURL:'http://core/api',authenticate:async()=>identity,resolveCoreToken:async()=> 'key',fetch:async()=>Response.json(identity)});
 assert.equal((await handler(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{Origin:'https://evil.test','Content-Type':'application/json'},body:'{}'}))).status,403);
 assert.equal((await handler(new Request('https://app.test/api/nuance/search',{method:'POST',headers:{'Content-Type':'text/plain'},body:'{}'}))).status,415);
});
