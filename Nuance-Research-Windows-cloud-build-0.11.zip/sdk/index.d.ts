export type Mode = 'Search' | 'Quotes' | 'Explore' | 'Topics' | 'Ask';
export type ScientificMode = 'Standard' | 'Exhaustive' | 'Contradict' | 'Explore' | 'Strict Sources' | 'Low Compute';
export type ContentKind = 'article' | 'comment' | 'document';
export interface RequestOptions {signal?: AbortSignal; timeoutMs?: number}
export interface ClientOptions {
  baseURL: string; getAccessToken?: () => string | null | undefined | Promise<string | null | undefined>;
  fetch?: typeof globalThis.fetch; timeoutMs?: number; credentials?: RequestCredentials;
}
export interface Source {
  chunk_id: string; document_id: string; external_id: string | null; kind: ContentKind; title: string;
  page: number; page_label: string; quote: string; span: {start:number; end:number}; source_sha256: string;
  citation_url: string; signals: Record<string,{score:number|null;rank:number|null}>;
  matched_terms: string[]; concepts: string[]; rrf:number; reranker_score:number|null;
  counterargument_marker:boolean; provenance:Record<string,unknown>;
}
export interface SearchInput {
  query:string; mode?:Mode; scientificMode?:ScientificMode; collectionId?:string; conceptId?:string;
  contentKind?:ContentKind; excludeExternalId?:string; limit?:number; rerank?:boolean;
}
export interface Coverage {authorized_documents:number;indexed_passages:number;candidates:number;returned:number;full_vector_traversal:boolean;truncated_output:boolean}
export interface SearchResult {results:Source[];warnings:string[];coverage:Coverage;explanation:string;pipeline:Record<string,unknown>}
export interface ArticleInput {title:string;body?:string;query?:string;collectionId?:string;externalId?:string;limit?:number;counterarguments?:boolean;rerank?:boolean}
export interface ArticleAssistance {query_used:string;draft_stored:false;sources:Source[];concept_suggestions:Array<{id:string;name:string;matched_aliases:string[];method:string}>;warnings:string[];explanation:string}
export interface CommentInput {collectionId:string;articleExternalId:string;query?:string;limit?:number;rerank?:boolean;lowCompute?:boolean}
export interface RankedComment {external_id:string;document_id:string;relevant_excerpt:string;evidence:Source}
export interface CommentResult {article_external_id:string;query_used:string;comments:RankedComment[];warnings:string[];coverage:Coverage;explanation:string}
export interface ContentInput {collectionId:string;externalId:string;kind?:ContentKind;title:string;text:string;parentExternalId?:string;readers?:string[]}
export interface SyncResult {document_id:string;external_id:string;kind:ContentKind;changed:boolean;previous_document_id?:string|null}
export interface DeleteInput {collectionId:string;externalId:string;kind:ContentKind}
export interface NuanceClient {
  search(input:SearchInput, options?:RequestOptions):Promise<SearchResult>;
  assistArticle(input:ArticleInput,options?:RequestOptions):Promise<ArticleAssistance>;
  rankComments(input:CommentInput,options?:RequestOptions):Promise<CommentResult>;
  upsertContent(input:ContentInput,options?:RequestOptions):Promise<SyncResult>;
  deleteContent(input:DeleteInput,options?:RequestOptions):Promise<{external_id:string;deleted_versions:number}>;
  createCollection(input:{name:string;readers?:string[]},options?:RequestOptions):Promise<{id:string;name:string}>;
  collections(options?:RequestOptions):Promise<Array<{id:string;name:string;owner:string;readers:string[]}>>;
  page(documentId:string,page:number,options?:RequestOptions):Promise<{document_id:string;page:number;page_label:string;text:string;sha256:string;provenance:Record<string,unknown>}>;
}
export class NuanceError extends Error {readonly status:number;constructor(message:string,status?:number)}
export function createNuanceClient(options:ClientOptions):NuanceClient;
