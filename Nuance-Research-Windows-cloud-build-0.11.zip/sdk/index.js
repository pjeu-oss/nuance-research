/** Fetch-only client: browsers, Expo/React Native and Node. No model on device. */
export class NuanceError extends Error {
  constructor(message, status = 0) { super(message); this.name = 'NuanceError'; this.status = status; }
}
export function createNuanceClient({baseURL, getAccessToken, fetch: fetchImpl = globalThis.fetch, timeoutMs = 15000, credentials = 'same-origin'}) {
  if (!baseURL || !fetchImpl) throw new TypeError('baseURL and fetch are required');
  const base = baseURL.replace(/\/+$/, '');
  async function request(path, body, options = {}, method = 'POST') {
    const controller = new AbortController();
    const abort = () => controller.abort(options.signal?.reason);
    if (options.signal?.aborted) abort();
    options.signal?.addEventListener('abort', abort, {once: true});
    const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? timeoutMs);
    try {
      const accessToken = await getAccessToken?.();
      if (controller.signal.aborted) { const error = new Error('Request aborted'); error.name = 'AbortError'; throw error; }
      const headers = {'Accept': 'application/json'};
      if (body !== undefined) headers['Content-Type'] = 'application/json';
      if (accessToken) headers.Authorization = 'Bearer ' + accessToken;
      const response = await fetchImpl(base + path, {method, headers, credentials, signal: controller.signal, body: body === undefined ? undefined : JSON.stringify(body)});
      let data;
      try { data = await response.json(); } catch { throw new NuanceError('Invalid JSON response', response.status); }
      if (!response.ok) throw new NuanceError(typeof data.detail === 'string' ? data.detail : 'Nuance request failed', response.status);
      return data;
    } finally {
      clearTimeout(timer); options.signal?.removeEventListener('abort', abort);
    }
  }
  return Object.freeze({
    search: (input, options) => request('/search', {
      query: input.query, mode: input.mode ?? 'Search', scientific_mode: input.scientificMode ?? 'Standard',
      collection_id: input.collectionId ?? null, concept_id: input.conceptId ?? null,
      content_kind: input.contentKind ?? null, exclude_external_id: input.excludeExternalId ?? null,
      limit: input.limit ?? 20, rerank: input.rerank ?? false
    }, options),
    assistArticle: (input, options) => request('/assist/article', {
      title: input.title, body: input.body ?? '', query: input.query ?? null,
      external_id: input.externalId ?? null, collection_id: input.collectionId ?? null,
      counterarguments: input.counterarguments ?? false, limit: input.limit ?? 10, rerank: input.rerank ?? false
    }, options),
    rankComments: (input, options) => request('/comments/rank', {
      collection_id: input.collectionId, article_external_id: input.articleExternalId,
      query: input.query ?? null, limit: input.limit ?? 10, rerank: input.rerank ?? false, low_compute: input.lowCompute ?? false
    }, options),
    upsertContent: (input, options) => request('/content', {
      collection_id: input.collectionId, external_id: input.externalId, kind: input.kind ?? 'article',
      title: input.title, text: input.text, parent_external_id: input.parentExternalId ?? null, readers: input.readers ?? null
    }, options),
    deleteContent: (input, options) => request('/content/delete', {
      collection_id: input.collectionId, external_id: input.externalId, kind: input.kind
    }, options),
    createCollection: (input, options) => request('/collections', input, options),
    collections: (options) => request('/collections', undefined, options, 'GET'),
    page: (documentId, page, options) => request('/documents/' + encodeURIComponent(documentId) + '/pages/' + Number(page), undefined, options, 'GET')
  });
}
