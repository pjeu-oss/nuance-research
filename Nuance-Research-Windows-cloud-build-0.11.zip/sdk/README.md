# @nuance/core-client 0.2.0

Client fetch portable pour Nuance Core : `search`, `assistArticle`, `rankComments`, `upsertContent`, `deleteContent`, `createCollection`, `collections`, `page`.

```js
import {createNuanceClient} from '@nuance/core-client';
const core=createNuanceClient({baseURL:'https://your-app/api/nuance',getAccessToken:()=>yourAppSessionToken});
const results=await core.search({query:'autonomie'});
```

Entrées facultatives : `@nuance/core-client/bridge` (backend Request/Response authentifié) et `@nuance/core-client/react` (hook de recherche debounced/annulable, React >=18).

Les clés administrateur/indexation Core restent dans le backend. Les utilisateurs passent par la session de leur application et une identité Core correspondante ; le bridge vérifie cette correspondance. Ce package ne crée pas votre authentification, vos collections ni l'index initial.

Documentation et exemples détaillés dans le projet Nuance Core : `INTEGRATION.md` et `examples/`. Package local, non publié sur npm. React facultatif ; aucun modèle, aucune API LLM et aucune dépendance nécessaire pour le client principal.
