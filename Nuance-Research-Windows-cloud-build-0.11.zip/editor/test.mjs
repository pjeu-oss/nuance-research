import {build} from 'esbuild';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const scratch=await mkdtemp(join(tmpdir(),'nuance-editor-test-'));
const target=join(scratch,'writer.mjs');
await build({entryPoints:['writer.js'],bundle:true,platform:'node',format:'esm',outfile:target,legalComments:'none'});
const {sourcingPlan}=await import(target);
const {Schema}=await import('@tiptap/pm/model');
const schema=new Schema({nodes:{doc:{content:'paragraph+'},paragraph:{content:'text*',group:'block'},text:{group:'inline'}}});
const text='Les résultats montrent un effet significatif chez les participants. Une autre phrase présente des considérations descriptives dans cette étude. Un dernier point permet de discuter les méthodes choisies pour la recherche.';
const doc=schema.node('doc',null,Array.from({length:6},()=>schema.node('paragraph',null,schema.text(text))));
const all=sourcingPlan(doc,'all'),key=sourcingPlan(doc,'key'),light=sourcingPlan(doc,'light');
if(all.length!==18||key.length!==6||light.length!==2)throw Error(JSON.stringify({all:all.length,key:key.length,light:light.length}));
for(const p of all)if(doc.textBetween(p.from,p.to)!==p.query)throw Error('Anchor does not match source text');
console.log('Sourcing density and exact text anchors verified: 18 / 6 / 2');

await rm(scratch,{recursive:true,force:true});

const {normalized}=await import('./reader-anchors.js');
for(const [source,expected] of [['The ﬁnal re-\nsearch question.','Thefinalresearchquestion.'],['A😀 ﬁne\u00ad phrase','A😀finephrase']]){const r=normalized(source);if(r.key!==expected||r.positions.length!==r.key.length)throw Error('PDF quote normalization mismatch');for(let i=0;i<r.positions.length;i++)if(r.positions[i]<0||r.positions[i]>=source.length)throw Error('Invalid quote offset');}
console.log('PDF ligature, line hyphen and Unicode anchors verified');

const {PageGesture}=await import('./page-gesture.js');
const gesture=new PageGesture();
if(gesture.feed({dx:0,dy:100,time:0}).consume)throw Error('Vertical scroll intercepted');
if(gesture.feed({dx:100,dy:0,time:1,ctrlKey:true}).turn)throw Error('Pinch turned page');
if(gesture.feed({dx:40,dy:1,time:500}).turn)throw Error('Premature gesture');
if(gesture.feed({dx:40,dy:1,time:530}).turn!==1)throw Error('Next-page gesture missed');
if(gesture.feed({dx:120,dy:1,time:600}).turn)throw Error('Momentum turned second page');
if(gesture.feed({dx:-80,dy:0,time:1400}).turn!==-1)throw Error('Reverse gesture missed');
const pan=new PageGesture();
if(pan.feed({dx:90,dy:0,time:0,panRoom:true}).consume)throw Error('Zoom pan intercepted');
if(pan.feed({dx:90,dy:0,time:50}).turn)throw Error('Pan momentum turned page');
console.log('Horizontal page gestures, momentum, pinch and native scrolling verified');
