// One horizontal trackpad gesture turns at most one page. Vertical scrolling,
// pinch zoom and horizontal panning of a zoomed document retain native behavior.
export class PageGesture {
 constructor(){this.last=-Infinity;this.turnedAt=-Infinity;this.total=0;this.latched=false;this.panning=false;}
 feed({dx,dy,time,ctrlKey=false,panRoom=false}){
  if(time-this.last>280){this.total=0;this.latched=false;this.panning=false;}this.last=time;
  if(ctrlKey||Math.abs(dx)<2||Math.abs(dx)<Math.abs(dy)*1.5){this.total=0;return {consume:false,turn:0};}
  if(panRoom){this.panning=true;this.total=0;return {consume:false,turn:0};}
  if(this.panning||this.latched||time-this.turnedAt<700)return {consume:true,turn:0};
  if(this.total&&Math.sign(this.total)!==Math.sign(dx))this.total=0;this.total+=dx;
  if(Math.abs(this.total)<70)return {consume:true,turn:0};
  const turn=Math.sign(this.total);this.latched=true;this.turnedAt=time;this.total=0;return {consume:true,turn};
 }
}
