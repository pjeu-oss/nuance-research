import {build} from 'esbuild';
await build({entryPoints:['writer.js'],bundle:true,format:'esm',minify:true,outfile:'../nuance/static/editor.bundle.js',legalComments:'linked'});

await import('./build-reader.mjs');
